// Mlife 脚本拆分工具 v2 — 按行号范围提取
const fs = require('fs');
const lines = fs.readFileSync('E:/tavern_sync_project/角色卡修改用/魅途/脚本/Mlife_TH.js', 'utf8').split('\n');
const DIR = 'E:/tavern_sync_project/角色卡修改用/魅途/脚本/';

// 关键行号（1-indexed -> 0-indexed）
const L = {
  bootStart: 6,        // (function(){"use strict";
  coreStart: 33,       // window.MlifeApp = (function() {
  floatStart: 3765,    // // ---- 酒馆模式：自动创建可拖动的悬浮窗 ----
  dmStart: 4047,       // // [2] DM Manager
  autoInitStart: 4771, // // [4] Auto-init
  fileEnd: 4789,       // })();
};

// ===== 模块1: Core =====
// 引擎核心 + 浮球 + DM + auto-init
let coreCode = lines.slice(0, L.coreStart).join('\n') + '\n';
coreCode += lines.slice(L.coreStart, L.floatStart).join('\n') + '\n';
coreCode += lines.slice(L.floatStart, L.dmStart).join('\n') + '\n';
coreCode += lines.slice(L.dmStart, L.autoInitStart).join('\n') + '\n';
coreCode += lines.slice(L.autoInitStart).join('\n');

// Add MLIFE_MODULE_CORE marker
coreCode = coreCode.replace('// MLIFE_SELF_CONTAINED', '// MLIFE_MODULE_CORE');

fs.writeFileSync(DIR + 'MlifeCore.js', coreCode, 'utf8');
console.log('MlifeCore.js:', (coreCode.length/1024).toFixed(0), 'KB');

// ===== 验证语法 =====
function checkSyntax(code, name) {
  try { new Function(code); console.log(`  ${name}: 语法 OK`); }
  catch(e) { console.log(`  ${name}: 语法错误 - ${e.message.slice(0,100)}`); }
}
checkSyntax(coreCode, 'Core');

console.log('\n拆分完成。注意：还需创建 Pages 和 Recruit 模块（从 Core 中提取函数）。');
