// build.js —— 将 src/ 下的模块按序注入外层 IIFE，重新打包为单文件 Mlife_TH.js
// 设计：保持"刷新自动生效"单文件契约（见 Mlife_TH.js 顶部 MLIFE_SELF_CONTAINED）。
// 模块注入位置：紧接外层 `(function(){"use strict";` 之后，使常量/工具函数
// 处于外层作用域，通过闭包被 MlifeApp / DM_Manager / Launcher 各嵌套 IIFE 共享。
const fs = require('fs');
const path = require('path');

const SRC = 'X:/tavern_sync_project/角色卡修改用/魅途/脚本/src';
const OUT = 'X:/tavern_sync_project/角色卡修改用/魅途/脚本/Mlife_TH.js';

const order = ['constants.js', 'storage.js', 'escape.js', 'parse.js'];
let modules = '';
for (const f of order) {
  modules += '\n/* ===================== src/' + f + ' ===================== */\n';
  modules += fs.readFileSync(path.join(SRC, f), 'utf8').trimEnd();
  modules += '\n';
}

let main = fs.readFileSync(path.join(SRC, 'main.js'), 'utf8');
const marker = '(function(){"use strict";';
const idx = main.indexOf(marker);
if (idx < 0) throw new Error('未找到外层 IIFE 标记: ' + marker);

const built = main.slice(0, idx + marker.length) + modules + main.slice(idx + marker.length);
fs.writeFileSync(OUT, built);
console.log('build ok ->', OUT);
console.log('injected module bytes:', modules.length);
