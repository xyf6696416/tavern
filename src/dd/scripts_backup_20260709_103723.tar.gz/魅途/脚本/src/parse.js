// ===== src/parse.js =====
// 提取 AI 回复文本，适配不同 API 格式。
// 原 MlifeApp（931）与 DM_Manager（4259）两处实现完全等价，合并为单一定义。
function extractReply(json) {
  if (!json) return '';
  try {
    if (json.choices && json.choices[0]) {
      var c = json.choices[0];
      if (c.message && c.message.content) return c.message.content;
      if (c.text) return c.text;
    }
    if (json.results && json.results[0] && json.results[0].text) {
      return json.results[0].text;
    }
  } catch (_) {}
  return '';
}
