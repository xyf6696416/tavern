// ===== src/constants.js =====
// 统一持久化 key 表（与《M-life 产品手册 v2.0》§8.1 数据维度对应）
// 通过外层 IIFE 闭包被 MlifeApp / DM_Manager / Launcher 共享。
var STORAGE_KEYS = {
  // —— MlifeApp 主模块（原硬编码字面量，Phase 1 收敛）——
  ACCOUNT: 'mlife_account',
  DM_THREAD: 'mlife_dm_',                         // 主会话线程 key 前缀
  RECRUIT_POSTS: 'mlife_recruit_posts',
  DM_SESS: 'mlife_dm_sess_v1_',                   // 会话数据 key 前缀（与 DM_Manager STORAGE_SESS_PREFIX 同源）
  RECRUIT_APPLICANTS: 'mlife_recruit_applicants_', // 应征者 key 前缀
  RECRUIT_APPLICATIONS: 'mlife_recruit_applications',

  // —— DM_Manager / Launcher 既有常量（纳入统一表，便于后续收敛）——
  DM_INDEX: 'mlife_dm_index_v1',
  DM_UNREAD: 'mlife_dm_unread_v1',
  DM_PERSONA: 'mlife_dm_persona_v1_',             // persona 缓存 key 前缀
  FLOAT_BALL: 'mlifeFloatBallPos',
  THEME: 'mlifeTheme'
};

// 招募 / 应征 状态色（Phase 2 收口：原两处 statusColorMap 取并集）
// 同时被 renderRecruitDetail 与 renderRecruitManage 共用，零行为变更。
var STATUS_COLORS = {
  '招募中':   '#34d399',
  '已报名':   '#60a5fa',
  '已确认':   '#60a5fa',
  '已选中':   '#60a5fa',
  '已完成':   '#34d399',
  '已取消':   '#9ca3af',
  '未选中':   '#6a6a70',
  '争议中':   '#f87171',
  '等待确认': '#fbbf24',
  '已锁定':   '#60a5fa'
};
