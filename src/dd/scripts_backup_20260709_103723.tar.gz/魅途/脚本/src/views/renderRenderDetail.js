
            app.renderDetail = function(data) {
                if (!data || !data.nick) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">详情不可用</div>';
                }

                var hiddenComment = '<!-- hidden: ' + (data.hidden || '') + ' -->\n';

                // 大号头像
                var headerHtml = '<div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--ml-border);">'
                    + '<span style="font-size:56px;width:64px;text-align:center;line-height:64px;flex-shrink:0;">' + (data.avatar || '') + '</span>'
                    + '<div style="flex:1;min-width:0;">'
                    + '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px;">'
                    + '<span style="font-weight:bold;font-size:20px;color:var(--ml-text);">' + app.escapeHtml(data.nick || '') + '</span>'
                    + (data.vip && data.vip !== '无'
                        ? '<span style="font-size:12px;padding:2px 10px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;">' + app.escapeHtml(data.vip) + '</span>'
                        : '')
                    + '</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);display:flex;gap:12px;flex-wrap:wrap;margin-bottom:4px;">'
                    + '<span>' + (data.age || '--') + '岁</span>'
                    + '<span>&middot;</span>'
                    + '<span>' + app.escapeHtml(data.distance || '') + '</span>'
                    + '<span>&middot;</span>'
                    + '<span>' + app.escapeHtml(data.active || '') + '</span>'
                    + '<span>&middot;</span>'
                    + '<span>' + app.escapeHtml(data.level || '') + '</span>'
                    + '</div>'
                    + '<div style="font-size:12px;color:var(--ml-text-dimmer);display:flex;gap:10px;flex-wrap:wrap;">'
                    + '<span>' + app.escapeHtml(data.registered || '') + '</span>'
                    + '<span>&middot;</span>'
                    + '<span>' + app.escapeHtml(data.purpose || '') + '</span>'
                    + '</div>'
                    + '</div>'
                    + '</div>';

                // 简介
                var bioHtml = data.bio
                    ? '<div style="margin-bottom:14px;">'
                        + '<div style="font-size:12px;color:#008899;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">简介</div>'
                        + '<div style="font-size:14px;color:var(--ml-text-ccc);line-height:1.6;padding:10px 12px;background:var(--ml-bg-info);border-radius:8px;border:1px solid #1a1a2e;">'
                        + app.escapeHtml(data.bio) + '</div>'
                        + '</div>'
                    : '';

                // 标签列表
                var tagsHtml = '';
                if (data.tags && data.tags.length > 0) {
                    tagsHtml = '<div style="margin-bottom:14px;">'
                        + '<div style="font-size:12px;color:#008899;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">标签</div>'
                        + '<div style="display:flex;flex-wrap:wrap;gap:6px;">';
                    for (var j = 0; j < data.tags.length; j++) {
                        tagsHtml += '<span style="display:inline-block;padding:4px 10px;border-radius:14px;background:rgba(255,107,157,0.12);color:var(--ml-accent);font-size:12px;border:1px solid #ff6b9d;">'
                            + app.escapeHtml(data.tags[j]) + '</span>';
                    }
                    tagsHtml += '</div></div>';
                }

                // 详细信息区
                var infoHtml = '<div style="margin-bottom:14px;display:grid;grid-template-columns:1fr 1fr;gap:8px;">';
                if (data.bodyType) {
                    infoHtml += '<div style="padding:8px 10px;background:var(--ml-bg-info);border-radius:6px;border:1px solid #1a1a2e;">'
                        + '<div style="font-size:10px;color:#008899;letter-spacing:0.06em;margin-bottom:2px;">体型</div>'
                        + '<div style="font-size:13px;color:var(--ml-text-main);">' + app.escapeHtml(data.bodyType) + '</div></div>';
                }
                if (data.height) {
                    infoHtml += '<div style="padding:8px 10px;background:var(--ml-bg-info);border-radius:6px;border:1px solid #1a1a2e;">'
                        + '<div style="font-size:10px;color:#008899;letter-spacing:0.06em;margin-bottom:2px;">身高</div>'
                        + '<div style="font-size:13px;color:var(--ml-text-main);">' + app.escapeHtml(data.height) + '</div></div>';
                }
                if (data.faceStyle) {
                    infoHtml += '<div style="padding:8px 10px;background:var(--ml-bg-info);border-radius:6px;border:1px solid #1a1a2e;">'
                        + '<div style="font-size:10px;color:#008899;letter-spacing:0.06em;margin-bottom:2px;">面容</div>'
                        + '<div style="font-size:13px;color:var(--ml-text-main);">' + app.escapeHtml(data.faceStyle) + '</div></div>';
                }
                if (data.features) {
                    infoHtml += '<div style="padding:8px 10px;background:var(--ml-bg-info);border-radius:6px;border:1px solid #1a1a2e;">'
                        + '<div style="font-size:10px;color:#008899;letter-spacing:0.06em;margin-bottom:2px;">特征</div>'
                        + '<div style="font-size:13px;color:var(--ml-text-main);">' + app.escapeHtml(data.features) + '</div></div>';
                }
                infoHtml += '</div>';

                // 风格
                var styleHtml = '';
                if (data.dailyStyle || data.dateStyle) {
                    styleHtml = '<div style="margin-bottom:14px;display:grid;grid-template-columns:1fr 1fr;gap:8px;">';
                    if (data.dailyStyle) {
                        styleHtml += '<div style="padding:8px 10px;background:var(--ml-bg-info);border-radius:6px;border:1px solid #1a1a2e;">'
                            + '<div style="font-size:10px;color:#008899;letter-spacing:0.06em;margin-bottom:2px;">日常风格</div>'
                            + '<div style="font-size:13px;color:var(--ml-text-main);">' + app.escapeHtml(data.dailyStyle) + '</div></div>';
                    }
                    if (data.dateStyle) {
                        styleHtml += '<div style="padding:8px 10px;background:var(--ml-bg-info);border-radius:6px;border:1px solid #1a1a2e;">'
                            + '<div style="font-size:10px;color:#008899;letter-spacing:0.06em;margin-bottom:2px;">约会风格</div>'
                            + '<div style="font-size:13px;color:var(--ml-text-main);">' + app.escapeHtml(data.dateStyle) + '</div></div>';
                    }
                    styleHtml += '</div>';
                }

                // 照片墙
                var imagesHtml = '';
                if (data.images && data.images.length > 0) {
                    imagesHtml = '<div style="margin-bottom:14px;">'
                        + '<div style="font-size:12px;color:#008899;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">照片 ' + data.images.length + '张</div>';
                    for (var k = 0; k < data.images.length; k++) {
                        var img = data.images[k];
                        imagesHtml += '<div style="background:var(--ml-bg-info);border-radius:8px;padding:10px 12px;margin-bottom:6px;font-size:13px;color:var(--ml-text-aaa);border:1px solid #1a1a2e;border-left:3px solid #ff6b9d;">'
                            + '<span style="color:var(--ml-accent);margin-right:6px;">&#x1F5BC;</span>'
                            + app.escapeHtml(img.desc || '') + '</div>';
                    }
                    imagesHtml += '</div>';
                }

                // 匹配时间
                var matchTimeHtml = data.matchTime
                    ? '<div style="text-align:center;font-size:12px;color:var(--ml-accent);margin-bottom:14px;padding:6px;background:rgba(255,107,157,0.08);border-radius:6px;border:1px solid rgba(255,107,157,0.2);">'
                        + '&#x2665; ' + app.escapeHtml(data.matchTime) + '</div>'
                    : '';

                // 操作按钮
                var actionsHtml = '<div style="display:flex;gap:10px;">'
                    + '<button onclick="MlifeApp.action(\'/send 返回匹配|/trigger\')" style="flex:1;padding:11px;border-radius:10px;border:1px solid #3a3a4a;background:#16161e;color:var(--ml-text-dim);font-size:14px;cursor:pointer;font-family:inherit;transition:all 0.2s;">返回</button>'
                    + '<button onclick="MlifeApp.action(\'/send 发私信给|/trigger\')" style="flex:1;padding:11px;border-radius:10px;border:1px solid #ff6b9d;background:var(--ml-glow-10);color:var(--ml-accent);font-size:14px;font-weight:bold;cursor:pointer;font-family:inherit;transition:all 0.2s;">&#x2709; 发私信</button>'
                    + '</div>';

                var html = '<div style="padding:0;">'
                    + hiddenComment
                    + '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:14px;padding:16px;">'
                    + headerHtml
                    + matchTimeHtml
                    + bioHtml
                    + tagsHtml
                    + infoHtml
                    + styleHtml
                    + imagesHtml
                    + actionsHtml
                    + '</div>'
                    + '</div>';

                MlifeApp.updateCache('detail', html);
                return html;
            };
