
            app.renderDM = function(data) {
                if (!data || !data.contact) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">选择联系人开始聊天</div>';
                }

                // 1. 尝试从 localStorage 加载历史
                var cached = MlifeApp.loadDM(data.contact);
                var messages = data.messages || [];

                // 2. 如果 AI 给的数据比缓存新，用 AI 数据覆盖缓存
                if (messages.length > 0) {
                    MlifeApp.saveDM(data.contact, data);
                } else if (cached) {
                    // 没有新数据但有缓存 → 用缓存
                    messages = cached.messages || [];
                    data.avatar = cached.avatar;
                    data.level = cached.level;
                }

                // 3. 渲染聊天界面
                // 私信返回按钮：前端导航到匹配页面（不触发AI）
                var headerHtml = '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;margin-bottom:10px;border-bottom:1px solid var(--ml-border);flex-shrink:0;">'
                    + '<button onclick="MlifeApp.switchTab(\'match\')" style="background:none;border:none;color:var(--ml-text-dim);font-size:18px;cursor:pointer;padding:0 4px;font-family:inherit;">&#x2190;</button>'
                    + '<span style="font-size:36px;width:42px;text-align:center;line-height:42px;flex-shrink:0;">' + (data.avatar || '') + '</span>'
                    + '<div style="flex:1;min-width:0;">'
                    + '<div style="display:flex;align-items:center;gap:6px;">'
                    + '<span style="font-weight:bold;font-size:16px;color:var(--ml-text);">' + app.escapeHtml(data.contact) + '</span>'
                    + (data.level ? '<span style="font-size:11px;padding:1px 6px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(data.level) + '</span>' : '')
                    + '</div>'
                    + '</div>'
                    + '</div>';

                // 3.5 开盒入口按钮（有角色数据时显示）
                var unboxBtnHtml = '';
                if (data.hasCharacter && data.contact) {
                    unboxBtnHtml = '<div style="margin-bottom:10px;">'
                        + '<button onclick="MlifeApp.action(\'/send 开盒' + encodeURIComponent(data.contact) + '|/trigger\')" '
                        + 'style="width:100%;padding:10px;border-radius:10px;border:1px solid #f6d365;'
                        + 'background:linear-gradient(135deg,rgba(246,211,101,0.1),rgba(253,160,133,0.1));'
                        + 'color:#f6d365;font-size:14px;font-weight:bold;cursor:pointer;font-family:inherit;'
                        + 'transition:background 0.2s;"'
                        + 'onmouseover="this.style.background=\'linear-gradient(135deg,rgba(246,211,101,0.2),rgba(253,160,133,0.2))\'"'
                        + 'onmouseout="this.style.background=\'linear-gradient(135deg,rgba(246,211,101,0.1),rgba(253,160,133,0.1))\'">'
                        + '&#x1F48E; 开盒查看完整信息 (100 M币)</button>'
                        + '</div>';
                }

                // 消息气泡
                var messagesHtml = '';
                if (messages && messages.length > 0) {
                    messagesHtml = '<div style="margin-bottom:10px;">';
                    for (var i = 0; i < messages.length; i++) {
                        var msg = messages[i];
                        var hiddenComment = '<!-- hidden: ' + (msg.hidden || '') + ' -->\n';
                        var isIncoming = msg.type === 'incoming';
                        var align = isIncoming ? 'left' : 'right';
                        var bubbleBg = isIncoming ? '#1e1e2e' : '#ff6b9d';
                        var bubbleColor = isIncoming ? '#ddd' : '#fff';
                        var borderRadius = isIncoming ? '12px 12px 12px 4px' : '12px 12px 4px 12px';

                        var contentHtml = '';

                        if (msg.msgType === 'voice') {
                            // 语音消息
                            contentHtml = '<div style="display:flex;align-items:center;gap:8px;">'
                                + '<span style="font-size:18px;">&#x1F3B5;</span>'
                                + '<span style="font-size:13px;">' + app.escapeHtml(msg.duration || '') + '</span>'
                                + '</div>'
                                + (msg.transcript ? '<div style="font-size:12px;color:' + (isIncoming ? '#8a8a9a' : 'rgba(255,255,255,0.7)') + ';margin-top:4px;padding-top:4px;border-top:1px solid ' + (isIncoming ? '#2e2e3e' : 'rgba(255,255,255,0.2)') + ';">语音转文字: ' + app.escapeHtml(msg.transcript) + '</div>' : '');
                        } else if (msg.msgType === 'image') {
                            // 图片消息
                            var images = msg.images || [];
                            var imgParts = [];
                            for (var k = 0; k < images.length; k++) {
                                imgParts.push('<div style="font-size:13px;color:' + (isIncoming ? '#bbb' : 'rgba(255,255,255,0.85)') + ';padding:6px 8px;border:1px dashed ' + (isIncoming ? '#3a3a4a' : 'rgba(255,255,255,0.3)') + ';border-radius:6px;margin-bottom:4px;">&#x1F5BC; ' + app.escapeHtml(images[k].desc || '') + '</div>');
                            }
                            contentHtml = imgParts.join('');
                        } else {
                            // 纯文字消息
                            contentHtml = '<span style="font-size:14px;white-space:pre-wrap;">' + app.escapeHtml(msg.text || '') + '</span>';
                        }

                        // 状态标记（已读/未读）
                        var statusHtml = '';
                        if (!isIncoming && msg.status) {
                            statusHtml = '<span style="font-size:11px;color:rgba(255,255,255,0.5);margin-left:6px;">' + app.escapeHtml(msg.status) + '</span>';
                        }

                        // 时间戳
                        var timeHtml = msg.time
                            ? '<div style="font-size:11px;color:var(--ml-text-dimmer);text-align:' + align + ';margin-top:3px;">' + app.escapeHtml(msg.time) + '</div>'
                            : '';

                        messagesHtml += hiddenComment
                            + '<div style="text-align:' + align + ';margin-bottom:10px;">'
                            + '<div style="display:inline-block;max-width:80%;text-align:left;padding:10px 14px;border-radius:' + borderRadius + ';background:' + bubbleBg + ';color:' + bubbleColor + ';">'
                            + contentHtml
                            + statusHtml
                            + '</div>'
                            + timeHtml
                            + '</div>';
                    }
                    messagesHtml += '</div>';
                } else {
                    messagesHtml = '<div style="text-align:center;padding:30px;color:var(--ml-text-dim);font-size:13px;">暂无消息，发送第一条消息开始聊天</div>';
                }

                // 4. 底部输入框
                var inputHtml = '<div style="display:flex;gap:8px;padding:10px 0;border-top:1px solid #1e1e2e;margin-top:auto;">'
                    + '<input id="mlife-dm-input" type="text" placeholder="输入消息..." style="flex:1;padding:10px 14px;border-radius:20px;border:1px solid #2a2a3a;background:var(--ml-bg-info);color:var(--ml-text-main);font-size:14px;outline:none;font-family:inherit;" onkeydown="if(event.key===\'Enter\')document.getElementById(\'mlife-dm-send\').click()">'
                    + '<button id="mlife-dm-send" onclick="(function(){var input=document.getElementById(\'mlife-dm-input\');var text=input.value.trim();if(!text)return;MlifeApp.action(\'/send 回复' + app.escapeHtml(data.contact) + ':\'+text+\'|/trigger\');})()" style="width:44px;height:44px;border-radius:50%;border:none;background:#ff6b9d;color:#fff;font-size:18px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-family:inherit;flex-shrink:0;">&#x27A4;</button>'
                    + '</div>';

                var html = '<div style="display:flex;flex-direction:column;height:100%;min-height:0;">'
                    + headerHtml
                    + '<div style="flex:1;overflow-y:auto;overflow-x:hidden;padding-right:4px;min-height:0;">'
                    + unboxBtnHtml
                    + messagesHtml
                    + '</div>'
                    + inputHtml
                    + '</div>';

                // 5. 缓存
                MlifeApp.updateCache('dm', html);
                return html;
            };
