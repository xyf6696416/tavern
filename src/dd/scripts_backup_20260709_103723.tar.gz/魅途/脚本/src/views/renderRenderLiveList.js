
            app.renderLiveList = function(data) {
                if (!data || !data.rooms || data.rooms.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无直播</div>';
                }

                var rooms = data.rooms;
                var cards = [];

                for (var i = 0; i < rooms.length; i++) {
                    var r = rooms[i];
                    var hiddenComment = '<!-- hidden: ' + (r.hidden || '') + ' -->\n';

                    // 状态标签颜色
                    var statusColor = '#ff4757';
                    if (r.status === '即将开播') statusColor = '#ffa502';
                    else if (r.status === '回放') statusColor = '#2ed573';

                    // VIP 标签
                    var vipHtml = '';
                    if (r.vip && r.vip !== '无') {
                        vipHtml = '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;">' + app.escapeHtml(r.vip) + '</span>';
                    }

                    // 标签列表
                    var tagsHtml = '';
                    if (r.tags && r.tags.length > 0) {
                        tagsHtml = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:6px;">';
                        for (var j = 0; j < r.tags.length; j++) {
                            tagsHtml += '<span style="font-size:11px;padding:2px 8px;border-radius:10px;background:var(--ml-bg-section);border:1px solid var(--ml-border);color:var(--ml-text-aaa);">' + app.escapeHtml(r.tags[j]) + '</span>';
                        }
                        tagsHtml += '</div>';
                    }

                    // 预览
                    var previewHtml = '';
                    if (r.preview) {
                        previewHtml = '<div style="font-size:13px;color:#888;margin-top:6px;padding:8px;background:var(--ml-bg-info);border-radius:6px;border-left:3px solid #ff6b9d;line-height:1.5;">'
                            + '<span style="color:var(--ml-accent);margin-right:4px;">&#x1F4F7;</span>'
                            + app.escapeHtml(r.preview)
                            + '</div>';
                    }

                    var cardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;cursor:pointer;" onclick="MlifeApp.action(\'/send 进入' + encodeURIComponent(r.name || '') + '的直播间|/trigger\')">'
                        + hiddenComment
                        // 头像 + 主播名 + 在线人数行
                        + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">'
                        + '<span style="font-size:36px;width:44px;text-align:center;line-height:44px;">' + (r.avatar || '') + '</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                        + '<span style="font-weight:bold;font-size:15px;color:var(--ml-text);">' + app.escapeHtml(r.name || '') + '</span>'
                        + '<span style="font-size:11px;padding:2px 8px;border-radius:10px;background:' + statusColor + ';color:#fff;font-weight:bold;">' + app.escapeHtml(r.status || '') + '</span>'
                        + vipHtml
                        + '</div>'
                        + '<div style="font-size:12px;color:var(--ml-text-dim);margin-top:3px;display:flex;align-items:center;gap:4px;">'
                        + '<span style="color:var(--ml-accent);">&#x1F4E1;</span> '
                        + '<span>' + (r.viewers || 0) + ' 人在看</span>'
                        + '</div>'
                        + '</div>'
                        + '</div>'
                        // 标题
                        + '<div style="font-size:14px;color:var(--ml-text-main);font-weight:500;margin-bottom:4px;">' + app.escapeHtml(r.title || '') + '</div>'
                        // 预览
                        + previewHtml
                        // 标签
                        + tagsHtml
                        + '</div>';

                    cards.push(cardHtml);
                }

                var html = '<div style="padding:0;">' + cards.join('\n') + '</div>';
                MlifeApp.updateCache('live_list', html);
                return html;
            };
