
            app.renderRecruitManage = function(data) {
                var tab = (data && data.tab === '我报名的') ? 'myApplications' : 'myRecruits';
                var allFilters = ['全部', '招募中', '已锁定', '已完成', '已取消'];
                var currentFilter = (data && data._filter) || '全部';

                var myRecruits = app.getRecruitPosts();
                var myApplications = JSON.parse(mlifeStorage.get(STORAGE_KEYS.RECRUIT_APPLICATIONS) || '[]');

                var statusColorMap = STATUS_COLORS;

                function makeStatusTag(status) {
                    var color = statusColorMap[status] || '#9ca3af';
                    var rgb = app.hexToRgb(color);
                    return '<span style="font-size:11px;padding:2px 8px;border-radius:4px;background:rgba(' + rgb + ',0.1);color:' + color + ';border:1px solid rgba(' + rgb + ',0.2);font-weight:500;">' + app.escapeHtml(status) + '</span>';
                }

                function makeItemList(items, emptyText) {
                    if (!items || items.length === 0) {
                        return '<div style="padding:32px 20px;text-align:center;"><div style="font-size:32px;margin-bottom:10px;opacity:0.5;">\ud83d\udccb</div><div style="font-size:14px;color:#6a6a70;">' + app.escapeHtml(emptyText) + '</div></div>';
                    }
                    var filtered = items;
                    if (currentFilter !== '全部') {
                        filtered = [];
                        for (var fi = 0; fi < items.length; fi++) {
                            if (items[fi].status && items[fi].status.indexOf(currentFilter) >= 0) filtered.push(items[fi]);
                        }
                    }
                    var listHtml = '';
                    for (var i = 0; i < filtered.length; i++) {
                        var item = filtered[i];
                        listHtml += '<div onclick="MlifeApp.navigate(\'recruit_detail_local\',{postId:\'' + item.id + '\'})" style="background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:10px;padding:12px 14px;margin-bottom:8px;cursor:pointer;" onmouseover="this.style.borderColor=\'rgba(201,169,110,0.3)\';this.style.background=\'#2a2a32\'" onmouseout="this.style.borderColor=\'rgba(201,169,110,0.12)\';this.style.background=\'#222228\'">'
                            + '<div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:6px;">'
                            + '<div style="display:flex;align-items:center;gap:6px;">'
                            + '<span style="font-size:16px;">' + (item.typeIcon || '\ud83d\udccb') + '</span>'
                            + '<span style="font-weight:600;font-size:14px;color:#e5e5e7;">' + app.escapeHtml(item.title) + '</span>'
                            + (item.id ? '<span style="font-size:10px;color:#6a6a70;margin-left:4px;">#' + app.escapeHtml(item.id) + '</span>' : '')
                            + '</div>'
                            + makeStatusTag(item.status)
                            + '</div>'
                            + (item.poster ? '<div style="font-size:11px;color:#9a9a9f;margin-bottom:4px;">' + app.escapeHtml(item.poster) + '</div>' : '')
                            + (item.recruitType ? '<div style="font-size:11px;color:#6a6a70;margin-bottom:6px;">' + app.escapeHtml(item.recruitType) + '</div>' : '')
                            + '<div style="display:flex;gap:10px;font-size:11px;color:#9a9a9f;margin-bottom:6px;">'
                            + '<span>\ud83d\udd50 ' + app.escapeHtml(item.time || '') + '</span>'
                            + (item.reward ? '<span style="color:#c9a96e;font-weight:600;">' + app.escapeHtml(item.reward) + '</span>' : '')
                            + '</div>'
                            + (item.progress ? '<div style="font-size:12px;color:#6a6a70;padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:6px;line-height:1.4;">' + app.escapeHtml(item.progress) + '</div>' : '')
                            + '</div>';
                    }
                    if (filtered.length === 0) {
                        return '<div style="padding:32px 20px;text-align:center;"><div style="font-size:32px;margin-bottom:10px;opacity:0.5;">\ud83d\udccb</div><div style="font-size:14px;color:#6a6a70;">暂无符合条件的订单</div></div>';
                    }
                    return listHtml;
                }

                var tabHtml = '<div style="display:flex;background:#1a1a1f;border-bottom:1px solid rgba(201,169,110,0.12);">'
                    + '<button onclick="MlifeApp.navigate(\'recruit_manage\',{tab:\'我发布的\',_filter:\'' + currentFilter + '\'})" style="flex:1;padding:10px 0;text-align:center;font-size:14px;font-weight:500;cursor:pointer;background:none;border:none;border-bottom:2px solid ' + (tab === 'myRecruits' ? '#c9a96e' : 'transparent') + ';color:' + (tab === 'myRecruits' ? '#c9a96e' : '#9a9a9f') + ';font-family:inherit;">我发布的</button>'
                    + '<button onclick="MlifeApp.navigate(\'recruit_manage\',{tab:\'我报名的\',_filter:\'' + currentFilter + '\'})" style="flex:1;padding:10px 0;text-align:center;font-size:14px;font-weight:500;cursor:pointer;background:none;border:none;border-bottom:2px solid ' + (tab === 'myApplications' ? '#c9a96e' : 'transparent') + ';color:' + (tab === 'myApplications' ? '#c9a96e' : '#9a9a9f') + ';font-family:inherit;">我报名的</button>'
                    + '</div>';

                var filterHtml = '<div style="padding:8px 12px;background:#1a1a1f;border-bottom:1px solid rgba(201,169,110,0.12);display:flex;gap:6px;overflow-x:auto;">';
                for (var fi = 0; fi < allFilters.length; fi++) {
                    var f = allFilters[fi];
                    filterHtml += '<span onclick="MlifeApp.navigate(\'recruit_manage\',{tab:\'' + (tab === 'myRecruits' ? '我发布的' : '我报名的') + '\',_filter:\'' + f + '\'})" style="padding:3px 10px;border-radius:12px;font-size:11px;white-space:nowrap;cursor:pointer;background:' + (f === currentFilter ? 'rgba(201,169,110,0.15)' : '#222228') + ';color:' + (f === currentFilter ? '#c9a96e' : '#9a9a9f') + ';border:1px solid ' + (f === currentFilter ? '#c9a96e' : 'transparent') + ';">' + f + '</span>';
                }
                filterHtml += '</div>';

                var listHtml = tab === 'myRecruits'
                    ? makeItemList(myRecruits, '暂无发布的招募')
                    : makeItemList(myApplications, '暂无报名的招募');

                return '<div style="padding:0;">'
                    + '<div style="background:linear-gradient(135deg,#1a1a1f,#222228);padding:14px 16px;border-bottom:1px solid rgba(201,169,110,0.12);display:flex;align-items:center;gap:10px;">'
                    + '<span style="font-size:20px;width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#c9a96e,#8b7340);display:flex;align-items:center;justify-content:center;flex-shrink:0;">\ud83d\udc8e</span>'
                    + '<div><div style="font-weight:600;font-size:15px;color:#e5e5e7;">我的管理</div>'
                    + '<div style="font-size:11px;color:#9a9a9f;">黑金之选</div></div></div>'
                    + tabHtml + filterHtml
                    + '<div style="padding:12px 16px;background:#1a1a1f;min-height:200px;">' + listHtml + '</div></div>';
            };
