
            app.renderRecruitDetail = function(data) {
                if (!data || !data.code) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;letter-spacing:0.06em;">招募详情不可用</div>';
                }

                var r = data;

                // 状态标签
                var statusColors = {
                    '招募中': '#34d399',
                    '已锁定': '#60a5fa',
                    '已完成': '#34d399',
                    '已取消': '#9ca3af',
                    '争议中': '#f87171'
                };
                var statusColor = statusColors[r.status] || '#9ca3af';
                var statusLabel = '<span style="font-size:11px;padding:3px 10px;border-radius:4px;background:rgba(' + app.hexToRgb(statusColor) + ',0.1);color:' + statusColor + ';border:1px solid rgba(' + app.hexToRgb(statusColor) + ',0.2);font-weight:500;">' + app.escapeHtml(r.status) + '</span>';

                // 标签列表
                var tagsHtml = '';
                if (r.tags && r.tags.length > 0) {
                    tagsHtml = '<div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:12px;">';
                    for (var j = 0; j < r.tags.length; j++) {
                        tagsHtml += '<span style="font-size:11px;padding:2px 10px;border-radius:12px;border:1px solid rgba(201,169,110,0.2);color:#c9a96e;background:rgba(201,169,110,0.1);">' + app.escapeHtml(r.tags[j]) + '</span>';
                    }
                    tagsHtml += '</div>';
                }

                // Play标签
                var playTagsHtml = '';
                if (r.playTags && r.playTags.length > 0) {
                    playTagsHtml = '<div style="margin-bottom:12px;">';
                    playTagsHtml += '<div style="font-size:11px;color:#6a6a70;margin-bottom:4px;">PLAY 标签</div><div style="display:flex;flex-wrap:wrap;gap:4px;">';
                    for (var pt = 0; pt < r.playTags.length; pt++) {
                        playTagsHtml += '<span style="font-size:11px;padding:2px 8px;border-radius:10px;background:rgba(201,169,110,0.08);color:#c9a96e;border:1px solid rgba(201,169,110,0.15);">' + app.escapeHtml(r.playTags[pt]) + '</span>';
                    }
                    playTagsHtml += '</div></div>';
                }

                // 隐藏描述
                var hiddenHtml = r.hidden ? '<div style="font-size:11px;color:#6a6a70;font-style:italic;padding:10px 16px;line-height:1.4;background:rgba(201,169,110,0.04);border-bottom:1px dashed rgba(255,255,255,0.05);">' + app.escapeHtml(r.hidden) + '</div>' : '';

                // 发布者信息栏
                var publisherAvatar = r.avatar || '💎';
                var publisherCode = r.poster || r.code || '';
                var publisherHtml = '<div style="display:flex;align-items:center;gap:12px;padding:14px 16px;background:linear-gradient(135deg,#1a1a1f,#222228);border-bottom:1px solid rgba(201,169,110,0.12);">'
                    + '<span style="font-size:24px;width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,#c9a96e,#8b7340);display:flex;align-items:center;justify-content:center;flex-shrink:0;">' + publisherAvatar + '</span>'
                    + '<div style="flex:1;min-width:0;">'
                    + '<div style="font-weight:600;font-size:15px;color:#e5e5e7;">' + app.escapeHtml(publisherCode) + '</div>'
                    + '<div style="display:flex;gap:12px;margin-top:4px;font-size:11px;color:#9a9a9f;">'
                    + (r.credit ? '<span>信用分 ' + app.escapeHtml(r.credit) + '</span>' : '')
                    + (r.rating ? '<span style="color:#c9a96e;">' + app.escapeHtml(r.rating) + '</span>' : '')
                    + (r.history ? '<span>' + app.escapeHtml(r.history) + '</span>' : '')
                    + '</div></div></div>';

                // 信息网格
                var infoGridHtml = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:14px 16px;background:#1a1a1f;border-bottom:1px solid rgba(201,169,110,0.12);">';
                infoGridHtml += '<div style="grid-column:1/-1;background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);">'
                    + '<div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">招募标题</div>'
                    + '<div style="font-size:14px;color:#e5e5e7;font-weight:500;">' + (r.typeIcon || '') + ' ' + app.escapeHtml(r.title) + '</div>'
                    + '</div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">招募类型</div><div style="font-size:13px;color:#e5e5e7;">' + (r.recruitType || '—') + '</div></div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">状态</div>' + statusLabel + '</div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">人数</div><div style="font-size:13px;color:#e5e5e7;">' + (r.count || '1') + '人</div></div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">执行时间</div><div style="font-size:13px;color:#e5e5e7;">' + (r.time || '—') + '</div></div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">城市</div><div style="font-size:13px;color:#e5e5e7;">' + (r.city || '—') + '</div></div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">时长</div><div style="font-size:13px;color:#e5e5e7;">' + (r.duration || '—') + '</div></div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">发布时间</div><div style="font-size:13px;color:#e5e5e7;">' + (r.publishTime || r.time || '—') + '</div></div>';
                infoGridHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">有效期</div><div style="font-size:13px;color:#e5e5e7;">' + (r.expire || '7天') + '</div></div>';
                infoGridHtml += '</div>';

                // 详细要求
                var reqHtml = '<div style="padding:14px 16px;background:#1a1a1f;border-bottom:1px solid rgba(201,169,110,0.12);">'
                    + '<div style="font-size:11px;font-weight:600;color:#c9a96e;margin-bottom:10px;letter-spacing:1px;">📝 详细要求</div>';
                if (r.ageReq) reqHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);margin-bottom:6px;"><div style="font-size:10px;color:#6a6a70;margin-bottom:3px;">年龄要求</div><div style="font-size:13px;color:#e5e5e7;">' + app.escapeHtml(r.ageReq) + '</div></div>';
                if (r.bodyPref) reqHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);margin-bottom:6px;"><div style="font-size:10px;color:#6a6a70;margin-bottom:3px;">身材偏好</div><div style="font-size:13px;color:#e5e5e7;">' + app.escapeHtml(r.bodyPref) + '</div></div>';
                if (r.specialReq) reqHtml += '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);margin-bottom:6px;"><div style="font-size:10px;color:#6a6a70;margin-bottom:3px;">特殊要求</div><div style="font-size:13px;color:#e5e5e7;">' + app.escapeHtml(r.specialReq) + '</div></div>';
                if (r.body) reqHtml += '<div style="background:#222228;border-radius:8px;padding:12px;border:1px solid rgba(201,169,110,0.12);"><div style="font-size:10px;color:#6a6a70;margin-bottom:4px;">详情描述</div><div style="font-size:13px;color:var(--ml-text-ccc);line-height:1.6;white-space:pre-wrap;">' + app.escapeHtml(r.body) + '</div></div>';
                reqHtml += '</div>';

                // 报酬明细
                var rewardHtml = '<div style="padding:14px 16px;background:#1a1a1f;border-bottom:1px solid rgba(201,169,110,0.12);">'
                    + '<div style="font-size:11px;font-weight:600;color:#c9a96e;margin-bottom:10px;letter-spacing:1px;">💰 报酬明细</div>';
                if (r.singleReward || r.reward) rewardHtml += '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04);"><span style="font-size:12px;color:#9a9a9f;">单人报酬</span><span style="font-size:13px;font-weight:600;color:#c9a96e;">' + app.escapeHtml(r.singleReward || r.reward) + '</span></div>';
                if (r.totalReward) rewardHtml += '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04);"><span style="font-size:12px;color:#9a9a9f;">总报酬</span><span style="font-size:13px;color:#e5e5e7;">' + app.escapeHtml(r.totalReward) + '</span></div>';
                if (r.serviceFee) rewardHtml += '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04);"><span style="font-size:12px;color:#9a9a9f;">平台服务费</span><span style="font-size:13px;color:#f87171;">' + app.escapeHtml(r.serviceFee) + '</span></div>';
                if (r.deposit) rewardHtml += '<div style="display:flex;justify-content:space-between;padding:8px 0;"><span style="font-size:12px;color:#9a9a9f;">押金状态</span><span style="font-size:13px;color:#e5e5e7;">' + app.escapeHtml(r.deposit) + '</span></div>';
                rewardHtml += '</div>';

                // 应征者列表
                var applicantsHtml = '';
                if (r.applicants && r.applicants.length > 0) {
                    applicantsHtml = '<div style="padding:14px 16px;background:#1a1a1f;border-bottom:1px solid rgba(201,169,110,0.12);">'
                        + '<div style="font-size:11px;font-weight:600;color:#c9a96e;margin-bottom:10px;letter-spacing:1px;">📋 应征者列表（' + r.applicants.length + '人）</div>';
                    for (var k = 0; k < r.applicants.length; k++) {
                        var a = r.applicants[k];
                        var aStatusColor = a.status === '待审核' ? '#fbbf24' : a.status === '已确认' || a.status === '已选中' ? '#34d399' : '#6a6a70';
                        applicantsHtml += '<div style="background:#222228;border-radius:8px;padding:12px;border:1px solid rgba(201,169,110,0.12);margin-bottom:8px;">'
                            + '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">'
                            + '<span style="font-weight:600;font-size:13px;color:#e5e5e7;">' + app.escapeHtml(a.name || a.code || '') + '</span>'
                            + '<span style="font-size:11px;padding:2px 8px;border-radius:4px;background:rgba(' + app.hexToRgb(aStatusColor) + ',0.1);color:' + aStatusColor + ';border:1px solid rgba(' + app.hexToRgb(aStatusColor) + ',0.2);">' + app.escapeHtml(a.status) + '</span>'
                            + '</div>';
                        if (a.age || a.body || a.rating || a.orders) {
                            applicantsHtml += '<div style="display:flex;gap:10px;margin-bottom:6px;font-size:11px;color:#9a9a9f;">'
                                + (a.age ? '<span>' + a.age + '岁</span>' : '')
                                + (a.body ? '<span>' + app.escapeHtml(a.body) + '</span>' : '')
                                + (a.rating ? '<span>评分 ' + app.escapeHtml(a.rating) + '</span>' : '')
                                + (a.orders ? '<span>' + app.escapeHtml(a.orders) + '</span>' : '')
                                + '</div>';
                        }
                        if (a.note) applicantsHtml += '<div style="font-size:12px;color:#6a6a70;padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:4px;margin-bottom:6px;">' + app.escapeHtml(a.note) + '</div>';
                        if (a.ops) {
                            var ops = a.ops.split('/');
                            applicantsHtml += '<div style="display:flex;gap:6px;">';
                            for (var oi = 0; oi < ops.length; oi++) {
                                var op = ops[oi].trim();
                                if (op === '无') continue;
                                var opClass = op.indexOf('私信') !== -1 ? 'background:rgba(255,255,255,0.06);color:#9a9a9f;border:1px solid rgba(255,255,255,0.1);' : op.indexOf('确认') !== -1 || op.indexOf('选择') !== -1 ? 'background:rgba(52,211,153,0.15);color:#34d399;border:1px solid rgba(52,211,153,0.25);' : op.indexOf('拒绝') !== -1 ? 'background:rgba(248,113,113,0.1);color:#f87171;border:1px solid rgba(248,113,113,0.2);' : 'background:rgba(255,255,255,0.06);color:#9a9a9f;border:1px solid rgba(255,255,255,0.1);';
                                var sendText = op.indexOf('私信') !== -1 ? '/send 私信应征者 ' + (a.code || a.name) + '|/trigger'
                                    : op.indexOf('确认') !== -1 || op.indexOf('选择') !== -1 ? '/send 确认选择应征者 ' + (a.code || a.name) + '|/trigger'
                                    : op.indexOf('拒绝') !== -1 ? '/send 拒绝应征者 ' + (a.code || a.name) + '|/trigger'
                                    : '';
                                if (sendText) {
                                    applicantsHtml += '<button onclick="MlifeApp.action(\'' + sendText + '\')" style="padding:4px 10px;border-radius:6px;font-size:11px;font-weight:500;border:none;cursor:pointer;' + opClass + 'font-family:inherit;">' + app.escapeHtml(op) + '</button>';
                                } else {
                                    applicantsHtml += '<span style="padding:4px 10px;border-radius:6px;font-size:11px;font-weight:500;' + opClass + '">' + app.escapeHtml(op) + '</span>';
                                }
                            }
                            applicantsHtml += '</div>';
                        }
                        applicantsHtml += '</div>';
                    }
                    applicantsHtml += '</div>';
                }

                // 操作按钮
                var btnText = r.btnText || '报名应征';
                var btnHint = r.btnHint || '';
                var isDisabled = btnText.indexOf('无权限') !== -1 || btnText.indexOf('已报名') !== -1;
                var sendAction = isDisabled ? '' : btnText.indexOf('查看报名列表') !== -1
                    ? '/send 查看报名列表 ' + r.code + '|/trigger'
                    : '/send 报名应征 ' + r.code + '|/trigger';

                var actionHtml = '<div style="padding:14px 16px;display:flex;gap:10px;">'
                    + '<button onclick="MlifeApp.action(\'/send 返回招募广场|/trigger\')" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(201,169,110,0.2);background:transparent;color:#9a9a9f;font-size:13px;cursor:pointer;font-family:inherit;transition:all 0.2s;">返回</button>'
                    + (sendAction ? '<button onclick="MlifeApp.action(\'' + sendAction + '\')" style="flex:2;padding:10px;border-radius:8px;border:1px solid #c9a96e;background:linear-gradient(135deg,rgba(201,169,110,0.2),rgba(201,169,110,0.3));color:#c9a96e;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:all 0.2s;">' + app.escapeHtml(btnText) + '</button>' : '<button disabled style="flex:2;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.06);background:rgba(255,255,255,0.04);color:#6a6a70;font-size:13px;font-family:inherit;cursor:not-allowed;">' + app.escapeHtml(btnText) + '</button>')
                    + '</div>';
                if (btnHint) actionHtml += '<div style="font-size:11px;color:#6a6a70;text-align:center;padding:0 16px 12px;">' + app.escapeHtml(btnHint) + '</div>';

                var html = '<div style="padding:0;">'
                    + hiddenHtml
                    + publisherHtml
                    + infoGridHtml
                    + tagsHtml
                    + playTagsHtml
                    + reqHtml
                    + rewardHtml
                    + applicantsHtml
                    + actionHtml
                    + '</div>';

                MlifeApp.updateCache('recruit_detail', html);
                return html;
            };
