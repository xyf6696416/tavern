
            app.renderMatch = function(data) {
                if (!data || !data.cards || data.cards.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无推荐</div>';
                }

                var cards = data.cards;
                var cardsHtml = [];

                for (var i = 0; i < cards.length; i++) {
                    var c = cards[i];
                    var hiddenComment = '<!-- hidden: ' + (c.hidden || '') + ' -->\n';

                    // 头像 + 昵称行
                    var headerHtml = '<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">'
                        + '<span style="font-size:40px;width:48px;text-align:center;line-height:48px;flex-shrink:0;">' + (c.avatar || '') + '</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                        + '<span style="font-weight:bold;font-size:16px;color:var(--ml-text);">' + app.escapeHtml(c.nick || '') + '</span>'
                        + (c.vip && c.vip !== '无'
                            ? '<span style="font-size:11px;padding:2px 8px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;">' + app.escapeHtml(c.vip) + '</span>'
                            : '')
                        + '</div>'
                        + '<div style="font-size:13px;color:var(--ml-text-dim);margin-top:4px;display:flex;gap:10px;">'
                        + '<span>' + (c.age || '--') + '岁</span>'
                        + '<span>&middot;</span>'
                        + '<span>' + app.escapeHtml(c.distance || '') + '</span>'
                        + '<span>&middot;</span>'
                        + '<span>' + app.escapeHtml(c.active || '') + '</span>'
                        + '</div>'
                        + '</div>'
                        + '</div>';

                    // bio 简介
                    var bioHtml = c.bio
                        ? '<div style="font-size:14px;color:var(--ml-text-bbb);line-height:1.5;margin-bottom:12px;padding:10px 12px;background:var(--ml-bg-info);border-radius:8px;border:1px solid #1a1a2e;">'
                            + app.escapeHtml(c.bio) + '</div>'
                        : '';

                    // 标签列表（flex wrap）
                    var tagsHtml = '';
                    if (c.tags && c.tags.length > 0) {
                        tagsHtml = '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;">';
                        for (var j = 0; j < c.tags.length; j++) {
                            var tag = c.tags[j];
                            var tagColors = ['#ff6b9d','#00e5ff','#f6d365','#7c6bff','#50e3c2','#ff9f43'];
                            var tagColor = tagColors[j % tagColors.length];
                            tagsHtml += '<span style="display:inline-block;padding:4px 10px;border-radius:14px;background:rgba('
                                + (tagColor === '#ff6b9d' ? '255,107,157'
                                    : tagColor === '#00e5ff' ? '0,229,255'
                                    : tagColor === '#f6d365' ? '246,211,101'
                                    : tagColor === '#7c6bff' ? '124,107,255'
                                    : tagColor === '#50e3c2' ? '80,227,194'
                                    : '255,159,67') + ',0.15);'
                                + 'color:' + tagColor + ';font-size:12px;border:1px solid ' + tagColor + ';">'
                                + app.escapeHtml(tag) + '</span>';
                        }
                        tagsHtml += '</div>';
                    }

                    // 点赞数
                    var likesHtml = '<div style="margin-bottom:12px;font-size:13px;color:var(--ml-text-dim);display:flex;align-items:center;gap:4px;">'
                        + '<span style="color:var(--ml-accent);">&#x2764;</span> '
                        + (c.likes || 0) + ' 人感兴趣</div>';

                    // 操作按钮
                    var actionsHtml = '<div style="display:flex;gap:10px;">'
                        + '<button onclick="MlifeApp.action(\'/send 跳过|/trigger\')" style="flex:1;padding:10px;border-radius:10px;border:1px solid #3a3a4a;background:#16161e;color:var(--ml-text-dim);font-size:14px;cursor:pointer;font-family:inherit;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:6px;">'
                        + '<span style="font-size:16px;">&#x2715;</span> 跳过</button>'
                        + '<button onclick="MlifeApp.action(\'/send 感兴趣|/trigger\')" style="flex:1;padding:10px;border-radius:10px;border:1px solid #ff6b9d;background:var(--ml-glow-10);color:var(--ml-accent);font-size:14px;cursor:pointer;font-family:inherit;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:6px;">'
                        + '<span style="font-size:16px;">&#x2665;</span> 感兴趣</button>'
                        + '</div>';

                    // 组装卡片
                    var cardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:14px;padding:16px;margin-bottom:14px;">'
                        + hiddenComment
                        + headerHtml
                        + bioHtml
                        + tagsHtml
                        + likesHtml
                        + actionsHtml
                        + '</div>';

                    cardsHtml.push(cardHtml);
                }

                var html = '<div style="padding:0;">' + cardsHtml.join('\n') + '</div>';
                MlifeApp.updateCache('match', html);
                return html;
            };
