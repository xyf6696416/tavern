
            app.renderLive = function(data) {
                if (!data) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">直播间加载中...</div>';
                }

                var hiddenComment = '<!-- hidden: ' + (data.hidden || '') + ' -->\n';

                // 主播信息头部
                var headerHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                    + hiddenComment
                    + '<div style="display:flex;align-items:center;gap:10px;">'
                    + '<span style="font-size:40px;width:48px;text-align:center;line-height:48px;">' + (data.avatar || '') + '</span>'
                    + '<div style="flex:1;min-width:0;">'
                    + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                    + '<span style="font-weight:bold;font-size:16px;color:var(--ml-text);">' + app.escapeHtml(data.name || '') + '</span>'
                    + (data.level ? '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(data.level) + '</span>' : '')
                    + '<span style="font-size:11px;padding:2px 8px;border-radius:10px;background:#ff4757;color:#fff;font-weight:bold;">' + app.escapeHtml(data.status || '直播中') + '</span>'
                    + '</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);margin-top:3px;display:flex;align-items:center;gap:4px;">'
                    + '<span style="color:var(--ml-accent);">&#x1F4E1;</span> '
                    + '<span>' + (data.viewers || 0) + ' 人在看</span>'
                    + '<span style="margin-left:10px;color:var(--ml-cyan);">&#x1F3A5;</span> '
                    + '<span>' + app.escapeHtml(data.title || '') + '</span>'
                    + '</div>'
                    + '</div>'
                    + '</div>'
                    + '</div>';

                // 场景描述
                var sceneHtml = '';
                if (data.scene) {
                    sceneHtml = '<div style="background:var(--ml-bg-info);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;border-left:3px solid #ff6b9d;">'
                        + '<div style="font-size:12px;color:var(--ml-accent);font-weight:bold;margin-bottom:6px;letter-spacing:0.05em;">&#x1F3AC; 直播间画面</div>'
                        + '<div style="font-size:14px;color:var(--ml-text-ccc);line-height:1.7;">' + app.escapeHtml(data.scene) + '</div>'
                        + '</div>';
                }

                // 弹幕列表
                var danmakuHtml = '';
                if (data.danmaku && data.danmaku.length > 0) {
                    danmakuHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                        + '<div style="font-size:12px;color:var(--ml-cyan);font-weight:bold;margin-bottom:8px;letter-spacing:0.05em;">&#x1F4AC; 弹幕</div>'
                        + '<div style="max-height:200px;overflow-y:auto;">';
                    for (var di = 0; di < data.danmaku.length; di++) {
                        var d = data.danmaku[di];
                        var vipBadge = '';
                        if (d.vip && d.vip !== '无') {
                            vipBadge = '<span style="font-size:10px;padding:0 5px;border-radius:2px;background:var(--ml-gold);color:#1a1a1a;margin-left:4px;">' + app.escapeHtml(d.vip) + '</span>';
                        }
                        danmakuHtml += '<div style="padding:6px 0;' + (di > 0 ? 'border-top:1px solid #1e1e2e;' : '') + 'font-size:13px;color:var(--ml-text-ccc);display:flex;align-items:flex-start;gap:4px;">'
                            + '<span style="color:var(--ml-accent);font-weight:bold;white-space:nowrap;">' + app.escapeHtml(d.name || '') + '</span>'
                            + vipBadge
                            + '<span style="color:var(--ml-text-dim);">:</span>'
                            + '<span>' + app.escapeHtml(d.text || '') + '</span>'
                            + '</div>';
                    }
                    danmakuHtml += '</div></div>';
                }

                // 礼物列表
                var giftsHtml = '';
                if (data.gifts && data.gifts.length > 0) {
                    giftsHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                        + '<div style="font-size:12px;color:#f6d365;font-weight:bold;margin-bottom:8px;letter-spacing:0.05em;">&#x1F381; 礼物</div>';
                    for (var gi = 0; gi < data.gifts.length; gi++) {
                        var g = data.gifts[gi];
                        giftsHtml += '<div style="display:flex;align-items:center;gap:6px;padding:6px 0;' + (gi > 0 ? 'border-top:1px solid #1e1e2e;' : '') + 'font-size:13px;">'
                            + '<span style="color:#f6d365;">&#x2B50;</span>'
                            + '<span style="color:var(--ml-text);font-weight:bold;">' + app.escapeHtml(g.name || '') + '</span>'
                            + '<span style="color:var(--ml-text-dim);">送出</span>'
                            + '<span style="color:#f6d365;font-weight:bold;">' + app.escapeHtml(g.gift || '') + '</span>'
                            + (g.value ? '<span style="color:var(--ml-accent);margin-left:4px;">(' + app.escapeHtml(g.value) + ')</span>' : '')
                            + '</div>';
                    }
                    giftsHtml += '</div>';
                }

                // 底部操作
                var actionsHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;display:flex;gap:8px;">'
                    + '<input type="text" placeholder="发送弹幕..." id="danmaku-input" style="flex:1;padding:10px 12px;border-radius:8px;border:1px solid var(--ml-border);background:#0a0a14;color:var(--ml-text-main);font-size:13px;font-family:inherit;outline:none;" onkeypress="if(event.key===\'Enter\'){var v=this.value;if(v){MlifeApp.action(\'/send 发送弹幕:\' + v + \'|/trigger\');this.value=\'\';}}">'
                    + '<button onclick="MlifeApp.action(\'/send 发送弹幕:\' + document.getElementById(\'danmaku-input\').value + \'|/trigger\');document.getElementById(\'danmaku-input\').value=\'\';" style="padding:10px 16px;border-radius:8px;border:none;background:#ff6b9d;color:#fff;font-size:13px;cursor:pointer;font-family:inherit;font-weight:bold;">发送</button>'
                    + '<button onclick="MlifeApp.action(\'/send 送礼物|/trigger\')" style="padding:10px 16px;border-radius:8px;border:1px solid #f6d365;background:#2a2010;color:#f6d365;font-size:13px;cursor:pointer;font-family:inherit;font-weight:bold;">&#x1F381; 送礼</button>'
                    + '</div>';

                var html = '<div style="padding:0;">'
                    + headerHtml
                    + sceneHtml
                    + danmakuHtml
                    + giftsHtml
                    + actionsHtml
                    + '</div>';

                MlifeApp.updateCache('live', html);
                return html;
            };
