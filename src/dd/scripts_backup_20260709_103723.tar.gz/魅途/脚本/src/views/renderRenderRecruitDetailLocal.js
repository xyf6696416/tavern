
            app.renderRecruitDetailLocal = function(postId) {
                var post = app.getRecruitPostById(postId);
                if (!post) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">招募已不存在</div>';
                }

                var statusColorMap = STATUS_COLORS;
                var sc = statusColorMap[post.status] || '#9ca3af';
                var sRgb = app.hexToRgb(sc);
                var statusTag = '<span style="font-size:12px;padding:2px 10px;border-radius:4px;background:rgba(' + sRgb + ',0.1);color:' + sc + ';border:1px solid rgba(' + sRgb + ',0.2);font-weight:500;">' + app.escapeHtml(post.status) + '</span>';

                // 应征者列表
                var applicantsHtml = '';
                var applicants = JSON.parse(mlifeStorage.get(STORAGE_KEYS.RECRUIT_APPLICANTS + post.id) || '[]');
                if (applicants.length === 0) {
                    applicantsHtml = '<div style="padding:24px;text-align:center;"><div style="font-size:32px;margin-bottom:8px;opacity:0.5;">📭</div><div style="font-size:13px;color:#6a6a70;">还没有人应征</div><div style="font-size:11px;color:#6a6a70;margin-top:4px;">发布后等待平台推荐应征者</div></div>';
                } else {
                    applicantsHtml = '<div style="display:flex;flex-direction:column;gap:8px;">';
                    for (var ai = 0; ai < applicants.length; ai++) {
                        var a = applicants[ai];
                        var aSc = statusColorMap[a.status] || '#9ca3af';
                        var aRgb = app.hexToRgb(aSc);
                        var aStatusTag = '<span style="font-size:10px;padding:1px 6px;border-radius:3px;background:rgba(' + aRgb + ',0.1);color:' + aSc + ';border:1px solid rgba(' + aRgb + ',0.2);">' + app.escapeHtml(a.status) + '</span>';

                        var tagsHtml = '';
                        if (a.tags && a.tags.length) {
                            tagsHtml = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin:4px 0;">';
                            for (var ti = 0; ti < a.tags.length; ti++) {
                                tagsHtml += '<span style="font-size:10px;padding:1px 6px;border-radius:3px;background:rgba(255,255,255,0.04);color:#9a9a9f;border:1px solid rgba(255,255,255,0.06);">' + app.escapeHtml(a.tags[ti]) + '</span>';
                            }
                            tagsHtml += '</div>';
                        }

                        // 状态为招募中才显示确认/拒绝按钮
                        var actionBtns = '';
                        if (post.status === '招募中') {
                            actionBtns = '<span onclick="if(confirm(\'确认选择' + app.escapeHtml(a.name) + '？\')){MlifeApp.cancelRecruitPost(\'' + post.id + '\');MlifeApp.navigate(\'recruit_manage\');}" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(52,211,153,0.15);color:#34d399;border:1px solid rgba(52,211,153,0.25);font-family:inherit;">✅ 确认</span>'
                            actionBtns = '<span onclick="MlifeApp.startDmWithApplicant(' + JSON.stringify(a).replace(/"/g, '&quot;') + ',' + JSON.stringify(post.title).replace(/"/g, '&quot;') + ')" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(96,165,250,0.1);color:#60a5fa;border:1px solid rgba(96,165,250,0.2);font-family:inherit;">💬 私信</span>'
                                + '<span onclick="MlifeApp.action(\'/send 拒绝 ' + app.escapeHtml(a.name) + '|/trigger\')" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(248,113,113,0.1);color:#f87171;border:1px solid rgba(248,113,113,0.2);font-family:inherit;">❌ 拒绝</span>';
                        } else {
                            actionBtns = '<span onclick="MlifeApp.startDmWithApplicant(' + JSON.stringify(a).replace(/"/g, '&quot;') + ',' + JSON.stringify(post.title).replace(/"/g, '&quot;') + ')" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(96,165,250,0.1);color:#60a5fa;border:1px solid rgba(96,165,250,0.2);font-family:inherit;">💬 私信</span>';
                        }

                        applicantsHtml += '<div style="background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:10px;padding:12px 14px;">'
                            + '<div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:4px;">'
                            + '<div style="display:flex;align-items:center;gap:8px;">'
                            + '<span style="font-size:24px;">' + (a.avatar || '👤') + '</span>'
                            + '<div><div style="font-weight:600;font-size:14px;color:#e5e5e7;">' + app.escapeHtml(a.name) + '</div>'
                            + '<div style="font-size:11px;color:#9a9a9f;">' + (a.age || '--') + ' · ' + (a.city || '--') + ' ⭐' + (a.rating || '--') + '</div></div>'
                            + '</div>' + aStatusTag
                            + '</div>'
                            + (a.note ? '<div style="font-size:12px;color:#6a6a70;padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:6px;margin:4px 0;line-height:1.4;">📝 ' + app.escapeHtml(a.note) + '</div>' : '')
                            + tagsHtml
                            + (actionBtns ? '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">' + actionBtns + '</div>' : '')
                            + '</div>';
                    }
                    applicantsHtml += '</div>';
                }

                // 底部操作按钮
                var bottomBtns = '';
                if (post.status === '招募中') {
                    bottomBtns = '<button onclick="if(confirm(\'确定取消招募「' + app.escapeHtml(post.title) + '」？\')){MlifeApp.cancelRecruitPost(\'' + post.id + '\');MlifeApp.navigate(\'recruit_manage\');}" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(248,113,113,0.3);background:rgba(248,113,113,0.1);color:#f87171;font-size:13px;cursor:pointer;font-family:inherit;">取消招募</button>';
                } else if (post.status === '已取消') {
                    bottomBtns = '<button onclick="MlifeApp.reactivateRecruitPost(\'' + post.id + '\');MlifeApp.navigate(\'recruit_manage\');" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(52,211,153,0.3);background:rgba(52,211,153,0.1);color:#34d399;font-size:13px;cursor:pointer;font-family:inherit;">重新发布</button>';
                }
                bottomBtns += '<button onclick="MlifeApp.navigate(\'recruit_manage\')" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(201,169,110,0.2);background:transparent;color:#9a9a9f;font-size:13px;cursor:pointer;font-family:inherit;">返回</button>';

                // 组装
                var rewardDisplay = post.reward ? '<div style="display:flex;gap:10px;font-size:12px;color:#9a9a9f;"><span>💰 ' + app.escapeHtml(post.reward) + '</span></div>' : '';
                var progressHtml = post.progress ? '<div style="font-size:12px;color:#6a6a70;padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:6px;line-height:1.4;">' + app.escapeHtml(post.progress) + '</div>' : '';

                return '<div style="padding:0;">'
                    + '<div style="background:linear-gradient(135deg,#1a1a1f,#222228);padding:12px 16px;border-bottom:1px solid rgba(201,169,110,0.12);display:flex;align-items:center;gap:10px;">'
                    + '<button onclick="MlifeApp.navigate(\'recruit_manage\')" style="background:none;border:none;color:var(--ml-text-dim);font-size:16px;cursor:pointer;padding:0 2px;font-family:inherit;">←</button>'
                    + '<span style="font-size:18px;">' + (post.typeIcon || '📋') + '</span>'
                    + '<div><div style="font-weight:600;font-size:15px;color:#e5e5e7;">' + app.escapeHtml(post.title) + '</div>'
                    + '<div style="font-size:11px;color:#9a9a9f;">' + (post.recruitType || '') + '</div></div>'
                    + statusTag
                    + '</div>'
                    + '<div style="padding:14px 16px;">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:6px;">👤 ' + app.escapeHtml(post.poster || '用户') + ' · 🕐 ' + app.escapeHtml(post.time || '') + '</div>'
                    + rewardDisplay
                    + '<div style="background:#1a1a1f;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.08);margin:8px 0;">'
                    + '<div style="font-size:11px;color:#9a9a9f;margin-bottom:6px;font-weight:600;">详细信息</div>'
                    + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 12px;font-size:12px;color:#e5e5e7;">'
                    + (post.count ? '<div><span style="color:#6a6a70;">人数:</span> ' + app.escapeHtml(String(post.count)) + '</div>' : '')
                    + (post.date ? '<div><span style="color:#6a6a70;">日期:</span> ' + app.escapeHtml(post.date) + '</div>' : '')
                    + (post.city ? '<div><span style="color:#6a6a70;">地点:</span> ' + app.escapeHtml(post.city) + '</div>' : '')
                    + (post.duration ? '<div><span style="color:#6a6a70;">时长:</span> ' + app.escapeHtml(post.duration) + '</div>' : '')
                    + (post.ageRange ? '<div><span style="color:#6a6a70;">年龄:</span> ' + app.escapeHtml(post.ageRange) + '</div>' : '')
                    + (post.bodyPref ? '<div><span style="color:#6a6a70;">偏好:</span> ' + app.escapeHtml(post.bodyPref) + '</div>' : '')
                    + '</div>'
                    + (post.specialReq ? '<div style="font-size:12px;color:#e5e5e7;margin-top:6px;"><span style="color:#6a6a70;">特殊要求:</span> ' + app.escapeHtml(post.specialReq) + '</div>' : '')
                    + (post.playTags && post.playTags.length ? '<div style="font-size:12px;color:#c9a96e;margin-top:6px;">🏷 ' + post.playTags.map(function(t){return app.escapeHtml(t)}).join(' · ') + '</div>' : '')
                    + '</div>'
                    + progressHtml
                    + '</div>'
                    + '<div style="padding:8px 16px 4px;border-bottom:1px solid rgba(201,169,110,0.08);"><div style="font-size:13px;font-weight:600;color:#e5e5e7;">应征者 (' + applicants.length + '人)</div></div>'
                    + '<div style="padding:8px 16px;">' + applicantsHtml + '</div>'
                    + '<div style="padding:12px 16px;display:flex;gap:8px;">' + bottomBtns + '</div>'
                    + '</div>';
            };
