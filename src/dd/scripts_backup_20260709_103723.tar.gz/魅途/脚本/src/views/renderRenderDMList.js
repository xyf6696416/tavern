             */
            app.renderDMList = function() {
                var items = [];
                try {
                    if (typeof DM_Manager !== 'undefined' && DM_Manager.getContactList) {
                        items = DM_Manager.getContactList();
                    }
                } catch(_) {}
                if (!items || items.length === 0) {
                    return '<div style="padding:40px 20px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无私信联系人</div>';
                }
                var listHtml = '<div style="padding:0;">';
                for (var i = 0; i < items.length; i++) {
                    var c = items[i];
                    var unread = 0;
                    try { unread = DM_Manager.getUnread(c.contact) || 0; } catch(_) {}
                    var timeStr = '';
                    if (c.lastTime) {
                        try { var d = new Date(c.lastTime); timeStr = d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}); } catch(_) {}
                    }
                    var avatar = '👤';
                    try { var meta = DM_Manager.getSessionMeta(c.contact); if(meta&&meta.avatar) avatar=meta.avatar; } catch(_) {}
                    var badgeHtml = unread > 0 ? '<span style="float:right;background:#ff6b9d;color:#fff;border-radius:50%;width:22px;height:22px;text-align:center;font-size:12px;line-height:22px;font-weight:bold;">'+(unread>99?'99+':unread)+'</span>' : '';
                    listHtml += '<div onclick="MlifeApp.navigate(\'dm\',{contact:\''+app.escapeHtml(c.contact)+'\'})" style="display:flex;align-items:center;gap:12px;padding:14px 0;border-bottom:1px solid var(--ml-border-1a);cursor:pointer;">'
                        + '<span style="font-size:36px;width:44px;text-align:center;line-height:44px;">'+app.escapeHtml(avatar)+'</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;justify-content:space-between;"><span style="font-weight:bold;font-size:15px;color:var(--ml-text);">'+app.escapeHtml(c.contact)+'</span>'
                        + '<span style="font-size:11px;color:var(--ml-text-dimmer);">'+app.escapeHtml(timeStr)+'</span></div>'
                        + '<div style="display:flex;justify-content:space-between;"><span style="font-size:13px;color:var(--ml-text-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px;">'+app.escapeHtml(c.lastMessage||'')+'</span>'
                        + badgeHtml+'</div></div></div>';
                }
                return '<div style="padding:0 4px;">'+listHtml+'</div>';
            };
