            // ---- 路由 ----
            app.renderPage = function(config) {
                if (!config || !config.page) {
                    app.currentPage = 'home';
                    app.renderHome(null);
                    return;
                }
                app.currentPage = config.page;
                var page = config.page;
                var data = config.data || null;

                // 显示浮层（兼容 flex 和 block 两种布局模式）
                var appEl = document.getElementById('mlife-app');
                if (appEl) {
                    var useFlex = !!appEl.querySelector('.nav-bar');
                    var targetDisplay = useFlex ? 'flex' : 'block';
                    if (appEl.style.display !== targetDisplay) {
                        appEl.style.display = targetDisplay;
                    }
                }

                var contentEl = document.getElementById('mlife-content');
                if (!contentEl) return;

                var html = '';
                switch (page) {
                    case 'home':
                    case 'index':
                        html = app.renderHome(data);
                        break;
                    case 'match':
                        html = app.renderMatch(data);
                        break;
                    case 'detail':
                        html = app.renderDetail(data);
                        break;
                    case 'live_list':
                    case 'livelist':
                        html = app.renderLiveList(data);
                        break;
                    case 'live':
                        html = app.renderLive(data);
                        break;
                    case 'goddess':
                        html = app.renderGoddess(data);
                        break;
                    case 'resource':
                        html = app.renderResource(data);
                        break;
                    case 'profile':
                        html = app.renderProfile(data);
                        break;
                    case 'selfie':
                        html = app.renderSelfie(data);
                        break;
                    case 'chat':
                        html = app.renderChat(data);
                        break;
                    case 'dm':
                    case 'DM':
                        html = app.renderDM(data);
                        break;
                    case 'dm_list':
                    case 'dmList':
                        html = app.renderDMList();
                        break;
                    case 'recruit_list':
                    case 'recruitlist':
                        html = app.renderRecruitList(data);
                        break;
                    case 'recruit_detail':
                    case 'recruitdetail':
                        html = app.renderRecruitDetail(data);
                        break;
                    case 'recruit_post':
                    case 'recruitpost':
                        html = app.renderRecruitPost(data);
                        break;
                    case 'recruit_manage':
                    case 'recruitmanage':
                        html = app.renderRecruitManage(data);
                        break;
                    case 'unbox':
                        html = app.renderUnbox(data);
                        break;
                    case 'settings':
                        html = app.renderSettings(data);
                        break;
                    default:
                        html = app.renderHome(data);
                        break;
                }

                contentEl.innerHTML = html;

                // 如果渲染结果为空，且该页支持 AI 生成，触发自动生成
                if (app.__isPageEmpty(page, html) && app.__pageGenerators[page]) {
                    if (!app.__isGenerating[page]) {
                        app.__generatePageContent(page);
                    }
                }
            };
