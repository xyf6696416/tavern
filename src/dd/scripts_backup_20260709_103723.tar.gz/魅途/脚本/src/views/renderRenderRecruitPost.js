
            app.renderRecruitPost = function(data) {
                var balance = 0;
                try {
                    if (data && data.form && data.form.balance) balance = parseInt(data.form.balance) || 0;
                    else if (data && data.balance) balance = parseInt(data.balance) || 0;
                } catch(_) {}

                // 预设标签库
                var PLAY_TAGS = [
                    '师生','制服','服从型','主导型','温柔主导','女主导',
                    '道具','绳缚','露出','户外','车内','试衣间',
                    '足控','丝袜','口交','深喉','颜射','内射',
                    '3P','交换','调教','主从','SM','强制',
                    '摄影','私房','网调','语音','视频',
                    '角色扮演','反差','羞辱','高潮控制','多次',
                    '舔足','足交','玩具','跳蛋','肛塞',
                    '男友感','女友感','氛围感','自然发展','颜值要求',
                    '身材好','体力好','持久','肌肉','干净',
                    '约会','喝酒','过夜','吃饭','看电影'
                ];

                var RECRUIT_TYPES = ['单人约会','多人聚会','角色扮演','道具play','露出任务','调教','网调','摄影','单人定制','母女','双胞胎·姐妹','闺蜜','绿帽','绿奴','情侣交换','夫妻交换'];
                var SPECIAL_TYPES = ['母女','双胞胎·姐妹','绿帽','绿奴','情侣交换','夫妻交换'];
                var TYPE_FEE_MAP = {
                    '单人约会':0.20,'多人聚会':0.20,'角色扮演':0.20,'道具play':0.20,'露出任务':0.20,'调教':0.20,'网调':0.20,'摄影':0.20,'单人定制':0.20,
                    '母女':0.30,'双胞胎·姐妹':0.25,'闺蜜':0.20,'绿帽':0.30,'绿奴':0.30,'情侣交换':0,'夫妻交换':0
                };
                var TYPE_ICON_MAP = {
                    '单人约会':'💑','多人聚会':'🎉','角色扮演':'🎭','道具play':'🔧','露出任务':'👀','调教':'🏏','网调':'📱','摄影':'📸','单人定制':'✨','母女':'👩‍👧','双胞胎·姐妹':'👭','闺蜜':'👯','绿帽':'💚','绿奴':'🔗','情侣交换':'🔄','夫妻交换':'💞'
                };

                var specialMsgs = {
                    '母女':'需双方身份证+户口本验证，报酬×2.5，服务费30%',
                    '双胞胎·姐妹':'需双方身份证+关系证明验证，双胞胎报酬×3，姐妹×2，服务费25%',
                    '绿帽':'需伴侣关系证明+三方视频确认，平台抽取报酬30%',
                    '绿奴':'需伴侣关系证明+三方视频确认，平台抽取报酬30%',
                    '情侣交换':'需双方关系证明+四方视频确认，固定服务费各50000 M币',
                    '夫妻交换':'需结婚证+四方视频确认，固定服务费各50000 M币'
                };

                function formatMCoin(num) {
                    if (num === 0) return '0 M币';
                    if (!num || isNaN(num)) return '—';
                    var sign = num < 0 ? '-' : '';
                    var abs = Math.abs(num);
                    return sign + abs.toLocaleString('zh-CN') + ' M币';
                }

                function makeTagChips() {
                    var chips = '';
                    for (var ti = 0; ti < PLAY_TAGS.length; ti++) {
                        chips += '<span class="hj-tag-chip" data-tag="' + app.escapeHtml(PLAY_TAGS[ti]) + '" style="display:inline-block;padding:5px 12px;border-radius:16px;font-size:12px;cursor:pointer;background:#2a2a32;color:#9a9a9f;border:1px solid rgba(255,255,255,0.08);transition:all 0.15s;user-select:none;margin:0 4px 6px 0;" onmouseover="this.style.borderColor=\'rgba(201,169,110,0.3)\';this.style.color=\'#e5e5e7\'" onmouseout="if(!this.classList.contains(\'selected\')){this.style.borderColor=\'rgba(255,255,255,0.08)\';this.style.color=\'#9a9a9f\'}" onclick="this.classList.toggle(\'selected\');if(this.classList.contains(\'selected\')){this.style.background=\'rgba(201,169,110,0.15)\';this.style.color=\'#c9a96e\';this.style.borderColor=\'#c9a96e\';this.style.fontWeight=\'600\'}else{this.style.background=\'#2a2a32\';this.style.color=\'#9a9a9f\';this.style.borderColor=\'rgba(255,255,255,0.08)\';this.style.fontWeight=\'400\'}">' + app.escapeHtml(PLAY_TAGS[ti]) + '</span>';
                    }
                    return chips;
                }

                function makeTypeOptions() {
                    var opts = '<option value="">请选择</option>';
                    for (var ti2 = 0; ti2 < RECRUIT_TYPES.length; ti2++) {
                        opts += '<option value="' + app.escapeHtml(RECRUIT_TYPES[ti2]) + '">' + app.escapeHtml(RECRUIT_TYPES[ti2]) + '</option>';
                    }
                    return opts;
                }

                // 生成唯一 ID 前缀防止冲突
                var uid = 'hjp_' + Date.now() + '_';

                var html = ''
                    // 头部
                    + '<div style="background:linear-gradient(135deg,#1a1a1f,#222228);padding:14px 16px;border-bottom:1px solid rgba(201,169,110,0.12);display:flex;align-items:center;gap:10px;">'
                    + '<span style="font-size:20px;width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#c9a96e,#8b7340);display:flex;align-items:center;justify-content:center;flex-shrink:0;">💎</span>'
                    + '<div><div style="font-weight:600;font-size:15px;color:#e5e5e7;">发布招募</div>'
                    + '<div style="font-size:11px;color:#9a9a9f;">填写信息后确认发布</div></div></div>'

                    // 提示条
                    + '<div style="padding:8px 16px;background:rgba(201,169,110,0.04);border-bottom:1px solid rgba(201,169,110,0.08);display:flex;align-items:flex-start;gap:6px;">'
                    + '<span style="font-size:12px;flex-shrink:0;">💡</span>'
                    + '<span style="font-size:11px;color:#8b7340;line-height:1.5;">特殊类型需要额外验证，发布后进入人工审核。常规类型发布后立即生效，有效期7天。</span></div>'

                    // 表单主体
                    + '<div style="padding:14px 16px;background:#1a1a1f;max-height:480px;overflow-y:auto;">'

                    // ---- 基本信息 ----
                    + '<div style="font-size:11px;font-weight:600;color:#c9a96e;margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid rgba(201,169,110,0.12);letter-spacing:1px;">📋 基本信息</div>'

                    // 标题
                    + '<div style="margin-bottom:10px;" id="' + uid + 'fg-title">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;display:flex;justify-content:space-between;"><span><span style="color:#f87171;">*</span> 招募标题</span><span style="font-size:10px;color:#6a6a70;" id="' + uid + 'counter-title">0/15</span></div>'
                    + '<input id="' + uid + 'ipt-title" type="text" placeholder="15字以内" maxlength="15" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;">'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-title">请填写招募标题</div></div>'

                    // 类型 + 人数
                    + '<div style="display:flex;gap:8px;margin-bottom:10px;">'
                    + '<div style="flex:1;" id="' + uid + 'fg-type">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 招募类型</div>'
                    + '<select id="' + uid + 'ipt-type" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;appearance:none;cursor:pointer;box-sizing:border-box;">' + makeTypeOptions() + '</select>'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-type">请选择招募类型</div></div>'
                    + '<div style="flex:1;" id="' + uid + 'fg-count">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 人数</div>'
                    + '<input id="' + uid + 'ipt-count" type="number" placeholder="1" min="1" max="5" value="1" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;">'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-count">1~5人</div></div></div>'

                    // 特殊类型提示（隐藏默认）
                    + '<div id="' + uid + 'special-notice" style="display:none;font-size:12px;color:#fbbf24;margin-bottom:10px;padding:6px 10px;background:rgba(251,191,36,0.08);border-radius:6px;border:1px solid rgba(251,191,36,0.15);"></div>'

                    // 时间 + 城市
                    + '<div style="display:flex;gap:8px;margin-bottom:10px;">'
                    + '<div style="flex:1;" id="' + uid + 'fg-date">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 执行时间</div>'
                    + '<input id="' + uid + 'ipt-date" type="text" placeholder="例：本周六 19:00" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;">'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-date">请填写执行时间</div></div>'
                    + '<div style="flex:1;" id="' + uid + 'fg-city">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 执行地点</div>'
                    + '<input id="' + uid + 'ipt-city" type="text" placeholder="例：上海·静安" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;">'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-city">请填写执行地点</div></div></div>'

                    // 时长
                    + '<div style="margin-bottom:12px;" id="' + uid + 'fg-duration">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 时长预期</div>'
                    + '<select id="' + uid + 'ipt-duration" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;appearance:none;cursor:pointer;box-sizing:border-box;">'
                    + '<option value="">请选择</option><option value="2小时">2小时</option><option value="4小时">4小时</option><option value="过夜">过夜</option><option value="自定义">自定义</option></select>'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-duration">请选择时长</div></div>'

                    // ---- 详细要求 ----
                    + '<div style="font-size:11px;font-weight:600;color:#c9a96e;margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid rgba(201,169,110,0.12);letter-spacing:1px;margin-top:4px;">🔍 详细要求</div>'

                    // 年龄 + 身材
                    + '<div style="display:flex;gap:8px;margin-bottom:10px;">'
                    + '<div style="flex:1;" id="' + uid + 'fg-age">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 年龄范围</div>'
                    + '<input id="' + uid + 'ipt-age" type="text" placeholder="例：20-28岁" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;">'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-age">请填写年龄范围</div></div>'
                    + '<div style="flex:1;" id="' + uid + 'fg-body">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;">身材偏好 <span style="color:#6a6a70;font-size:10px;">选填</span></div>'
                    + '<input id="' + uid + 'ipt-body" type="text" placeholder="不限" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;"></div></div>'

                    // 特殊要求
                    + '<div style="margin-bottom:10px;">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;">特殊要求 <span style="color:#6a6a70;font-size:10px;">选填</span><span style="float:right;font-size:10px;color:#6a6a70;" id="' + uid + 'counter-req">0/200</span></div>'
                    + '<textarea id="' + uid + 'ipt-req" placeholder="越具体越容易匹配" maxlength="200" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;resize:vertical;min-height:50px;box-sizing:border-box;"></textarea></div>'

                    // Play标签
                    + '<div style="margin-bottom:10px;" id="' + uid + 'fg-tags">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> Play标签 <span style="color:#6a6a70;font-size:10px;">可多选</span></div>'
                    + '<div id="' + uid + 'tag-selector">' + makeTagChips() + '</div>'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-tags">请至少选择一个Play标签</div></div>'

                    // ---- 报酬与费用 ----
                    + '<div style="font-size:11px;font-weight:600;color:#c9a96e;margin-bottom:10px;padding-bottom:6px;border-bottom:1px solid rgba(201,169,110,0.12);letter-spacing:1px;margin-top:4px;">💰 报酬与费用</div>'

                    // M币余额
                    + '<div style="display:flex;justify-content:space-between;padding:6px 0;font-size:12px;margin-bottom:6px;">'
                    + '<span style="color:#9a9a9f;">M币余额</span>'
                    + '<span style="color:#c9a96e;font-weight:600;" id="' + uid + 'balance-display">' + formatMCoin(balance) + '</span></div>'

                    // 单人报酬
                    + '<div style="margin-bottom:8px;" id="' + uid + 'fg-reward">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:4px;"><span style="color:#f87171;">*</span> 单人报酬 (M币)</div>'
                    + '<input id="' + uid + 'ipt-reward" type="number" placeholder="最低10000" min="10000" step="1000" style="width:100%;padding:9px 12px;background:#2a2a32;border:1px solid rgba(255,255,255,0.08);border-radius:8px;color:#e5e5e7;font-size:13px;font-family:inherit;outline:none;box-sizing:border-box;">'
                    + '<div style="font-size:10px;color:#6a6a70;margin-top:2px;">最低10000 M币/人（1000元）</div>'
                    + '<div style="font-size:11px;color:#f87171;margin-top:3px;display:none;" id="' + uid + 'err-reward">单人报酬最低10000 M币</div></div>'

                    // 自动计算区
                    + '<div style="background:#222228;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.12);margin-bottom:4px;">'
                    + '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.03);"><span style="font-size:11px;color:#9a9a9f;">总报酬</span><span style="font-size:12px;font-weight:600;color:#c9a96e;" id="' + uid + 'calc-total">—</span></div>'
                    + '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.03);"><span style="font-size:11px;color:#9a9a9f;">平台服务费 <span style="color:#6a6a70;font-size:10px;">(发布时扣除·不退)</span></span><span style="font-size:12px;color:#f87171;" id="' + uid + 'calc-fee">—</span></div>'
                    + '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.03);"><span style="font-size:11px;color:#9a9a9f;">押金 <span style="color:#6a6a70;font-size:10px;">(冻结·完成后释放)</span></span><span style="font-size:12px;color:#c9a96e;" id="' + uid + 'calc-deposit">—</span></div>'
                    + '<div style="border-top:1px solid rgba(201,169,110,0.12);margin:4px 0;"></div>'
                    + '<div style="display:flex;justify-content:space-between;padding:5px 0;"><span style="font-size:12px;font-weight:600;color:#9a9a9f;">合计支出</span><span style="font-size:13px;font-weight:700;color:#f87171;" id="' + uid + 'calc-total-cost">—</span></div>'
                    + '<div style="display:flex;justify-content:space-between;padding:5px 0;display:none;" id="' + uid + 'row-after-balance"><span style="font-size:11px;color:#9a9a9f;">发布后余额</span><span style="font-size:12px;" id="' + uid + 'calc-after-balance">—</span></div>'
                    + '</div>'

                    + '</div>' // 表单主体结束

                    // 按钮
                    + '<div style="padding:12px 16px;background:#0a0a0f;display:flex;gap:8px;">'
                    + '<button id="' + uid + 'btn-cancel" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(201,169,110,0.2);background:transparent;color:#9a9a9f;font-size:13px;cursor:pointer;font-family:inherit;transition:all 0.2s;">取消</button>'
                    + '<button id="' + uid + 'btn-submit" style="flex:2;padding:10px;border-radius:8px;border:1px solid #c9a96e;background:linear-gradient(135deg,rgba(201,169,110,0.2),rgba(201,169,110,0.3));color:#c9a96e;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:all 0.2s;">确认发布</button>'
                    + '</div>';

                // 延迟绑定事件（DOM 渲染后）
                setTimeout(function() {
                    var formData = { title: '', type: '', count: 1, date: '', city: '', duration: '', ageRange: '', bodyPref: '', specialReq: '', playTags: [], reward: 0 };

                    function updateCalc() {
                        var type = formData.type;
                        var count = formData.count || 1;
                        var reward = formData.reward || 0;
                        var totalReward = reward * count;
                        var feeRate = TYPE_FEE_MAP[type] !== undefined ? TYPE_FEE_MAP[type] : 0.20;
                        var isExchange = (type === '情侣交换' || type === '夫妻交换');
                        var fee, deposit, totalCost, afterBalance;
                        if (isExchange) { fee = 50000; deposit = 0; totalCost = fee; }
                        else { fee = Math.round(totalReward * feeRate); deposit = Math.round(totalReward * 0.5); totalCost = fee + deposit; }
                        afterBalance = balance - totalCost;

                        var elTotal = document.getElementById(uid + 'calc-total');
                        var elFee = document.getElementById(uid + 'calc-fee');
                        var elDeposit = document.getElementById(uid + 'calc-deposit');
                        var elTotalCost = document.getElementById(uid + 'calc-total-cost');
                        var elAfterBalance = document.getElementById(uid + 'calc-after-balance');
                        var rowAfter = document.getElementById(uid + 'row-after-balance');
                        var elBalance = document.getElementById(uid + 'balance-display');

                        if (elTotal) elTotal.textContent = isExchange ? '—' : formatMCoin(totalReward);
                        if (elFee) elFee.textContent = formatMCoin(fee);
                        if (elDeposit) elDeposit.textContent = isExchange ? '—' : formatMCoin(deposit);
                        if (elTotalCost) elTotalCost.textContent = formatMCoin(totalCost);
                        if (rowAfter) rowAfter.style.display = (reward > 0 && count > 0 && type) ? 'flex' : 'none';
                        if (elAfterBalance) {
                            elAfterBalance.textContent = formatMCoin(afterBalance);
                            elAfterBalance.style.color = afterBalance < 0 ? '#f87171' : '#e5e5e7';
                        }
                        if (elBalance) {
                            elBalance.textContent = formatMCoin(balance);
                            elBalance.style.color = afterBalance < 0 ? '#f87171' : '#c9a96e';
                        }
                    }

                    function clearError(id) { var el = document.getElementById(id); if (el) el.style.display = 'none'; }
                    function setError(id) { var el = document.getElementById(id); if (el) el.style.display = 'block'; }

                    // 标题
                    var iptTitle = document.getElementById(uid + 'ipt-title');
                    if (iptTitle) {
                        iptTitle.addEventListener('input', function() {
                            var len = this.value.length;
                            var counter = document.getElementById(uid + 'counter-title');
                            if (counter) counter.textContent = len + '/15';
                            formData.title = this.value;
                            clearError(uid + 'err-title');
                        });
                    }

                    // 类型
                    var iptType = document.getElementById(uid + 'ipt-type');
                    if (iptType) {
                        iptType.addEventListener('change', function() {
                            formData.type = this.value;
                            clearError(uid + 'err-type');
                            // 特殊类型提示
                            var notice = document.getElementById(uid + 'special-notice');
                            if (notice) {
                                var isSpecial = SPECIAL_TYPES.indexOf(this.value) >= 0;
                                if (isSpecial) {
                                    notice.style.display = 'block';
                                    notice.textContent = '⚠ ' + (specialMsgs[this.value] || '需要额外验证');
                                } else {
                                    notice.style.display = 'none';
                                }
                            }
                            updateCalc();
                        });
                    }

                    // 人数
                    var iptCount = document.getElementById(uid + 'ipt-count');
                    if (iptCount) {
                        iptCount.addEventListener('input', function() {
                            var v = parseInt(this.value) || 1;
                            if (v < 1) v = 1; if (v > 5) v = 5;
                            this.value = v;
                            formData.count = v;
                            clearError(uid + 'err-count');
                            updateCalc();
                        });
                    }

                    // 日期
                    var iptDate = document.getElementById(uid + 'ipt-date');
                    if (iptDate) { iptDate.addEventListener('input', function() { formData.date = this.value; clearError(uid + 'err-date'); }); }

                    // 城市
                    var iptCity = document.getElementById(uid + 'ipt-city');
                    if (iptCity) { iptCity.addEventListener('input', function() { formData.city = this.value; clearError(uid + 'err-city'); }); }

                    // 时长
                    var iptDuration = document.getElementById(uid + 'ipt-duration');
                    if (iptDuration) { iptDuration.addEventListener('change', function() { formData.duration = this.value; clearError(uid + 'err-duration'); }); }

                    // 年龄
                    var iptAge = document.getElementById(uid + 'ipt-age');
                    if (iptAge) { iptAge.addEventListener('input', function() { formData.ageRange = this.value; clearError(uid + 'err-age'); }); }

                    // 身材
                    var iptBody = document.getElementById(uid + 'ipt-body');
                    if (iptBody) { iptBody.addEventListener('input', function() { formData.bodyPref = this.value; }); }

                    // 特殊要求字数
                    var iptReq = document.getElementById(uid + 'ipt-req');
                    if (iptReq) {
                        iptReq.addEventListener('input', function() {
                            var len = this.value.length;
                            var counter = document.getElementById(uid + 'counter-req');
                            if (counter) counter.textContent = len + '/200';
                            formData.specialReq = this.value;
                        });
                    }

                    // 报酬
                    var iptReward = document.getElementById(uid + 'ipt-reward');
                    if (iptReward) {
                        iptReward.addEventListener('input', function() {
                            var v = parseInt(this.value) || 0;
                            formData.reward = v;
                            clearError(uid + 'err-reward');
                            updateCalc();
                        });
                    }

                    // 提交
                    var btnSubmit = document.getElementById(uid + 'btn-submit');
                    if (btnSubmit) {
                        btnSubmit.addEventListener('click', function() {
                            // 收集标签
                            var chips = document.querySelectorAll('#' + uid + 'tag-selector .hj-tag-chip.selected');
                            formData.playTags = [];
                            for (var ci = 0; ci < chips.length; ci++) {
                                formData.playTags.push(chips[ci].getAttribute('data-tag'));
                            }

                            // 验证
                            var valid = true;
                            if (!formData.title || formData.title.trim() === '') { setError(uid + 'err-title'); valid = false; }
                            if (!formData.type) { setError(uid + 'err-type'); valid = false; }
                            if (!formData.count || formData.count < 1 || formData.count > 5) { setError(uid + 'err-count'); valid = false; }
                            if (!formData.date || formData.date.trim() === '') { setError(uid + 'err-date'); valid = false; }
                            if (!formData.city || formData.city.trim() === '') { setError(uid + 'err-city'); valid = false; }
                            if (!formData.duration) { setError(uid + 'err-duration'); valid = false; }
                            if (!formData.ageRange || formData.ageRange.trim() === '') { setError(uid + 'err-age'); valid = false; }
                            if (formData.playTags.length === 0) { setError(uid + 'err-tags'); valid = false; }
                            if (!formData.reward || formData.reward < 10000) { setError(uid + 'err-reward'); valid = false; }

                            if (!valid) return;

                            // 余额检查
                            var type = formData.type;
                            var count = formData.count;
                            var reward = formData.reward;
                            var feeRate = TYPE_FEE_MAP[type] !== undefined ? TYPE_FEE_MAP[type] : 0.20;
                            var isExchange = (type === '情侣交换' || type === '夫妻交换');
                            var totalReward = reward * count;
                            var fee = isExchange ? 50000 : Math.round(totalReward * feeRate);
                            var deposit = isExchange ? 0 : Math.round(totalReward * 0.5);
                            var totalCost = fee + deposit;
                            if (totalCost > balance && balance > 0) { setError(uid + 'err-reward'); document.getElementById(uid + 'err-reward').textContent = '余额不足，还差 ' + formatMCoin(totalCost - balance); return; }

                            // 拼接消息
                            var lines = ['确认发布招募：'];
                            lines.push('招募标题：' + formData.title);
                            lines.push('招募类型：' + formData.type);
                            lines.push('人数需求：' + formData.count);
                            lines.push('执行时间：' + formData.date);
                            lines.push('执行地点：' + formData.city);
                            lines.push('时长预期：' + formData.duration);
                            lines.push('年龄要求：' + formData.ageRange);
                            if (formData.bodyPref) lines.push('身材偏好：' + formData.bodyPref);
                            if (formData.specialReq) lines.push('特殊要求：' + formData.specialReq);
                            lines.push('Play标签：' + formData.playTags.join('，'));
                            lines.push('单人报酬：' + formData.reward + ' M币');

                            btnSubmit.disabled = true;
                            btnSubmit.textContent = '提交中...';

                            // 保存到本地
                            var newPost = {id:'R'+Date.now().toString(36).toUpperCase(),typeIcon:(TYPE_ICON_MAP[formData.type]||'📋'),title:formData.title,recruitType:formData.type,status:'招募中',time:new Date().toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}),reward:formatMCoin(formData.reward)+'/次',progress:'等待平台审核',poster:'用户'};
                            MlifeApp.saveRecruitPost(newPost);
                            setTimeout(function(){MlifeApp.navigate('recruit_manage')}, 500);

                            if (typeof MlifeApp !== 'undefined' && MlifeApp.action) {
                                MlifeApp.action('/send ' + encodeURIComponent(lines.join('\n')) + '|/trigger');
                            } else if (typeof triggerSlash === 'function') {
                                triggerSlash('/send ' + encodeURIComponent(lines.join('\n')) + '|/trigger');
                            }
                        });
                    }

                    // 取消按钮
                    var btnCancel = document.getElementById(uid + 'btn-cancel');
                    if (btnCancel) {
                        btnCancel.addEventListener('click', function() {
                            if (typeof MlifeApp !== 'undefined' && MlifeApp.action) {
                                MlifeApp.action('/send 取消发布招募|/trigger');
                            } else if (typeof triggerSlash === 'function') {
                                triggerSlash('/send 取消发布招募|/trigger');
                            }
                        });
                    }

                    // 初始计算
                    updateCalc();
                }, 50);

                MlifeApp.updateCache('recruit_post', html);
                return html;
            };
