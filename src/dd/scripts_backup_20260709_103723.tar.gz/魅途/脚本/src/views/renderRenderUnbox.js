            // ---- 开盒页面 ----
            app.renderUnbox = function(data) {
                if (!data || !data.contact) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">开盒数据不可用</div>';
                }

                var charData = data.character || {};
                var isUnboxed = data.isUnboxed || false;
                var balance = data.balance || '0';
                var hiddenComment = '<!-- hidden: ' + app.escapeHtml(data.hidden || '') + ' -->\n';

                // ---- 页面头部（返回按钮 + 角色信息） ----
                // 开盒页返回私信时，通过缓存记录当前联系人，使再次navigate('dm')可恢复
                if (data.contact) {
                    MlifeApp.__lastDMContact = data.contact;
                }
                var headerHtml = '<div style="display:flex;align-items:center;gap:12px;padding:12px 0;margin-bottom:10px;border-bottom:1px solid var(--ml-border);flex-shrink:0;">'
                    + '<button onclick="MlifeApp.navigate(\'dm\', {contact:MlifeApp.__lastDMContact||null})" style="background:none;border:none;color:var(--ml-text-dim);font-size:18px;cursor:pointer;padding:0 4px;font-family:inherit;">&#x2190;</button>'
                    + '<span style="font-size:40px;width:48px;text-align:center;line-height:48px;flex-shrink:0;">' + app.escapeHtml(data.avatar || '') + '</span>'
                    + '<div style="flex:1;min-width:0;">'
                    + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                    + '<span style="font-weight:bold;font-size:17px;color:var(--ml-text);">' + app.escapeHtml(data.contact) + '</span>'
                    + (data.level ? '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(data.level) + '</span>' : '')
                    + (isUnboxed ? '<span style="font-size:11px;padding:1px 8px;border-radius:3px;background:rgba(100,200,100,0.2);color:#66dd88;border:1px solid #66dd88;font-weight:bold;">&#x2713; \u5df2\u5f00\u76d2</span>' : '')
                    + '</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);margin-top:2px;">'
                    + (data.vip && data.vip !== '\u65e0' ? app.escapeHtml(data.vip) + 'VIP' : '\u672a\u5f00\u901aVIP')
                    + (charData.age ? ' &middot; ' + charData.age + '\u5c81' : '')
                    + '</div>'
                    + '</div>'
                    + '</div>';

                // ---- \u672a\u5f00\u76d2\uff1a\u4ed8\u8d39\u5899 ----
                if (!isUnboxed) {
                    var balanceNum = parseInt(balance) || 0;
                    var hasEnough = balanceNum >= 100;
                    var priceHtml = hasEnough
                        ? '<div style="font-size:24px;font-weight:bold;color:#f6d365;margin:6px 0;">100 M\u5e01</div>'
                        : '<div style="font-size:24px;font-weight:bold;color:#ff4757;margin:6px 0;">100 M\u5e01</div>';
                    var balanceHtml = '<div style="font-size:13px;color:var(--ml-text-dim);margin-top:8px;">\u5f53\u524d\u4f59\u989d: <span style="color:' + (hasEnough ? '#66dd88' : '#ff4757') + ';font-weight:bold;">' + balance + ' M\u5e01</span></div>';
                    var actionBtnHtml = hasEnough
                        ? '<button onclick="MlifeApp.action(\'/send \u786e\u8ba4\u5f00\u76d2' + encodeURIComponent(data.contact) + '|/trigger\')" '
                        + 'style="width:100%;padding:12px;border-radius:10px;border:none;'
                        + 'background:var(--ml-gold);'
                        + 'color:#1a1a1a;font-size:16px;font-weight:bold;cursor:pointer;font-family:inherit;'
                        + 'transition:transform 0.2s,box-shadow 0.2s;'
                        + 'box-shadow:0 2px 12px rgba(246,211,101,0.3);"'
                        + 'onmouseover="this.style.transform=\'scale(1.02)\';this.style.boxShadow=\'0 4px 20px rgba(246,211,101,0.5)\'"'
                        + 'onmouseout="this.style.transform=\'scale(1)\';this.style.boxShadow=\'0 2px 12px rgba(246,211,101,0.3)\'"'
                        + '>&#x1F48E; \u5f00\u76d2 (100 M\u5e01)</button>'
                        : '<button onclick="MlifeApp.action(\'/send M\u5e01\u5145\u503c|/trigger\')" '
                        + 'style="width:100%;padding:12px;border-radius:10px;border:1px solid #ff4757;'
                        + 'background:rgba(255,71,87,0.1);'
                        + 'color:#ff4757;font-size:16px;font-weight:bold;cursor:pointer;font-family:inherit;">'
                        + '&#x1FA99; M\u5e01\u4e0d\u8db3\uff0c\u53bb\u5145\u503c</button>';

                    var tipHtml = hasEnough
                        ? '<div style="margin-top:10px;font-size:12px;color:var(--ml-text-dim);text-align:center;line-height:1.6;">'
                        + '\u5f00\u76d2\u540e\u53ef\u4ee5\u67e5\u770b\u8be5\u5973\u6027\u7684\u5b8c\u6574\u6863\u6848<br>\u5305\u62ec\u8eab\u4f53\u6570\u636e\u3001\u6027\u683c\u3001\u504f\u597d\u7b49\u5168\u90e8\u4fe1\u606f</div>'
                        : '<div style="margin-top:10px;font-size:12px;color:var(--ml-text-dim);text-align:center;line-height:1.6;">'
                        + '\u83b7\u53d6M\u5e01\u7684\u65b9\u5f0f\uff1a<br>'
                        + '&middot; \u6bcf\u65e5\u7b7e\u5230\u9886\u53d6 10 M\u5e01<br>'
                        + '&middot; \u6bcf\u65e5\u53d1\u5e16\u5956\u52b1 5 M\u5e01<br>'
                        + '&middot; \u76f4\u64ad\u6536\u793c\u7269\u8d5a M\u5e01</div>';

                    var paywallHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:14px;padding:24px;text-align:center;margin-bottom:12px;">'
                        + '<div style="font-size:40px;margin-bottom:8px;">&#x1F512;</div>'
                        + '<div style="font-size:16px;font-weight:bold;color:var(--ml-text-main);margin-bottom:4px;">\u6570\u636e\u5df2\u9501\u5b9a</div>'
                        + '<div style="font-size:13px;color:var(--ml-text-dim);margin-bottom:12px;">\u652f\u4ed8M\u5e01\u67e5\u770b\u8be5\u5973\u6027\u7684\u5b8c\u6574\u6863\u6848</div>'
                        + priceHtml
                        + actionBtnHtml
                        + balanceHtml
                        + tipHtml
                        + '</div>';

                    var html = '<div style="padding:0;">'
                        + hiddenComment
                        + headerHtml
                        + paywallHtml
                        + '</div>';

                    MlifeApp.updateCache('unbox', html);
                    return html;
                }

                // ---- \u5df2\u5f00\u76d2\uff1a\u5c55\u793a\u5168\u90e8\u6570\u636e ----
                function renderField(label, value) {
                    if (value === undefined || value === null || value === '') return '';
                    return '<div style="padding:6px 0;border-bottom:1px solid rgba(30,30,46,0.5);">'
                        + '<div style="font-size:11px;color:#008899;letter-spacing:0.06em;margin-bottom:1px;">' + app.escapeHtml(label) + '</div>'
                        + '<div style="font-size:14px;color:var(--ml-text-main);">' + app.escapeHtml(String(value)) + '</div>'
                        + '</div>';
                }

                function renderSection(title, fieldsHtml) {
                    if (!fieldsHtml) return '';
                    return '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:10px;padding:14px;margin-bottom:10px;">'
                        + '<div style="font-size:12px;color:#f6d365;font-weight:bold;margin-bottom:8px;letter-spacing:0.06em;padding-bottom:6px;border-bottom:1px solid rgba(246,211,101,0.15);">' + app.escapeHtml(title) + '</div>'
                        + fieldsHtml
                        + '</div>';
                }

                var basicFields = renderField('\u6635\u79f0', charData.nick)
                    + renderField('\u5e74\u9f84', charData.age ? charData.age + '\u5c81' : '')
                    + renderField('\u804c\u4e1a', charData.job)
                    + renderField('\u7b49\u7ea7', charData.level)
                    + renderField('VIP', charData.vip)
                    + renderField('\u6ce8\u518c\u65f6\u957f', charData.registered)
                    + renderField('\u4ea4\u53cb\u76ee\u7684', charData.purpose);

                var appearanceFields = renderField('\u4f53\u578b', charData.bodyType)
                    + renderField('\u8eab\u9ad8', charData.height)
                    + renderField('\u9762\u5bb9\u98ce\u683c', charData.faceStyle)
                    + renderField('\u7279\u5f81', charData.features)
                    + renderField('\u65e5\u5e38\u7a7f\u642d', charData.dailyStyle)
                    + renderField('\u7ea6\u4f1a\u7a7f\u642d', charData.dateStyle)
                    + renderField('\u5185\u8863\u504f\u597d', charData.lingerie)
                    + renderField('\u5c45\u5bb6\u98ce\u683c', charData.homeStyle);

                var personalityFields = renderField('\u6838\u5fc3\u9a71\u52a8', charData.personality_drive)
                    + renderField('\u4e3b\u8272\u8c03', charData.personality_main ? charData.personality_main.join(', ') : '')
                    + renderField('\u53cd\u5dee\u7279\u8d28', charData.personality_contrast);

                var chatFields = renderField('\u804a\u5929\u98ce\u683c', charData.chat_style)
                    + renderField('\u56de\u590d\u8282\u594f', charData.chat_pace)
                    + renderField('\u4e3b\u52a8\u6027', charData.chat_initiative)
                    + renderField('\u5f00\u8f66\u98ce\u683c', charData.chat_drive);

                var meetFields = renderField('\u521d\u6b21\u89c1\u9762', charData.meet_first)
                    + renderField('\u7ebf\u4e0a\u7ebf\u4e0b\u4e00\u81f4\u6027', charData.meet_real)
                    + renderField('\u8fdb\u5c55\u8282\u594f', charData.meet_pace);

                var bodyFields = renderField('\u7f69\u676f', charData.bust)
                    + renderField('\u8170\u90e8', charData.waist)
                    + renderField('\u81c0\u90e8', charData.hip)
                    + renderField('\u79c1\u5904', charData.pubic)
                    + renderField('\u5185\u90e8', charData.inner)
                    + renderField('\u654f\u611f\u70b9', charData.sensitive ? charData.sensitive.join(', ') : '');

                var nsfwFields = renderField('\u6838\u5fc3\u9a71\u52a8', charData.nsfw_drive)
                    + renderField('\u4eb2\u5bc6\u98ce\u683c', charData.nsfw_style)
                    + renderField('\u58f0\u97f3\u8868\u73b0', charData.nsfw_voice)
                    + renderField('\u9a9a\u8bdd\u7c7b\u578b', charData.nsfw_dirty_talk)
                    + renderField('\u504f\u597d', charData.nsfw_likes ? charData.nsfw_likes.join(', ') : '')
                    + renderField('\u7981\u533a', charData.nsfw_limits ? charData.nsfw_limits.join(', ') : '')
                    + renderField('\u9ad8\u6f6e\u8868\u73b0', charData.nsfw_orgasm);

                var contentHtml = '<div style="padding:0;">'
                    + headerHtml
                    + renderSection('\u57fa\u672c\u4fe1\u606f', basicFields)
                    + renderSection('\u5916\u8868\u4fe1\u606f', appearanceFields)
                    + renderSection('\u6027\u683c\u8c03\u8272\u76d8', personalityFields)
                    + renderSection('\u804a\u5929\u98ce\u683c', chatFields)
                    + renderSection('\u89c1\u9762\u98ce\u683c', meetFields)
                    + renderSection('\u8eab\u4f53\u6570\u636e', bodyFields)
                    + renderSection('NSFW \u4fe1\u606f', nsfwFields)
                    + '<div style="text-align:center;font-size:11px;color:#555;padding:8px 0 4px;">\u5f00\u76d2\u4e8e: ' + app.escapeHtml(charData.created_at || '\u672a\u77e5') + '</div>'
                    + '</div>';

                MlifeApp.updateCache('unbox', contentHtml);
                return contentHtml;
            };
