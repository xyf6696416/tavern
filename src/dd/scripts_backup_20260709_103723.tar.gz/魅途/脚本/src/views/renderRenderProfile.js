            // ---- 个人中心（基于变量渲染） ----
            app.renderProfile = function(data) {
                var vars = app.getMergedVars().stat_data || {};
                var mu = vars['M-life_用户'] || {};
                var social = vars['M-life_社交'] || {};
                var econ = vars['M-life_经济'] || {};
                var heijin = vars['M-life_黑金'] || {};
                var account = getCurrentAccount();

                // 变量数据作为基础，AI 生成/传入的 data 作为覆盖
                var p = data || {};
                var isVipBlack = (p.vip === '黑金' || mu.VIP类型 === '黑金');
                var sections = p.sections || [
                    {id:'selfie', name:'日常自拍', icon:'📸', locked:false},
                    {id:'chat', name:'闲聊灌水', icon:'💬', locked:false},
                    {id:'resource', name:'资源分享', icon:'📦', locked:false},
                    {id:'goddess', name:'女神夜话', icon:'👑', locked:false},
                    {id:'recruit_list', name:'黑金之选', icon:'💎', locked:!isVipBlack}
                ];

                // 顶部用户信息（变量为基底，AI 数据覆盖）
                var nick = p.nick || mu.昵称 || '用户';
                var level = p.level || mu.用户等级 || 'Lv1';
                var vip = p.vip || mu.VIP类型 || '无';
                var headerHtml = '<div style="padding:16px 16px 12px;text-align:center;border-bottom:1px solid var(--ml-border);">'
                    + '<div style="font-size:48px;margin-bottom:8px;">' + (p.avatar || '😊') + '</div>'
                    + '<div style="font-size:18px;font-weight:bold;color:var(--ml-text);">' + app.escapeHtml(nick) + '</div>'
                    + '<div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px;font-size:13px;">'
                    + '<span style="padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;font-size:12px;">' + app.escapeHtml(level) + '</span>'
                    + (vip && vip !== '无'
                        ? '<span style="padding:1px 7px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;font-size:12px;">' + app.escapeHtml(vip) + 'VIP</span>'
                        : '<span style="padding:1px 7px;border-radius:3px;background:#333;color:#999;font-size:12px;">未开通VIP</span>')
                    + '</div>'
                    + (p.bio ? '<div style="font-size:13px;color:var(--ml-text-aaa);margin-top:8px;max-width:280px;margin-left:auto;margin-right:auto;">' + app.escapeHtml(p.bio) + '</div>' : '')
                    + '</div>';

                // 社交统计（变量优先）
                var stats = p.stats || {};
                var statsHtml = '<div style="display:flex;padding:12px 16px;border-bottom:1px solid var(--ml-border);">'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:16px;font-weight:bold;color:var(--ml-text);">' + (stats.following || parseInt(social.关注数) || 0) + '</div><div style="font-size:11px;color:var(--ml-text-dim);margin-top:2px;">关注</div></div>'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:16px;font-weight:bold;color:var(--ml-text);">' + (stats.followers || parseInt(social.粉丝数) || 0) + '</div><div style="font-size:11px;color:var(--ml-text-dim);margin-top:2px;">粉丝</div></div>'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:16px;font-weight:bold;color:var(--ml-text);">' + (stats.likes || parseInt(social.获赞总数) || 0) + '</div><div style="font-size:11px;color:var(--ml-text-dim);margin-top:2px;">获赞</div></div>'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:16px;font-weight:bold;color:var(--ml-text);">' + (stats.posts || 0) + '</div><div style="font-size:11px;color:var(--ml-text-dim);margin-top:2px;">帖子</div></div>'
                    + '</div>';

                // 账号切换
                var accountSwitcherHtml = '<div style="padding:8px 16px;border-bottom:1px solid var(--ml-border);">'
                    + '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">'
                    + '<span style="font-size:13px;color:var(--ml-text-dim);">🔄 切换账号</span>'
                    + '<select id="mlife-account-select" style="background:var(--ml-bg-section);color:var(--ml-text-main);border:1px solid #2a2a3e;border-radius:6px;padding:6px 10px;font-size:13px;font-family:inherit;cursor:pointer;outline:none;"'
                    + ' onchange="MlifeApp.switchAccount(this.value)">'
                    + app.ACCOUNTS.map(function(a) {
                        return '<option value="' + a.id + '"' + (a.id === (account && account.id) ? ' selected' : '') + '>'
                            + a.emoji + ' ' + app.escapeHtml(a.label)
                            + '</option>';
                      }).join('')
                    + '</select>'
                    + '</div>'
                    + '</div>';

                // 板块导航列表
                var sectionsHtml = '<div style="padding:8px 0;">';
                for (var i = 0; i < sections.length; i++) {
                    var sec = sections[i];
                    var onclick = sec.locked
                        ? 'showHeiJinDenied()'
                        : 'MlifeApp.switchTab(\'' + sec.id + '\')';
                    sectionsHtml += '<div style="display:flex;align-items:center;padding:12px 16px;cursor:pointer;transition:background 0.2s;"'
                        + ' onclick="' + onclick + '"'
                        + ' onmouseover="this.style.background=\'#1a1a2e\'" onmouseout="this.style.background=\'transparent\'">'
                        + '<span style="font-size:20px;margin-right:12px;">' + sec.icon + '</span>'
                        + '<span style="flex:1;font-size:14px;color:var(--ml-text-main);">' + sec.name + '</span>';
                    if (sec.locked) {
                        sectionsHtml += '<span style="font-size:14px;color:var(--ml-text-dim);">🔒 黑金VIP</span>';
                    } else {
                        sectionsHtml += '<span style="font-size:14px;color:#555;">›</span>';
                    }
                    sectionsHtml += '</div>';
                }
                sectionsHtml += '</div>';

                // 底部功能按钮（签到状态从变量读取）
                var settings = p.settings || {};
                var checkedIn = settings.checkedIn || social.今日已签到 === 'true';
                var streakDays = settings.streakDays || parseInt(social.连续签到天数) || 0;
                var bottomHtml = '<div style="border-top:1px solid #1e1e2e;padding:8px 0;">'
                    + '<div style="display:flex;align-items:center;padding:12px 16px;cursor:pointer;transition:background 0.2s;"'
                    + ' onclick="MlifeApp.switchTab(\'settings\')"'
                    + ' onmouseover="this.style.background=\'#1a1a2e\'" onmouseout="this.style.background=\'transparent\'">'
                    + '<span style="font-size:18px;margin-right:12px;">⚙️</span>'
                    + '<span style="flex:1;font-size:14px;color:var(--ml-text-main);">个人设置</span>'
                    + '<span style="font-size:14px;color:#555;">›</span>'
                    + '</div>'
                    + '<div style="display:flex;align-items:center;padding:12px 16px;cursor:pointer;transition:background 0.2s;"'
                    + ' onclick="MlifeApp.action(\'/send 签到|/trigger\')"'
                    + ' onmouseover="this.style.background=\'#1a1a2e\'" onmouseout="this.style.background=\'transparent\'">'
                    + '<span style="font-size:18px;margin-right:12px;">📅</span>'
                    + '<span style="flex:1;font-size:14px;color:var(--ml-text-main);">签到</span>'
                    + (checkedIn ? '<span style="font-size:12px;color:#34d399;">今日已签到</span>' : '')
                    + (streakDays > 0 ? '<span style="font-size:12px;color:#f6d365;margin-left:6px;">连签' + streakDays + '天</span>' : '')
                    + '</div>'
                    + '</div>';

                var html = '<div style="padding:0;">'
                    + '<!-- hidden: ' + app.escapeHtml(p.hidden || '') + ' -->\n'
                    + headerHtml
                    + statsHtml
                    + accountSwitcherHtml
                    + sectionsHtml
                    + bottomHtml
                    + '</div>';
                MlifeApp.updateCache('profile', html);
                return html;
            };
