
            app.renderRecruitList = function(data) {
                if (!data || !data.recruits || data.recruits.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;letter-spacing:0.06em;">暂无招募帖</div>';
                }

                var recruits = data.recruits;
                var cards = [];

                // 生成筛选标签按钮（全部 + 各分类）
                var allFilters = ['全部', '单人约会', '多人聚会', '角色扮演', '道具play', '露出任务', '调教', '摄影', '特殊类型'];
                var currentFilter = data._filter || '全部';
                var filterBarHtml = '<div style="padding:10px 16px;display:flex;flex-wrap:wrap;gap:6px 8px;border-bottom:1px solid rgba(201,169,110,0.12);">';
                var filterKeys = { '单人约会': '单人', '多人聚会': '多人', '角色扮演': '角色扮演', '道具play': '道具', '露出任务': '露出', '调教': '调教', '摄影': '摄影', '特殊类型': '特殊' };
                for (var fi = 0; fi < allFilters.length; fi++) {
                    var f = allFilters[fi];
                    var cls = f === currentFilter ? 'rgba(201,169,110,0.15)' : 'transparent';
                    var borderCls = f === currentFilter ? '#c9a96e' : 'transparent';
                    var colorCls = f === currentFilter ? '#c9a96e' : '#8a8a9a';
                    filterBarHtml += '<span onclick="MlifeApp.navigate(\'recruit_list\',{_filter:\'' + f + '\',recruits:MlifeApp.__lastRecruitData || []})" style="padding:4px 12px;border-radius:14px;font-size:12px;white-space:nowrap;cursor:pointer;background:' + cls + ';color:' + colorCls + ';border:1px solid ' + borderCls + ';transition:all 0.2s;">' + f + '</span>';
                }
                filterBarHtml += '</div>';

                // 根据筛选过滤
                var filtered = [];
                for (var fi2 = 0; fi2 < recruits.length; fi2++) {
                    var rr = recruits[fi2];
                    if (currentFilter === '全部') {
                        filtered.push(rr);
                    } else {
                        // 从 hidden、typeIcon、tags 中匹配筛选分类
                        var searchText = (rr.hidden || '') + ' ' + (rr.typeIcon || '') + ' ' + (rr.tags ? rr.tags.join(' ') : '');
                        if (searchText.indexOf(filterKeys[currentFilter] || currentFilter) !== -1) {
                            filtered.push(rr);
                        }
                    }
                }

                for (var i = 0; i < filtered.length; i++) {
                    var r = filtered[i];

                    // 状态标签
                    var isActiveStatus = r.status === '招募中';
                    var statusColor = isActiveStatus ? '#34d399' : '#9ca3af';
                    var statusLabel = '<span style="font-size:11px;padding:2px 10px;border-radius:4px;background:rgba(' + (isActiveStatus ? '52,211,153' : '156,163,175') + ',0.1);color:' + statusColor + ';border:1px solid rgba(' + (isActiveStatus ? '52,211,153' : '156,163,175') + ',0.2);font-weight:500;">' + app.escapeHtml(r.status) + '</span>';

                    // 标签列表
                    var tagsHtml = '';
                    if (r.tags && r.tags.length > 0) {
                        tagsHtml = '<div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:8px;">';
                        for (var j = 0; j < r.tags.length; j++) {
                            tagsHtml += '<span style="font-size:11px;padding:1px 8px;border-radius:10px;border:1px solid rgba(201,169,110,0.5);color:#c9a96e;background:rgba(201,169,110,0.08);">' + app.escapeHtml(r.tags[j]) + '</span>';
                        }
                        tagsHtml += '</div>';
                    }

                    // 隐藏描述
                    var hiddenHtml = r.hidden ? '<div style="font-size:11px;color:#6a6a70;font-style:italic;padding-bottom:6px;border-bottom:1px dashed rgba(255,255,255,0.05);margin-bottom:8px;">' + app.escapeHtml(r.hidden) + '</div>' : '';

                    // 类型图标（从 typeIcon 取，没有则用 avatar）
                    var typeIcon = r.typeIcon || r.avatar || '💎';

                    var cardHtml = '<div onclick="MlifeApp.navigate(\'recruit_detail\',{code:\'' + app.escapeHtml(r.code) + '\',_recruits:MlifeApp.__lastRecruitData})" style="background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:12px;padding:14px 16px;margin-bottom:10px;cursor:pointer;transition:all 0.2s;" onmouseover="this.style.borderColor=\'rgba(201,169,110,0.3)\';this.style.background=\'#2a2a32\'" onmouseout="this.style.borderColor=\'rgba(201,169,110,0.12)\';this.style.background=\'#222228\'">'
                        + hiddenHtml
                        + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">'
                        + '<span style="font-size:18px;flex-shrink:0;">' + typeIcon + '</span>'
                        + '<span style="flex:1;font-size:15px;font-weight:600;color:#e5e5e7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">' + app.escapeHtml(r.title) + '</span>'
                        + (r.credit ? '<span style="font-size:10px;padding:2px 6px;border-radius:3px;background:rgba(201,169,110,0.1);color:#c9a96e;border:1px solid rgba(201,169,110,0.2);">信用' + app.escapeHtml(r.credit) + '</span>' : '')
                        + statusLabel
                        + '</div>'
                        + tagsHtml
                        + '<div style="display:flex;align-items:center;justify-content:space-between;padding-top:6px;border-top:1px solid rgba(201,169,110,0.08);">'
                        + '<span style="font-size:12px;color:#6a6a70;">👥 ' + (r.applicants || 0) + '人报名</span>'
                        + '<span style="font-size:14px;font-weight:600;color:#c9a96e;">' + (r.budget || r.reward || '') + '</span>'
                        + '</div>'
                        + '</div>';

                    cards.push(cardHtml);
                }

                // 保存数据供筛选按钮使用
                app.__lastRecruitData = recruits;

                var html = '<div style="padding:0;">'
                    + filterBarHtml
                    + '<div style="padding:12px 16px;display:flex;flex-direction:column;gap:0;">'
                    + cards.join('\n')
                    + (filtered.length === 0 ? '<div style="padding:30px;text-align:center;color:#6a6a70;font-size:14px;">暂无符合条件的招募</div>' : '')
                    + '</div></div>';
                MlifeApp.updateCache('recruit_list', html);
                return html;
            };
