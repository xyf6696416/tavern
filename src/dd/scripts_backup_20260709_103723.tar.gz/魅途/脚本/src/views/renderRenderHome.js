
            app.renderHome = function(data) {
                if (!data || !data.posts || data.posts.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无动态</div>';
                }

                var posts = data.posts;
                var cards = [];

                for (var i = 0; i < posts.length; i++) {
                    var p = posts[i];
                    var hiddenComment = '<!-- hidden: ' + (p.hidden || '') + ' -->\n';

                    // 头像 + 昵称行
                    var headerHtml = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">'
                        + '<span style="font-size:32px;width:40px;text-align:center;line-height:40px;">' + (p.avatar || '') + '</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                        + '<span style="font-weight:bold;font-size:15px;color:var(--ml-text);">' + app.escapeHtml(p.nick || '') + '</span>'
                        + '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(p.level || '') + '</span>'
                        + (p.vip && p.vip !== '无'
                            ? '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;">' + app.escapeHtml(p.vip) + '</span>'
                            : '')
                        + '</div>'
                        + '<div style="font-size:12px;color:var(--ml-text-dim);margin-top:3px;">'
                        + app.escapeHtml(p.time || '') + ' &middot; ' + app.escapeHtml(p.section || '')
                        + '</div>'
                        + '</div>'
                        + '</div>';

                    // 正文
                    var bodyHtml = p.body
                        ? '<div style="font-size:14px;color:var(--ml-text-main);line-height:1.6;margin-bottom:10px;white-space:pre-wrap;">' + app.escapeHtml(p.body) + '</div>'
                        : '';

                    // 图片描述
                    var imagesHtml = '';
                    if (p.images && p.images.length > 0) {
                        imagesHtml = '<div style="margin-bottom:10px;">';
                        for (var j = 0; j < p.images.length; j++) {
                            var img = p.images[j];
                            imagesHtml += '<div style="background:var(--ml-bg-section);border-radius:8px;padding:10px;margin-bottom:6px;font-size:13px;color:var(--ml-text-aaa);border:1px solid var(--ml-border);border-left:3px solid #ff6b9d;">'
                                + '<span style="color:var(--ml-accent);margin-right:6px;">&#x1F5BC;</span>'
                                + app.escapeHtml(img.desc || '')
                                + '</div>';
                        }
                        imagesHtml += '</div>';
                    }

                    // 付费墙
                    var paywallHtml = '';
                    if (p.paywall && p.paywall !== '无') {
                        paywallHtml = '<div style="margin-bottom:10px;padding:8px 12px;border-radius:8px;background:linear-gradient(135deg,#2a1a1a,#1a1a2e);border:1px solid #ff6b9d;color:var(--ml-accent);font-size:13px;display:flex;align-items:center;gap:8px;">'
                            + '<span>&#x1F512;</span>'
                            + app.escapeHtml(p.paywall)
                            + '</div>';
                    }

                    // 统计行
                    var statsHtml = '<div style="display:flex;gap:16px;margin-bottom:10px;font-size:13px;color:var(--ml-text-dim);">'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-accent);">&#x2764;</span> ' + p.likes + '</span>'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-cyan);">&#x1F4AC;</span> ' + p.comments + '</span>'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-text-dim);">&#x21AA;</span> ' + p.shares + '</span>'
                        + '</div>';

                    // 交互按钮
                    var actionsHtml = '<div style="display:flex;gap:8px;margin-bottom:10px;">'
                        + '<button onclick="MlifeApp.action(\'/send 点赞|献稻制作|触发\')" style="flex:1;padding:8px;border-radius:8px;border:1px solid var(--ml-border);background:var(--ml-bg-card);color:var(--ml-accent);font-size:13px;cursor:pointer;font-family:inherit;transition:background 0.2s;">&#x2764; 点赞</button>'
                        + '<button onclick="MlifeApp.action(\'/send 查看评论|献稻制作|触发\')" style="flex:1;padding:8px;border-radius:8px;border:1px solid var(--ml-border);background:var(--ml-bg-card);color:var(--ml-cyan);font-size:13px;cursor:pointer;font-family:inherit;transition:background 0.2s;">&#x1F4AC; 评论</button>'
                        + '</div>';

                    // 热评
                    var hotCommentsHtml = '';
                    if (p.hotComments && p.hotComments.length > 0) {
                        hotCommentsHtml = '<div style="background:var(--ml-bg-info);border-radius:8px;padding:8px 12px;">';
                        for (var k = 0; k < p.hotComments.length; k++) {
                            var hc = p.hotComments[k];
                            hotCommentsHtml += '<div style="font-size:13px;color:var(--ml-text-ccc);padding:4px 0;' + (k > 0 ? 'border-top:1px solid #1e1e2e;' : '') + '">'
                                + '<span style="color:var(--ml-accent);font-weight:bold;">' + app.escapeHtml(hc.name || '') + '</span>'
                                + '<span style="color:var(--ml-text-dim);margin:0 4px;">:</span>'
                                + '<span>' + app.escapeHtml(hc.text || '') + '</span>'
                                + '</div>';
                        }
                        hotCommentsHtml += '</div>';
                    }

                    // 组装卡片
                    var cardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                        + hiddenComment
                        + headerHtml
                        + bodyHtml
                        + imagesHtml
                        + paywallHtml
                        + statsHtml
                        + actionsHtml
                        + hotCommentsHtml
                        + '</div>';

                    cards.push(cardHtml);
                }

                var html = '<div style="padding:0;">' + cards.join('\n') + '</div>';
                MlifeApp.updateCache('home', html);
                return html;
            };
