             */
            app.renderSettings = function(data) {
                var vars = app.getMergedVars().stat_data || {};
                var mu = vars['M-life_用户'] || {};
                var social = vars['M-life_社交'] || {};
                var econ = vars['M-life_经济'] || {};
                var account = getCurrentAccount();

                var nick = mu.昵称 || '用户';
                var level = mu.用户等级 || 'Lv1';
                var vip = mu.VIP类型 || '无';
                var coins = econ.M币 || 0;

                var html = '<div style="padding:16px;">'

                    // 用户信息摘要
                    + '<div style="text-align:center;padding:16px 0;border-bottom:1px solid var(--ml-border);margin-bottom:12px;">'
                    + '<div style="font-size:20px;font-weight:bold;color:var(--ml-text);">' + app.escapeHtml(nick) + '</div>'
                    + '<div style="display:flex;align-items:center;justify-content:center;gap:8px;margin-top:6px;font-size:12px;">'
                    + '<span style="padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(level) + '</span>'
                    + (vip && vip !== '无'
                        ? '<span style="padding:1px 7px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;">' + app.escapeHtml(vip) + 'VIP</span>'
                        : '<span style="padding:1px 7px;border-radius:3px;background:#333;color:#999;">未开通VIP</span>')
                    + '</div>'
                    + '</div>'

                    // 账号切换
                    + '<div style="background:var(--ml-bg-section);border-radius:8px;padding:12px;margin-bottom:12px;">'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);margin-bottom:8px;">🔄 切换账号</div>'
                    + '<select style="width:100%;background:var(--ml-bg-info);color:var(--ml-text-main);border:1px solid #2a2a3e;border-radius:6px;padding:8px 10px;font-size:14px;font-family:inherit;cursor:pointer;outline:none;box-sizing:border-box;"'
                    + ' onchange="MlifeApp.switchAccount(this.value)">'
                    + app.ACCOUNTS.map(function(a) {
                        return '<option value="' + a.id + '"' + (a.id === (account && account.id) ? ' selected' : '') + '>'
                            + a.emoji + ' ' + app.escapeHtml(a.label)
                            + '</option>';
                      }).join('')
                    + '</select>'
                    + '</div>'

                    // 资产信息
                    + '<div style="background:var(--ml-bg-section);border-radius:8px;padding:12px;margin-bottom:12px;">'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);margin-bottom:8px;">💳 我的资产</div>'
                    + '<div style="display:flex;gap:16px;">'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:18px;font-weight:bold;color:#f6d365;">' + coins + '</div><div style="font-size:11px;color:var(--ml-text-dim);">M币</div></div>'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:18px;font-weight:bold;color:#34d399;">' + (parseInt(social.关注数) || 0) + '</div><div style="font-size:11px;color:var(--ml-text-dim);">关注</div></div>'
                    + '<div style="flex:1;text-align:center;"><div style="font-size:18px;font-weight:bold;color:var(--ml-accent);">' + (parseInt(social.粉丝数) || 0) + '</div><div style="font-size:11px;color:var(--ml-text-dim);">粉丝</div></div>'
                    + '</div>'
                    + '</div>'

                    // 主题切换
                    + '<div style="display:flex;align-items:center;justify-content:space-between;background:var(--ml-bg-section);border-radius:8px;padding:12px;margin-bottom:12px;">'
                    + '<span style="font-size:14px;color:var(--ml-text-main);">🌓 主题模式</span>'
                    + '<span style="font-size:13px;color:var(--ml-text-dim);">点击 🌙/☀️ 切换</span>'
                    + '</div>'

                    // 状态信息
                    + '<div style="background:var(--ml-bg-section);border-radius:8px;padding:12px;margin-bottom:12px;">'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);margin-bottom:8px;">📊 状态</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-main);padding:4px 0;">签到：' + (social.今日已签到 === 'true' ? '✅ 已签到' : '⬜ 未签到') + '</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-main);padding:4px 0;">连签：' + (parseInt(social.连续签到天数) || 0) + ' 天</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-main);padding:4px 0;">今日获赞：' + (parseInt(social.今日获赞) || 0) + '</div>'
                    + '</div>'

                    + '</div>';

                MlifeApp.updateCache('settings', html);
                return html;
            };
