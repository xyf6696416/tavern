
            app.renderResource = function(data) {
                if (!data || !data.posts || data.posts.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无资源分享</div>';
                }

                var posts = data.posts;
                var cards = [];

                for (var i = 0; i < posts.length; i++) {
                    var p = posts[i];
                    var hiddenComment = '<!-- hidden: ' + app.escapeHtml(p.hidden || '') + ' -->\n';

                    // 头像 + 昵称 + 等级
                    var headerHtml = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">'
                        + '<span style="font-size:32px;width:40px;text-align:center;line-height:40px;">' + (p.avatar || '📦') + '</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                        + '<span style="font-weight:bold;font-size:15px;color:var(--ml-text);">' + app.escapeHtml(p.nick || '') + '</span>'
                        + '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(p.level || '') + '</span>'
                        + '</div>'
                        + '<div style="font-size:12px;color:var(--ml-text-dim);margin-top:2px;">' + app.escapeHtml(p.time || '') + '</div>'
                        + '</div>'
                        + '</div>';

                    // 资源标题（突出显示，更大字号）
                    var titleHtml = p.title
                        ? '<div style="font-size:17px;font-weight:bold;color:#f0e6d0;margin-bottom:6px;line-height:1.4;">'
                            + app.escapeHtml(p.title) + '</div>'
                        : '';

                    // 正文
                    var bodyHtml = p.body
                        ? '<div style="font-size:14px;color:var(--ml-text-ccc);line-height:1.6;margin-bottom:8px;white-space:pre-wrap;">'
                            + app.escapeHtml(p.body) + '</div>'
                        : '';

                    // 文件大小 + 格式标签
                    var fileInfoHtml = '';
                    if (p.size || p.format) {
                        fileInfoHtml = '<div style="display:flex;gap:8px;margin-bottom:8px;">';
                        if (p.size) {
                            fileInfoHtml += '<span style="font-size:12px;padding:2px 8px;border-radius:4px;background:#1a2a3a;color:#66ccff;border:1px solid #2a4a6a;">'
                                + app.escapeHtml(p.size) + '</span>';
                        }
                        if (p.format) {
                            fileInfoHtml += '<span style="font-size:12px;padding:2px 8px;border-radius:4px;background:#2a1a1a;color:#ff8866;border:1px solid #4a2a2a;">'
                                + app.escapeHtml(p.format) + '</span>';
                        }
                        if (p.price && p.price !== '无') {
                            var priceColor = p.price.indexOf('免费') !== -1 ? '#66dd88' : '#ffcc44';
                            fileInfoHtml += '<span style="font-size:12px;padding:2px 8px;border-radius:4px;background:#1a2a1a;color:' + priceColor + ';border:1px solid #2a4a2a;">'
                                + app.escapeHtml(p.price) + '</span>';
                        }
                        fileInfoHtml += '</div>';
                    }

                    // 统计行
                    var statsHtml = '<div style="display:flex;gap:16px;margin-bottom:8px;font-size:13px;color:var(--ml-text-dim);">'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-accent);">&#x2764;</span> ' + (p.likes || 0) + '</span>'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-cyan);">&#x1F4AC;</span> ' + (p.comments || 0) + '</span>'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:#88dd88;">&#x2B07;</span> ' + (p.downloads || 0) + '</span>'
                        + '</div>';

                    // "下载" 按钮
                    var actionsHtml = '<div style="display:flex;gap:8px;margin-bottom:0;">'
                        + '<button onclick="MlifeApp.action(\'/send 下载资源|/trigger\')" style="flex:1;padding:10px;border-radius:8px;border:1px solid #2a6a4a;background:linear-gradient(135deg,#1a3a2a,#0d2618);color:#66dd88;font-size:14px;font-weight:bold;cursor:pointer;font-family:inherit;transition:background 0.2s;">&#x2B07; 下载</button>'
                        + '</div>';

                    // 组装卡片
                    var cardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                        + hiddenComment
                        + headerHtml
                        + titleHtml
                        + bodyHtml
                        + fileInfoHtml
                        + statsHtml
                        + actionsHtml
                        + '</div>';

                    cards.push(cardHtml);
                }

                var html = '<div style="padding:0;">' + cards.join('\n') + '</div>';
                MlifeApp.updateCache('resource', html);
                return html;
            };
