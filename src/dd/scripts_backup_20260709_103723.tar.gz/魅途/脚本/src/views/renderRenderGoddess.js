
            app.renderGoddess = function(data) {
                if (!data || !data.board || !data.profiles || data.profiles.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无女神档案</div>';
                }

                var board = data.board;
                var profiles = data.profiles;

                // 板块标题 + Tab
                var tabBtns = [
                    { label: '&#x1F525; 热帖', tab: '热帖' },
                    { label: '&#x1F4F0; 最新', tab: '最新' },
                    { label: '&#x1F3C6; 精选', tab: '每周精选' }
                ];
                var tabsHtml = '';
                for (var ti = 0; ti < tabBtns.length; ti++) {
                    var t = tabBtns[ti];
                    var isActive = (board.tab === t.tab);
                    tabsHtml += '<span style="padding:4px 16px;border-radius:16px;font-size:12px;cursor:pointer;' + (isActive ? 'background:#ff6b9d;color:#fff;font-weight:bold;' : 'background:var(--ml-bg-section);color:var(--ml-text-dim);') + '" onclick="MlifeApp.action(\'/send 切换到' + t.tab + '|/trigger\')">' + t.label + '</span>';
                }

                var boardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                    + '<div style="font-size:16px;font-weight:bold;color:var(--ml-accent);text-align:center;margin-bottom:10px;">' + app.escapeHtml(board.name || '女神夜话') + '</div>'
                    + '<div style="display:flex;gap:8px;justify-content:center;">' + tabsHtml + '</div>'
                    + '</div>';

                var cards = [];

                for (var i = 0; i < profiles.length; i++) {
                    var p = profiles[i];

                    // 评分颜色编码
                    var scoreColor = '#2ed573';
                    if (p.score < 6) scoreColor = '#ff4757';
                    else if (p.score < 8) scoreColor = '#ffa502';

                    // 标签
                    var tagsHtml = '';
                    if (p.tags && p.tags.length > 0) {
                        tagsHtml = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin:8px 0;">';
                        for (var tj = 0; tj < p.tags.length; tj++) {
                            var tag = p.tags[tj] || '';
                            var tagColor = '#2ed573';
                            var negativeKeywords = ['差', '不行', '冷', '敷衍', '快', '小', '不好', '一般', '粗鲁'];
                            for (var nk = 0; nk < negativeKeywords.length; nk++) {
                                if (tag.indexOf(negativeKeywords[nk]) !== -1) { tagColor = '#ff4757'; break; }
                            }
                            var neutralKeywords = ['普通', '还行', '凑合'];
                            for (var nuk = 0; nuk < neutralKeywords.length; nuk++) {
                                if (tag.indexOf(neutralKeywords[nuk]) !== -1) { tagColor = '#8a8a9a'; break; }
                            }
                            tagsHtml += '<span style="font-size:11px;padding:2px 10px;border-radius:10px;background:' + tagColor + '20;border:1px solid ' + tagColor + ';color:' + tagColor + ';">' + app.escapeHtml(tag) + '</span>';
                        }
                        tagsHtml += '</div>';
                    }

                    // 评价列表
                    var reviewsHtml = '';
                    if (p.reviews && p.reviews.length > 0) {
                        reviewsHtml = '<div style="margin-top:10px;background:var(--ml-bg-info);border-radius:8px;padding:10px;">'
                            + '<div style="font-size:12px;color:var(--ml-text-dim);margin-bottom:6px;">&#x1F4AC; 评价 (' + p.reviews.length + ')</div>';
                        for (var rj = 0; rj < Math.min(p.reviews.length, 5); rj++) {
                            var rv = p.reviews[rj];
                            reviewsHtml += '<div style="font-size:13px;color:var(--ml-text-ccc);padding:4px 0;' + (rj > 0 ? 'border-top:1px solid #1e1e2e;' : '') + '">'
                                + '<span style="color:var(--ml-accent);font-weight:bold;">' + app.escapeHtml(rv.author || '匿名') + '</span>'
                                + '<span style="color:var(--ml-text-dim);margin:0 4px;">:</span>'
                                + '<span>' + app.escapeHtml(rv.text || '') + '</span>'
                                + '</div>';
                        }
                        if (p.reviews.length > 5) {
                            reviewsHtml += '<div style="font-size:12px;color:var(--ml-text-dim);text-align:center;padding-top:4px;cursor:pointer;" onclick="MlifeApp.action(\'/send 查看更多评价|/trigger\')">查看更多 (' + (p.reviews.length - 5) + ' 条)...</div>';
                        }
                        reviewsHtml += '</div>';
                    }

                    var cardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                        + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">'
                        + '<span style="font-size:36px;width:44px;text-align:center;line-height:44px;">' + (p.avatar || '') + '</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                        + '<span style="font-weight:bold;font-size:15px;color:var(--ml-text);">' + app.escapeHtml(p.nick || '') + '</span>'
                        + '<span style="font-size:12px;color:var(--ml-text-dim);">' + (p.age || '') + '岁</span>'
                        + '<span style="font-size:14px;font-weight:bold;color:' + scoreColor + ';">' + (p.score || '') + '</span>'
                        + '</div>'
                        + '<div style="font-size:13px;color:#f6d365;font-weight:bold;margin-top:2px;">' + app.escapeHtml(p.price || '') + '</div>'
                        + '</div>'
                        + '</div>'
                        + (p.intro ? '<div style="font-size:13px;color:var(--ml-text-aaa);line-height:1.5;margin-bottom:4px;">' + app.escapeHtml(p.intro) + '</div>' : '')
                        + tagsHtml
                        + reviewsHtml
                        + '<div style="display:flex;gap:8px;margin-top:10px;">'
                        + '<button onclick="MlifeApp.action(\'/send 约' + encodeURIComponent(p.nick || '') + '|/trigger\')" style="flex:1;padding:8px;border-radius:8px;border:none;background:linear-gradient(135deg,#ff6b9d,#ff4757);color:#fff;font-size:13px;cursor:pointer;font-family:inherit;font-weight:bold;">&#x2764; 预约</button>'
                        + '<button onclick="MlifeApp.action(\'/send 查看' + encodeURIComponent(p.nick || '') + '详情|/trigger\')" style="flex:1;padding:8px;border-radius:8px;border:1px solid var(--ml-border);background:#0a0a14;color:var(--ml-cyan);font-size:13px;cursor:pointer;font-family:inherit;">&#x1F50D; 详情</button>'
                        + '</div>'
                        + '</div>';

                    cards.push(cardHtml);
                }

                var html = '<div style="padding:0;">' + boardHtml + cards.join('\n') + '</div>';
                MlifeApp.updateCache('goddess', html);
                return html;
            };
