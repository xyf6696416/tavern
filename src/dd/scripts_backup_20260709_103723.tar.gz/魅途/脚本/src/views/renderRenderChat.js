
            app.renderChat = function(data) {
                if (!data || !data.posts || data.posts.length === 0) {
                    return '<div style="padding:30px;text-align:center;color:var(--ml-text-dim);font-size:14px;">暂无帖子</div>';
                }

                var posts = data.posts;
                var cards = [];

                for (var i = 0; i < posts.length; i++) {
                    var p = posts[i];
                    var hiddenComment = '<!-- hidden: ' + app.escapeHtml(p.hidden || '') + ' -->\n';

                    // 头像 + 昵称 + 等级 + 时间
                    var headerHtml = '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">'
                        + '<span style="font-size:28px;width:36px;text-align:center;line-height:36px;">' + (p.avatar || '💬') + '</span>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'
                        + '<span style="font-weight:bold;font-size:14px;color:var(--ml-text);">' + app.escapeHtml(p.nick || '') + '</span>'
                        + '<span style="font-size:11px;padding:1px 7px;border-radius:3px;background:#ff6b9d;color:#fff;font-weight:bold;">' + app.escapeHtml(p.level || '') + '</span>'
                        + (p.vip && p.vip !== '无'
                            ? '<span style="font-size:10px;padding:1px 6px;border-radius:3px;background:var(--ml-gold);color:#1a1a1a;font-weight:bold;">' + app.escapeHtml(p.vip) + '</span>'
                            : '')
                        + '</div>'
                        + '<div style="font-size:12px;color:var(--ml-text-dim);margin-top:2px;">' + app.escapeHtml(p.time || '') + '</div>'
                        + '</div>'
                        + '</div>';

                    // 帖子标题（粗体，大字号）
                    var titleHtml = p.title
                        ? '<div style="font-size:16px;font-weight:bold;color:#f0e6d0;margin-bottom:6px;line-height:1.4;">'
                            + app.escapeHtml(p.title) + '</div>'
                        : '';

                    // 正文摘要
                    var bodyHtml = p.body
                        ? '<div style="font-size:14px;color:var(--ml-text-ccc);line-height:1.6;margin-bottom:8px;white-space:pre-wrap;">'
                            + app.escapeHtml(p.body) + '</div>'
                        : '';

                    // 投票
                    var pollHtml = '';
                    if (p.poll && p.poll.options && p.poll.options.length > 0) {
                        pollHtml = '<div style="background:var(--ml-bg-info);border-radius:8px;padding:8px 12px;margin-bottom:8px;border:1px solid var(--ml-border);">';
                        for (var k = 0; k < p.poll.options.length; k++) {
                            var opt = p.poll.options[k];
                            var pct = opt.percent || 0;
                            var barColor = k % 2 === 0 ? '#ff6b9d' : '#00e5ff';
                            pollHtml += '<div style="font-size:13px;color:var(--ml-text-ccc);margin-bottom:4px;">'
                                + '<div style="display:flex;justify-content:space-between;margin-bottom:2px;">'
                                + '<span>' + app.escapeHtml(opt.label || '') + '</span>'
                                + '<span style="color:' + barColor + ';">' + pct + '%</span>'
                                + '</div>'
                                + '<div style="height:6px;border-radius:3px;background:var(--ml-bg-section);overflow:hidden;">'
                                + '<div style="height:100%;width:' + pct + '%;border-radius:3px;background:' + barColor + ';transition:width 0.3s;"></div>'
                                + '</div>'
                                + '</div>';
                        }
                        if (p.poll.totalVotes) {
                            pollHtml += '<div style="font-size:11px;color:var(--ml-text-dimmer);margin-top:4px;">共 ' + p.poll.totalVotes + ' 人参与</div>';
                        }
                        pollHtml += '</div>';
                    }

                    // 热评
                    var hotCommentsHtml = '';
                    if (p.hotComments && p.hotComments.length > 0) {
                        hotCommentsHtml = '<div style="background:var(--ml-bg-info);border-radius:8px;padding:6px 10px;margin-bottom:8px;">';
                        for (var m = 0; m < p.hotComments.length; m++) {
                            var hc = p.hotComments[m];
                            hotCommentsHtml += '<div style="font-size:12px;color:var(--ml-text-bbb);padding:3px 0;' + (m > 0 ? 'border-top:1px solid #1e1e2e;' : '') + '">'
                                + '<span style="color:var(--ml-accent);font-weight:bold;">' + app.escapeHtml(hc.name || '') + '</span>'
                                + '<span style="color:var(--ml-text-dimmer);margin:0 4px;">:</span>'
                                + '<span>' + app.escapeHtml(hc.text || '') + '</span>'
                                + '</div>';
                        }
                        hotCommentsHtml += '</div>';
                    }

                    // 统计行
                    var statsHtml = '<div style="display:flex;gap:16px;margin-bottom:8px;font-size:13px;color:var(--ml-text-dim);">'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-cyan);">&#x1F4AC;</span> ' + (p.replies || 0) + '</span>'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-text-dim);">&#x1F441;</span> ' + (p.views || 0) + '</span>'
                        + '<span style="display:flex;align-items:center;gap:4px;"><span style="color:var(--ml-accent);">&#x2764;</span> ' + (p.likes || 0) + '</span>'
                        + '</div>';

                    // "回帖" 按钮
                    var actionsHtml = '<div style="display:flex;gap:8px;margin-bottom:0;">'
                        + '<button onclick="MlifeApp.action(\'/send 回复帖子|/trigger\')" style="flex:1;padding:10px;border-radius:8px;border:1px solid #2a4a6a;background:linear-gradient(135deg,#1a2a3a,#0d1826);color:#66ccff;font-size:14px;font-weight:bold;cursor:pointer;font-family:inherit;transition:background 0.2s;">&#x1F4AC; 回帖</button>'
                        + '</div>';

                    // 组装卡片
                    var cardHtml = '<div style="background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;">'
                        + hiddenComment
                        + headerHtml
                        + titleHtml
                        + bodyHtml
                        + pollHtml
                        + hotCommentsHtml
                        + statsHtml
                        + actionsHtml
                        + '</div>';

                    cards.push(cardHtml);
                }

                var html = '<div style="padding:0;">' + cards.join('\n') + '</div>';
                MlifeApp.updateCache('chat', html);
                return html;
            };
