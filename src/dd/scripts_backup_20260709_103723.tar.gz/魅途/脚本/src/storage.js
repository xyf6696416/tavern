// ===== src/storage.js =====
// 薄封装：与 window.localStorage 逐字等价，仅做闭包内统一入口。
// 调用点的 try/catch 保持不变，行为零变化。
var mlifeStorage = {
  get: function (k) { return localStorage.getItem(k); },
  set: function (k, v) { localStorage.setItem(k, v); },
  remove: function (k) { localStorage.removeItem(k); }
};
