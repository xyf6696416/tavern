// ===== src/escape.js =====
// HTML 转义（原 app.escapeHtml，731 行）。
// 全量转义 & < > " '，MlifeApp 主模块通过 app.escapeHtml 桥接使用。
// 注：原 DM_Manager 的 esc（子集转义 & < >）经核查零调用点，已于 Phase 2 删除。
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
