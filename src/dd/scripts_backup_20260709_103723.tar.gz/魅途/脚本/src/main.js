// MLIFE_SELF_CONTAINED
// M-life TH — 自包含脚本，刷新自动生效
(function(){"use strict";

// === 自注入（TH iframe type=module 中运行）===
if(window.top&&window.top!==window.self){
  try{
    var _scripts=document.querySelectorAll("script[type=module]");
    for(var _i=0;_i<_scripts.length;_i++){
      var _t=_scripts[_i].textContent||"";
      if(_t.indexOf("MLIFE_SELF_CONTAINED")>=0){
        var _inj=window.top.document.createElement("script");
        _inj.textContent=_t;
        window.top.document.head.appendChild(_inj);
        break;
      }
    }
  }catch(_e){}
  return;
}

// === 主页面执行 ===
if(window.__MLIFE_BOOTLOADED&&typeof window.MlifeApp!=="undefined")return;
window.__MLIFE_BOOTLOADED=true;

// ==================== M-life All-in-One ====================
// Auto-boots: shows a floating diamond, click to open M-life phone UI
// ============================================================

// [1] MlifeApp Engine
        // ============================================================
        // 全局 SPA 引擎 — window.MlifeApp
        // ============================================================
        window.MlifeApp = (function() {
            'use strict';

            var app = {};
            /*__MLIFE_VIEWS__*/

            // ---- 状态 ----
            app.config = null;
            app.currentPage = null;
            app.tabCache = {};
            app.__heiJinMode = false; // 黑金之选独立模式标志位
            app.__accountId = null;   // 当前选中账号 ID

            /**
             * 内置账号配置（替代世界书 {{user}} 描述）
             * 每个账号包含完整的 stat_data 覆盖值 + 用户描述文本
             */
            app.ACCOUNTS = [
                {
                    id: 'normal',
                    label: '残酷月光 · 打工人',
                    emoji: '🧑‍💼',
                    desc: (
                        '{{user}}身份锁定: 普通打工人、经济条件一般、单身男性，使用软件排解寂寞。一切互动据此展开。\n\n'
                        + '角色档案:\n'
                        + '  基本信息:\n'
                        + '    姓名: {{user}}\n'
                        + '    年龄: 26岁\n'
                        + '    籍贯: 山东青岛\n'
                        + '    现居: 上海\n'
                        + '    工作: 某国企办公室行政文员\n'
                        + '    月收入: 到手一万出头\n'
                        + '    M-life昵称: 残酷月光\n'
                        + '    M-life等级: Lv3\n'
                        + '  居住: 松江区老小区一居室，月租三千五\n'
                        + '  体态: 176cm，健身三年，肩宽腰窄，有明显线条\n'
                        + '  日常: 下班健身、自己做饭、周末偶尔打球\n'
                        + '  经济: 精打细算，每月剩一两千\n'
                    ),
                    stats: {
                        'M-life_用户': { 用户等级: 'Lv3', VIP类型: '无', 昵称: '残酷月光', 年龄: '26' },
                        'M-life_社交': { 获赞总数: '128', 粉丝数: '46', 关注数: '32', 今日已签到: 'false', 连续签到天数: '0' },
                        'M-life_经济': { M币余额: '320', 累计充值: '500' },
                        'M-life_黑金': { 进行中招募数: '0', 已报名招募数: '0' },
                    }
                },
                {
                    id: 'rich',
                    label: '残酷月光 · 高富帅',
                    emoji: '🕶️',
                    desc: (
                        '{{user}}身份锁定: 高知、经济条件极佳、单身帅气男性，自媒体博主。一切互动据此展开。\n\n'
                        + '角色档案:\n'
                        + '  基本信息:\n'
                        + '    姓名: {{user}}\n'
                        + '    年龄: 26岁\n'
                        + '    工作: 自媒体博主，全网50万粉\n'
                        + '    M-life昵称: 残酷月光\n'
                        + '    M-life等级: Lv5\n'
                        + '  体态: 178cm，肌肉线条流畅，健身房常客\n'
                        + '  居住: 200平大平层，奥迪RS7\n'
                        + '  日常: 拍摄、剪片、健身、做菜放松\n'
                        + '  经济: 商单+家里支持，条件优渥\n'
                    ),
                    stats: {
                        'M-life_用户': { 用户等级: 'Lv5', VIP类型: '黑金', 昵称: '残酷月光', 年龄: '26' },
                        'M-life_社交': { 获赞总数: '8826', 粉丝数: '1200', 关注数: '280', 今日已签到: 'false', 连续签到天数: '0' },
                        'M-life_经济': { M币余额: '3818198', 累计充值: '5000000' },
                        'M-life_黑金': { 进行中招募数: '3', 已报名招募数: '2' },
                    }
                }
            ];

            /**
             * 获取当前选中账号
             */
            function getCurrentAccount() {
                if (!app.__accountId) {
                    try { app.__accountId = mlifeStorage.get(STORAGE_KEYS.ACCOUNT) || 'normal'; } catch(_) { app.__accountId = 'normal'; }
                }
                return app.ACCOUNTS.find(function(a) { return a.id === app.__accountId; }) || app.ACCOUNTS[0];
            }

            /**
             * 切换账号
             */
            app.switchAccount = function(accountId) {
                var account = app.ACCOUNTS.find(function(a) { return a.id === accountId; });
                if (!account) return false;
                app.__accountId = accountId;
                try { mlifeStorage.set(STORAGE_KEYS.ACCOUNT, accountId); } catch(_) {}
                // 清空页面缓存，强制重新渲染
                app.tabCache = {};
                // 回到首页刷新
                app.switchTab('profile');
                return true;
            };

            /**
             * 获取账号覆盖后的变量数据
             * 优先从 Mvu 系统读取，用账号数据覆盖
             * 返回 { stat_data: {...} } 格式
             */
            app.getMergedVars = function() {
                var base = { stat_data: {} };
                // 1. 从 Mvu 系统读（优先）
                try {
                    if (typeof Mvu !== 'undefined' && typeof Mvu.getMvuVariable === 'function') {
                        var rawData = null;
                        try { rawData = Mvu.getMvuData(); } catch(_) {}
                        if (rawData && rawData.stat_data) {
                            base = rawData;
                        }
                    }
                } catch(_) {}
                // 2. 用账号数据覆盖
                var account = getCurrentAccount();
                if (account && account.stats) {
                    var sd = base.stat_data || {};
                    Object.keys(account.stats).forEach(function(key) {
                        sd[key] = Object.assign({}, sd[key] || {}, account.stats[key]);
                    });
                    base.stat_data = sd;
                }
                return base;
            };

            /**
             * 写入变量到 Mvu 系统
             * path: 'M-life_经济.M币余额'
             * value: '500'
             */
            app.setMergedVar = async function(path, value) {
                try {
                    if (typeof Mvu !== 'undefined' && typeof Mvu.setMvuVariable === 'function') {
                        var rawData = null;
                        try { rawData = Mvu.getMvuData(); } catch(_) {}
                        var data = rawData || { stat_data: {} };
                        if (!data.stat_data) data.stat_data = {};
                        await Mvu.setMvuVariable(data, path, value, { reason: 'mlife_update' });
                        return true;
                    }
                } catch(e) {
                    console.warn('[MlifeApp] setMergedVar error:', e);
                }
                return false;
            };

            // 辅助：hex 转 rgb 逗号格式（供 render 函数使用）
            app.hexToRgb = function(hex) {
                var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
                return result ? parseInt(result[1], 16) + ',' + parseInt(result[2], 16) + ',' + parseInt(result[3], 16) : '0,0,0';
            };

            // ---- JSON 解析辅助 ----
            function parseJsonData() {
                // 查找 textarea 中的 JSON（AI 通过 $1 占位符填入）
                var jsonStr = null;
                var ta = document.getElementById('mlife-json-data');
                if (ta) {
                    jsonStr = ta.value;
                }
                if (!jsonStr) {
                    // 尝试从 data- 属性读取
                    var container = document.getElementById('mlife-app');
                    if (container && container.dataset.json) {
                        jsonStr = container.dataset.json;
                    }
                }
                if (jsonStr) {
                    try {
                        return JSON.parse(jsonStr);
                    } catch (e) {
                        console.warn('[MlifeApp] JSON parse failed:', e);
                        return null;
                    }
                }
                return null;
            }

            // ---- 状态栏更新 ----
            function populateStatusBar() {
                // 独立模式：检查 Mvu 是否可用
                if (typeof Mvu === 'undefined' || typeof Mvu.getMvuVariable !== 'function') {
                    return;
                }
                var allVars = app.getMergedVars();

                function setText(id, path, fallback) {
                    var el = document.getElementById(id);
                    if (!el) return;
                    var val = _.get(allVars, path, fallback);
                    el.textContent = val;
                }

                setText('var-系统-日期', 'stat_data.系统.日期', '--');
                setText('var-系统-时间', 'stat_data.系统.时间', '--');
                setText('var-系统-位置', 'stat_data.系统.位置', '--');
                setText('var-mlife-容貌身材', 'stat_data.M-life.容貌身材', '--');
                setText('var-mlife-妆容配饰', 'stat_data.M-life.妆容配饰', '--');
                setText('var-mlife-穿着打扮', 'stat_data.M-life.穿着打扮', '--');
                setText('var-mlife-身体状态', 'stat_data.M-life.身体状态', '--');
            }

            app.refreshStatus = function() {
                populateStatusBar();
            };

            // ---- 通信封装 ----
            app.action = function(cmd) {
                if (typeof triggerSlash === 'function') {
                    triggerSlash(cmd);
                } else {
                    console.warn('[MlifeApp] triggerSlash not available');
                }
            };

            // ---- 持久化 ----
            app.saveDM = function(contact, data) {
                try {
                    mlifeStorage.set(STORAGE_KEYS.DM_THREAD + contact, JSON.stringify(data));
                } catch (e) {
                    console.warn('[MlifeApp] saveDM failed:', e);
                }
            };


            // ---- 招募帖子持久化 ----
            app.saveRecruitPost = function(post) {
                try {
                    var posts = JSON.parse(mlifeStorage.get(STORAGE_KEYS.RECRUIT_POSTS) || '[]');
                    posts.unshift(post);
                    mlifeStorage.set(STORAGE_KEYS.RECRUIT_POSTS, JSON.stringify(posts));
                    return true;
                } catch(e) {
                    console.warn('[MlifeApp] saveRecruitPost failed:', e);
                    return false;
                }
            };

            app.getRecruitPostById = function(id) {
                var posts = app.getRecruitPosts();
                for (var i = 0; i < posts.length; i++) {
                    if (posts[i].id === id) return posts[i];
                }
                return null;
            };

            app.cancelRecruitPost = function(id) {
                try {
                    var posts = app.getRecruitPosts();
                    for (var i = 0; i < posts.length; i++) {
                        if (posts[i].id === id) {
                            posts[i].status = '已取消';
                            posts[i].progress = '已主动取消';
                            mlifeStorage.set(STORAGE_KEYS.RECRUIT_POSTS, JSON.stringify(posts));
                            return true;
                        }
                    }
                } catch(e) { console.warn('[MlifeApp] cancelRecruitPost error:', e); }
                return false;
            };

            app.reactivateRecruitPost = function(id) {
                try {
                    var posts = app.getRecruitPosts();
                    for (var i = 0; i < posts.length; i++) {
                        if (posts[i].id === id) {
                            posts[i].status = '招募中';
                            posts[i].progress = '已重新发布';
                            mlifeStorage.set(STORAGE_KEYS.RECRUIT_POSTS, JSON.stringify(posts));
                            return true;
                        }
                    }
                } catch(e) { console.warn('[MlifeApp] reactivateRecruitPost error:', e); }
                return false;
            };

            /**
             * 从招募详情页发起私信：创建会话 → 生成人格 → AI 发第一条消息 → 跳转 DM
             */
            app.startDmWithApplicant = async function(applicant, recruitTitle) {
                try {
                    var contact = applicant.contactId || applicant.name;
                    var dm = window.DM_Manager;
                    if (!dm) { console.warn('[MlifeApp] DM_Manager not ready'); return; }

                    // 1. 检查是否已有会话
                    var existing = dm.getSessionMeta(contact);
                    if (existing && existing.msgCount > 0) {
                        // 已有对话 → 直接跳转
                        window.top.MlifeApp.navigate('dm', {contact: contact, avatar: applicant.avatar});
                        return;
                    }

                    // 2. 构建 personaExtra（应征者数据）
                    var personaExtra = {
                        name: applicant.name,
                        age: applicant.age,
                        city: applicant.city,
                        job: applicant.job || '',
                        personality: '温柔体贴',
                        chatStyle: '自然口语化',
                        attitude: '友好',
                        relationship: '刚认识（通过招募「' + (recruitTitle || '') + '」接触）',
                        tags: applicant.tags || [],
                        rating: applicant.rating,
                        bodyType: applicant.bodyType,
                        height: applicant.height,
                        selfIntro: applicant.selfIntro || '',
                        note: applicant.note || ''
                    };

                    // 3. 生成人格底座（buildPersonaPrompt 会自动缓存）
                    var personaPrompt = await dm.getOrCreatePersona(contact, applicant.avatar, personaExtra);

                    // 4. 构建第一句自我介绍
                    var introMessages = [
                        { role: 'system', content: personaPrompt },
                        { role: 'user', content: '你好～我看到你对招募「' + (recruitTitle || '') + '」感兴趣，我们开始聊天吧。请以你的身份主动发一段自我介绍，包括你的名字、基本情况、为什么想来这个招募、你的特点。自然口语化，2-4句话。' }
                    ];

                    // 5. 调 AI 生成自我介绍
                    var firstMsg = '';
                    try {
                        if (typeof dm.dmGenerate === 'function') {
                            firstMsg = await dm.dmGenerate(introMessages, personaPrompt);
                        }
                    } catch(_) {}
                    if (!firstMsg || firstMsg.length < 5) {
                        firstMsg = '你好～我是' + (applicant.name || '') + '，看到你的招募「' + (recruitTitle || '') + '」觉得挺合适的，想了解一下具体情况～';
                    }

                    // 6. 创建会话并写入第一条消息
                    var sess = dm.getOrCreateSession(contact, applicant.avatar);
                    if (sess) {
                        sess.messages.push({ role: 'assistant', content: firstMsg, time: new Date().toLocaleString() });
                        sess.personaPrompt = personaPrompt;
                        sess.updated = new Date().toLocaleString();
                        // 保存会话（DM_Manager 格式）
                        try {
                            var key = contact.toLowerCase().replace(/[^a-z0-9]/g, '_');
                            mlifeStorage.set(STORAGE_KEYS.DM_SESS + key, JSON.stringify(sess));
                        } catch(_) {}
                        // 同时保存到旧格式（renderDM 可读）
                        try {
                            var dmData = {contact: contact, avatar: applicant.avatar, messages: sess.messages || []};
                            mlifeStorage.set(STORAGE_KEYS.DM_THREAD + contact, JSON.stringify(dmData));
                        } catch(_) {}
                    }

                    // 7. 跳转到 DM
                    window.top.MlifeApp.navigate('dm', {contact: contact, avatar: applicant.avatar, fromRecruit: recruitTitle});

                } catch(e) {
                    console.warn('[MlifeApp] startDmWithApplicant error:', e);
                    // 出错时也尝试跳转
                    window.top.MlifeApp.navigate('dm', {contact: applicant.contactId || applicant.name, avatar: applicant.avatar});
                }
            };



            app.getRecruitPosts = function() {
                try {
                    return JSON.parse(mlifeStorage.get(STORAGE_KEYS.RECRUIT_POSTS) || '[]');
                } catch(e) {
                    return [];
                }
            };



            app.loadDM = function(contact) {
                try {
                    var raw = mlifeStorage.get(STORAGE_KEYS.DM_THREAD + contact);
                    return raw ? JSON.parse(raw) : null;
                } catch (e) {
                    console.warn('[MlifeApp] loadDM failed:', e);
                    return null;
                }
            };

            // ---- Tab 缓存 ----
            app.updateCache = function(page, data) {
                app.tabCache[page] = data;
            };

            app.getCached = function(page) {
                return app.tabCache[page] || null;
            };

            // ---- 页面渲染函数（stub） ----
            function renderStub(title) {
                return '<div style="padding: 20px; text-align: center; border: 1px dashed rgba(0,229,255,0.3); border-radius: 4px;">'
                    + '<span style="color: #008899; letter-spacing: 0.08em;">'
                    + title + '</span></div>';
            }



            // ---- HTML 转义辅助 ----
            app.escapeHtml = escapeHtml;  // 实现见 src/escape.js（外层闭包）

            /** 编码 data-person 属性值 */
            app.encPerson = function(data) {
                return encodeURIComponent(JSON.stringify(data));
            };

            /** 解码 data-person 属性值 */
            app.decPerson = function(str) {
                return JSON.parse(decodeURIComponent(str));
            };

            // ---- 用户操作菜单 (ActionSheet) ----
            app.showPersonMenu = function(person) {
                if (!person || !person.contact) return;
                app.closePersonMenu();

                var contact = app.escapeHtml(person.contact);
                var avatar = app.escapeHtml(person.avatar || '👤');
                var nick = app.escapeHtml(person.nick || person.contact);

                var overlay = document.createElement('div');
                overlay.id = 'mlife-action-overlay';
                overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:9999;';
                overlay.onclick = function() { app.closePersonMenu(); };
                document.body.appendChild(overlay);

                var sheet = document.createElement('div');
                sheet.id = 'mlife-action-sheet';
                sheet.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:var(--ml-bg-section);border-radius:16px 16px 0 0;padding:20px 16px;z-index:10000;animation:mlifeSlideUp 0.2s ease;max-width:500px;margin:0 auto;';
                sheet.innerHTML = ''
                    + '<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid #2a2a3e;">'
                    + '<span style="font-size:40px;width:48px;text-align:center;line-height:48px;">' + avatar + '</span>'
                    + '<div><div style="font-weight:bold;font-size:18px;color:var(--ml-text);">' + nick + '</div></div>'
                    + '</div>'
                    + '<button onclick="MlifeApp.closePersonMenu();MlifeApp.navigate(\'dm\',{contact:\'' + contact + '\',avatar:\'' + avatar + '\'})" style="width:100%;padding:14px;border-radius:12px;border:1px solid #ff6b9d;background:var(--ml-glow-10);color:var(--ml-accent);font-size:16px;cursor:pointer;margin-bottom:8px;font-family:inherit;">💬 发私信</button>'
                    + '<button onclick="MlifeApp.closePersonMenu()" style="width:100%;padding:14px;border-radius:12px;border:none;background:var(--ml-bg-hover);color:var(--ml-text-dim);font-size:16px;cursor:pointer;font-family:inherit;">取消</button>';
                document.body.appendChild(sheet);

                if (!document.getElementById('mlife-sheet-keyframe')) {
                    var style = document.createElement('style');
                    style.id = 'mlife-sheet-keyframe';
                    style.textContent = '@keyframes mlifeSlideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}';
                    document.head.appendChild(style);
                }
            };

            app.closePersonMenu = function() {
                var overlay = document.getElementById('mlife-action-overlay');
                if (overlay) overlay.remove();
                var sheet = document.getElementById('mlife-action-sheet');
                if (sheet) sheet.remove();
            };

            // ---- DM Tab 红点更新 ----
            app.updateDmTabBadge = function() {
                var total = 0;
                try {
                    if (typeof DM_Manager !== 'undefined' && DM_Manager.getTotalUnread) {
                        total = DM_Manager.getTotalUnread();
                    }
                } catch(_) {}
                var dmTab = document.getElementById('nav-dm');
                if (!dmTab) return;
                var existing = dmTab.querySelector('.badge');
                if (existing) existing.remove();
                if (total > 0) {
                    var badge = document.createElement('span');
                    badge.className = 'badge';
                    badge.textContent = total > 99 ? '99+' : total;
                    badge.style.cssText = 'position:absolute;top:-4px;right:-8px;background:#ff3b30;color:#fff;border-radius:50%;width:18px;height:18px;font-size:11px;text-align:center;line-height:18px;font-weight:bold;z-index:10;';
                    dmTab.style.position = 'relative';
                    dmTab.appendChild(badge);
                }
            };

            // ===================================================================
            // AI 内容生成子系统 — 骨架屏 + API 调用 + 渲染
            // ===================================================================

            /**
             * 注入 shimmer 动画 CSS
             */
            function injectShimmerStyle() {
                if (document.getElementById('mlife-shimmer-style')) return;
                var style = document.createElement('style');
                style.id = 'mlife-shimmer-style';
                style.textContent = [
                    '@keyframes mlifeShimmer{',
                    '0%{background-position:-200% 0}',
                    '100%{background-position:200% 0}',
                    '}',
                    '@keyframes mlifeFadeIn{',
                    'from{opacity:0.6}',
                    'to{opacity:1}',
                    '}',
                    '.mlf-shimmer{',
                    'background:linear-gradient(90deg,#1a1a2e 25%,#2a2a3e 50%,#1a1a2e 75%);',
                    'background-size:200% 100%;',
                    'animation:mlifeShimmer 1.5s infinite;',
                    'border-radius:6px;',
                    '}',
                    '.mlf-shimmer-card{',
                    'background:var(--ml-bg-card);border:1px solid var(--ml-border);border-radius:12px;padding:14px;margin-bottom:12px;',
                    'animation:mlifeFadeIn 0.3s ease;',
                    '}',
                    '.mlf-shimmer-avatar{',
                    'width:40px;height:40px;border-radius:50%;flex-shrink:0;',
                    '}',
                    '.mlf-shimmer-line{height:14px;margin-bottom:8px;}',
                    '.mlf-shimmer-line-sm{height:11px;width:60%;margin-bottom:6px;}',
                    '.mlf-shimmer-img{height:80px;border-radius:8px;margin-bottom:8px;}',
                    '.mlf-shimmer-btn{height:36px;border-radius:8px;flex:1;}',
                    '.mlf-shimmer-tag{height:22px;width:50px;border-radius:4px;display:inline-block;margin-right:6px;}',
                ].join('\n');
                document.head.appendChild(style);
            }

            /**
             * 骨架屏构建器 — 首页 (3 张 shimmer 卡片)
             */
            function skeletonHome() {
                var html = '';
                for (var i = 0; i < 3; i++) {
                    html += '<div class="mlf-shimmer-card">'
                        + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">'
                        + '<div class="mlf-shimmer mlf-shimmer-avatar"></div>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:45%;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line-sm"></div>'
                        + '</div></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:85%;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-img"></div>'
                        + '<div style="display:flex;gap:16px;margin:10px 0;">'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:40px;height:14px;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:40px;height:14px;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:40px;height:14px;"></div>'
                        + '</div>'
                        + '<div style="display:flex;gap:8px;">'
                        + '<div class="mlf-shimmer mlf-shimmer-btn"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-btn"></div>'
                        + '</div>'
                        + '</div>';
                }
                return html;
            }

            /**
             * 骨架屏构建器 — 匹配 (2 张 shimmer 卡片)
             */
            function skeletonMatch() {
                var html = '';
                for (var i = 0; i < 2; i++) {
                    html += '<div class="mlf-shimmer-card">'
                        + '<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">'
                        + '<div class="mlf-shimmer mlf-shimmer-avatar" style="width:48px;height:48px;"></div>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:35%;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line-sm" style="width:50%;"></div>'
                        + '</div></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:90%;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line-sm" style="width:40%;"></div>'
                        + '<div style="margin:10px 0;">'
                        + '<span class="mlf-shimmer mlf-shimmer-tag"></span>'
                        + '<span class="mlf-shimmer mlf-shimmer-tag"></span>'
                        + '<span class="mlf-shimmer mlf-shimmer-tag"></span>'
                        + '</div>'
                        + '<div style="display:flex;gap:8px;">'
                        + '<div class="mlf-shimmer mlf-shimmer-btn" style="height:40px;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-btn" style="height:40px;"></div>'
                        + '</div>'
                        + '</div>';
                }
                return html;
            }

            /**
             * 错误状态 HTML
             */
            function skeletonError(pageName, errMsg) {
                return '<div style="padding:40px 20px;text-align:center;">'
                    + '<div style="font-size:40px;margin-bottom:12px;">⚠️</div>'
                    + '<div style="color:var(--ml-accent);font-size:15px;font-weight:bold;margin-bottom:6px;">内容加载失败</div>'
                    + '<div style="color:var(--ml-text-dim);font-size:12px;margin-bottom:16px;">' + app.escapeHtml(errMsg || '') + '</div>'
                    + '<button onclick="MlifeApp.__retryGenerate(\'' + pageName + '\')" style="padding:10px 28px;border-radius:10px;border:1px solid #ff6b9d;background:var(--ml-glow-10);color:var(--ml-accent);font-size:14px;cursor:pointer;font-family:inherit;">🔄 重新加载</button>'
                    + '</div>';
            }

            /* extractReply 已移至 src/parse.js（通过外层闭包共享，与 DM_Manager 共用单一定义） */

            /**
             * 调用 tavern 内部 API 生成内容
             * 使用 SillyTavern.getContext().generateRaw 方法
             */
            app.__callApi = async function(systemPrompt) {
                // 使用 SillyTavern 的 generateRaw API（带 30s 超时）
                try {
                    var c = SillyTavern.getContext();
                    if (typeof c.generateRaw === 'function') {
                        var result = await Promise.race([
                            c.generateRaw({
                                prompt: systemPrompt,
                                systemPrompt: '',
                                responseLength: 1500,
                            }),
                            new Promise(function(_, reject) {
                                setTimeout(function() { reject(new Error('generateRaw 超时')); }, 30000);
                            })
                        ]);
                        if (result) return result;
                    }
                } catch (_) {}

                // 回退：直接 fetch
                try {
                    var chatCompletionSource = window.main_api || 'openai';
                    var model;
                    try { if (window.oai_settings && window.oai_settings.model) model = window.oai_settings.model; } catch (_) {}

                    var payload = {
                        messages: [{ role: 'system', content: systemPrompt }],
                        chat_completion_source: chatCompletionSource,
                        max_tokens: 1500,
                        temperature: 0.8,
                        stream: false,
                        use_sysprompt: false,
                    };
                    if (model) payload.model = model;

                    var csrfToken = '';
                    try { csrfToken = window.token || ''; } catch (_) {}

                    var controller = new AbortController();
                    var timeoutId = setTimeout(function() { controller.abort(); }, 30000);

                    var response = await fetch('/api/backends/chat-completions/generate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
                        cache: 'no-cache',
                        body: JSON.stringify(payload),
                        signal: controller.signal,
                    });
                    clearTimeout(timeoutId);
                    if (!response.ok) return null;
                    var json = await response.json();
                    if (json.error) return null;
                    return extractReply(json);
                } catch (_) {
                    return null;
                }
            };

            /**
             * 从 AI 回复中提取 &lt;mlife_app&gt; 包裹的 JSON
             */
            app.__extractMlifeJson = function(text) {
                if (!text) return null;
                // 三级解析
                var match = text.match(/<mlife_app>([\s\S]*?)<\/mlife_app>/i);
                if (match) {
                    try { return JSON.parse(match[1].trim()); } catch(_) {}
                }
                try { return JSON.parse(text.trim()); } catch(_) {}
                var objMatch = text.match(/\{[\s\S]*?"page"[\s\S]*?"data"[\s\S]*?\}/);
                if (objMatch) {
                    try { return JSON.parse(objMatch[0]); } catch(_) {}
                }
                return null;
            };

            /**
             * 检测 HTML 是否为空状态
             */
            app.__isPageEmpty = function(page, html) {
                if (!html) return true;
                // 如果渲染结果包含"暂无"关键词，视为空状态
                return html.indexOf('暂无') !== -1;
            };

            /**
             * 按名称调用 render 函数
             */
            function renderPageByName(page, data) {
                switch (page) {
                    case 'home': case 'index': return app.renderHome(data);
                    case 'match': return app.renderMatch(data);
                    case 'detail': return app.renderDetail(data);
                    case 'live_list': case 'livelist': return app.renderLiveList(data);
                    case 'live': return app.renderLive(data);
                    case 'goddess': return app.renderGoddess(data);
                    case 'resource': return app.renderResource(data);
                    case 'selfie': return app.renderSelfie(data);
                    case 'chat': return app.renderChat(data);
                    case 'profile': return app.renderProfile(data);
                    case 'recruit_list': case 'recruitlist': return app.renderRecruitList(data);
                    case 'recruit_detail': case 'recruitdetail': return app.renderRecruitDetail(data);
                    case 'recruit_post': case 'recruitpost': return app.renderRecruitPost(data);
                    case 'recruit_manage': case 'recruitmanage': return app.renderRecruitManage(data);
                    case 'unbox': return app.renderUnbox(data);
                    default: return null;
                }
            }

            // 暴露给 app 对象，确保闭包内部也能引用
            app.__renderPageByName = renderPageByName;

            /**
             * 构建 AI 提示词 — 首页
             */
            function buildPromptHome() {
                var ctx = '';
                var account = getCurrentAccount();
                try {
                    var all = app.getMergedVars();
                    var mu = all && all.stat_data;
                    if (mu) {
                        var sys = mu['系统'] || {};
                        var user = mu['M-life_用户'] || {};
                        ctx = '当前时间: ' + (sys.时间 || '未知') + ', 日期: ' + (sys.日期 || '未知') + ', 位置: ' + (sys.位置 || '未知') + '. '
                            + '用户: ' + (user.昵称 || '未知') + ', 等级: ' + (user.用户等级 || 'Lv1') + ', VIP: ' + (user.VIP类型 || '无') + '.';
                        if (account && account.desc) {
                            ctx += '\n\n【用户档案】\n' + account.desc;
                        }
                    }
                } catch (_) {}

                return '你是一个模拟社交软件 M-life 的内容生成器。请生成首页动态信息流。\n\n'
                    + '上下文:\n' + ctx + '\n\n'
                    + '请输出 JSON 格式，用 <mlife_app> 标签包裹。\n\n'
                    + 'JSON 结构:\n'
                    + '{\n'
                    + '  "page": "home",\n'
                    + '  "data": {\n'
                    + '    "posts": [\n'
                    + '      {\n'
                    + '        "hidden": "发帖人真实状态和动机(不显示)",\n'
                    + '        "avatar": "emoji或符号",\n'
                    + '        "nick": "用户昵称",\n'
                    + '        "level": "Lv1-Lv5",\n'
                    + '        "vip": "无/白银/黄金/黑金",\n'
                    + '        "time": "发帖时间",\n'
                    + '        "section": "福利自拍/闲聊灌水/资源分享",\n'
                    + '        "body": "帖子正文，口语化",\n'
                    + '        "images": [{ "desc": "图片描述" }],\n'
                    + '        "paywall": "无/需XX M币解锁",\n'
                    + '        "likes": 0,\n'
                    + '        "comments": 0,\n'
                    + '        "shares": 0,\n'
                    + '        "hotComments": [{ "name": "用户昵称", "text": "热评内容" }]\n'
                    + '      }\n'
                    + '    ]\n'
                    + '  },\n'
                    + '  "status": { "时间": "当前时间描述", "位置": "当前位置描述" },\n'
                    + '  "badges": { "home": 0, "match": 0, "live": 0, "dm": 0, "profile": 0 }\n'
                    + '}\n\n'
                    + '规则:\n'
                    + '- 每次生成 3-5 条帖子\n'
                    + '- 动态类型混合：纯文字帖、图片帖、擦边帖、日常帖、求助帖、吐槽帖、广告帖\n'
                    + '- 约 90% 性暗示/擦边、10% 日常\n'
                    + '- section 只能从 "福利自拍" / "闲聊灌水" / "资源分享" 中选\n'
                    + '- 帖子内容口语化，像真实社交平台\n'
                    + '- 图片 desc 需具体描述拍摄角度、穿着、光线、环境、身体部位\n'
                    + '- 付费内容只描述可见部分，paywall 标注解锁价格\n'
                    + '- 高互动帖可附带 1-2 条 hotComments，没有则留空数组\n'
                    + '- 禁止输出 <thinking> <content> 等标签\n'
                    + '- 只输出 <mlife_app> 包裹的 JSON，不要多余文字';
            }

            /**
             * 构建 AI 提示词 — 匹配
             */
            function buildPromptMatch() {
                var ctx = '';
                var account = getCurrentAccount();
                try {
                    var all = app.getMergedVars();
                    var mu = all && all.stat_data;
                    if (mu) {
                        var sys = mu['系统'] || {};
                        var user = mu['M-life_用户'] || {};
                        ctx = '当前时间: ' + (sys.时间 || '未知') + ', 日期: ' + (sys.日期 || '未知') + ', 位置: ' + (sys.位置 || '未知') + '. '
                            + '用户: ' + (user.昵称 || '未知') + ', 等级: ' + (user.用户等级 || 'Lv1') + ', VIP: ' + (user.VIP类型 || '无') + '.';
                        if (account && account.desc) {
                            ctx += '\n\n【用户档案】\n' + account.desc;
                        }
                    }
                } catch (_) {}

                return '你是一个模拟社交软件 M-life 的内容生成器。请生成约炮匹配推荐卡片。\n\n'
                    + '上下文:\n' + ctx + '\n\n'
                    + '请输出 JSON 格式，用 <mlife_app> 标签包裹。\n\n'
                    + 'JSON 结构:\n'
                    + '{\n'
                    + '  "page": "match",\n'
                    + '  "data": {\n'
                    + '    "cards": [\n'
                    + '      {\n'
                    + '        "hidden": "照骗程度、注册时长、真实目的",\n'
                    + '        "avatar": "emoji头像",\n'
                    + '        "nick": "用户昵称",\n'
                    + '        "age": 0,\n'
                    + '        "distance": "X.Xkm",\n'
                    + '        "active": "刚刚活跃/X分钟前/X小时前",\n'
                    + '        "bio": "一句话简介，口语化",\n'
                    + '        "tags": ["标签1","标签2","标签3"],\n'
                    + '        "vip": "无/白银/黄金/黑金",\n'
                    + '        "likes": 0\n'
                    + '      }\n'
                    + '    ]\n'
                    + '  }\n'
                    + '}\n\n'
                    + '标签池: 线下见面、纯聊天、线上互动、一夜情、长期关系、兴趣交友、饭搭子、游戏搭子、运动搭子、旅行、摄影、美食、音乐、电影、读书、主导型、服从型、切换型、角色扮演、SM、制服\n\n'
                    + '规则:\n'
                    + '- 每次生成 1-3 张卡片\n'
                    + '- 标签从标签池选取\n'
                    + '- 个人简介口语化，符合人物设定\n'
                    + '- 距离和活跃时间要合理\n'
                    + '- 禁止输出 <thinking> <content> 等标签\n'
                    + '- 只输出 <mlife_app> 包裹的 JSON，不要多余文字';
            }

            /**
             * 通用骨架屏 (适用于列表类页面：4张简版 shimmer 卡片)
             */
            function skeletonGeneric() {
                var html = '';
                for (var i = 0; i < 3; i++) {
                    html += '<div class="mlf-shimmer-card">'
                        + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">'
                        + '<div class="mlf-shimmer mlf-shimmer-avatar"></div>'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:50%;"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line-sm" style="width:40%;"></div>'
                        + '</div></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line"></div>'
                        + '<div class="mlf-shimmer mlf-shimmer-line" style="width:70%;"></div>'
                        + '</div>';
                }
                return html;
            }

            /**
             * 通用 AI 提示词 — 根据 pageName 动态构建
             */
            function buildPromptGeneric(pageName) {
                var ctx = '';
                var account = getCurrentAccount();
                try {
                    var all = app.getMergedVars();
                    var mu = all && all.stat_data;
                    if (mu) {
                        var sys = mu['系统'] || {};
                        var user = mu['M-life_用户'] || {};
                        ctx = '当前时间: ' + (sys.时间 || '未知') + ', 日期: ' + (sys.日期 || '未知') + ', 位置: ' + (sys.位置 || '未知') + '. '
                            + '用户: ' + (user.昵称 || '未知') + ', 等级: ' + (user.用户等级 || 'Lv1') + ', VIP: ' + (user.VIP类型 || '无') + '.';
                        if (account && account.desc) {
                            ctx += '\n\n【用户档案】\n' + account.desc;
                        }
                    }
                } catch (_) {}

                var prompts = {
                    detail: '请生成一个 M-life 用户的详细个人档案数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"detail","data":{"hidden":"真实状态","avatar":"emoji","nick":"昵称","vip":"无/白银/黄金/黑金","age":0,"distance":"X.Xkm","active":"活跃时间","level":"Lv1-Lv5","registered":"新人/老用户/中间用户","purpose":"目的","bio":"简介","tags":["标签"],"bodyType":"体型","height":"数字cm","faceStyle":"面容风格","features":"特征","dailyStyle":"日常穿着","dateStyle":"约会穿着","images":[{"desc":"描述"}],"matchTime":"匹配时间"}}\n\n'
                        + '规则: 每次输出 1 个详情对象，数据要真实详细。标签从平台标签池选取（线下见面、纯聊天、线上互动、一夜情、长期关系等）。',

                    live_list: '请生成 M-life 直播推荐列表。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"live_list","data":{"rooms":[{"hidden":"真实状态","avatar":"emoji","name":"主播名","level":"Lv1-Lv5","status":"直播中/即将开播/回放","viewers":0,"title":"标题","preview":"画面摘要","tags":["标签"],"vip":"无/白银/黄金/黑金"}]}}\n\n'
                        + '规则: 每次 3-4 个直播间，标签从 跳舞/成人/聊天/唱歌/游戏 选。',

                    live: '请生成一个 M-life 直播间的实时数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"live","data":{"hidden":"真实状态","avatar":"emoji","name":"主播名","level":"Lv1-Lv5","status":"正在直播/即将开播/回放","viewers":0,"title":"标题","scene":"主播在画面中的视觉状态——穿着、姿势、动作、表情、光线等","danmaku":[{"name":"昵称","text":"弹幕内容","vip":"无/白银/黄金/黑金"}],"gifts":[{"name":"昵称","gift":"礼物名","value":"价格"}]}}\n\n'
                        + '规则: 每个直播间需有hidden字段描述主播真实状态。3-6 条弹幕，0-3 个礼物，scene 描述要具体（衣服松紧褶皱、皮肤汗珠、坐姿改变等细节）。',

                    goddess: '请生成 M-life 女神夜话板块的女性用户匿名评价档案。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"goddess","data":{"board":{"name":"女神夜话","tab":"热帖/最新/每周精选"},"profiles":[{"avatar":"emoji","nick":"昵称","age":0,"score":5.0,"tags":["标签"],"price":"价格","intro":"简介","reviews":[{"text":"评价内容","author":"昵称"}]}]}}\n\n'
                        + '规则: 每次 1 个档案，5-20 条评价，女性视角真实体验，评价内容要具体详细（写清楚对方做了什么、技术水平、态度、身体反应等），像女生真实反馈口语化。',

                    resource: '请生成 M-life 资源分享板块的帖子列表。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"resource","data":{"posts":[{"hidden":"动机","avatar":"emoji","nick":"昵称","level":"Lv1-Lv5","vip":"无/白银/黄金/黑金","time":"时间","title":"标题","body":"正文","size":"文件大小","format":"格式","price":"价格","downloads":0,"comments":0,"likes":0}]}}\n\n'
                        + '规则: 每次 2-4 条资源帖，size/format/price 字段可选。资源类型包括：视频合集、图包、教程、工具推荐、自拍打包。标题要吸引眼球。',

                    selfie: '请生成 M-life 日常自拍板块的帖子列表。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"selfie","data":{"posts":[{"hidden":"动机","avatar":"emoji","nick":"昵称","level":"Lv1-Lv5","vip":"无/白银/黄金/黑金","time":"时间","body":"配文","images":[{"desc":"图片描述"}],"paywall":"无/需XX M币解锁","likes":0,"comments":0,"shares":0}]}}\n\n'
                        + '规则: 每次 2-4 条，配文口语化暧昧简短。图片 desc 需具体描写拍摄角度/穿着/露出程度/光线/环境/姿势。支持多图和付费帖，付费帖只描述免费预览图部分。',

                    chat: '请生成 M-life 闲聊灌水板块的帖子列表。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"chat","data":{"posts":[{"hidden":"动机","avatar":"emoji","nick":"昵称","level":"Lv1-Lv5","vip":"无/白银/黄金/黑金","time":"时间","title":"标题","body":"正文","replies":0,"views":0,"likes":0,"hotComments":[{"name":"昵称","text":"热评"}],"poll":{"options":["选项"],"totalVotes":0}}]}}\n\n'
                        + '规则: 每次 3-5 条帖子，内容杂：吐槽、求助、征友、无聊发疯、深夜emo、晒日常。支持热评（1-2条）和投票帖（poll字段）。正文口语化随意。',

                    profile: '请生成 M-life 用户的个人中心数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"profile","data":{"hidden":"真实状态","avatar":"emoji","nick":"昵称","level":"Lv1-Lv5","vip":"无/白银/黄金/黑金","age":0,"bio":"简介","stats":{"following":0,"followers":0,"likes":0,"posts":0},"sections":[{"id":"selfie","name":"日常自拍","icon":"📸","locked":false},{"id":"chat","name":"闲聊灌水","icon":"💬","locked":false},{"id":"resource","name":"资源分享","icon":"📦","locked":false},{"id":"goddess","name":"女神夜话","icon":"👑","locked":false},{"id":"recruit_list","name":"黑金之选","icon":"💎","locked":false}],"settings":{"showCheckin":true,"checkedIn":false,"streakDays":0}}}\n\n'
                        + '规则: 黑金VIP用户 黑金之选 locked:false。',

                    recruit_list: '请生成 M-life 黑金之选招募广场的招募帖列表。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"recruit_list","data":{"recruits":[{"hidden":"发布人真实状态、背景、是否靠谱等（不显示）","code":"R001","title":"标题","poster":"发布人","avatar":"高级感emoji(💎👑🌟等)","credit":"信用分","typeIcon":"类型图标(单人约会同城/多人聚会/角色扮演/道具play/露出任务/调教/摄影/特殊类型)","budget":"XXXXM币/次","tags":["标签"],"status":"招募中/已锁定/已完成/已取消","applicants":0,"time":"时间"}]}}\n\n'
                        + '规则: 每次 3-5 条，高端精致风格。typeIcon附加筛选分类信息用/分隔。tags含：长期、短期、固定、互惠、SM、角色扮演、旅行、出差、商务、陪同等。',

                    recruit_detail: '请生成一个 M-life 黑金之选招募帖的详情数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"recruit_detail","data":{"hidden":"发布人真实状态、背景、是否有坑（不显示）","code":"R001","title":"标题","poster":"发布人","avatar":"emoji","vip":"无/白银/黄金/黑金","credit":"信用分","rating":"评分","history":"历史完成单","recruitType":"招募类型(单人约会/多人聚会/角色扮演等)","typeIcon":"类型图标+分类","count":"人数","time":"执行时间","city":"城市","duration":"时长","publishTime":"发布时间","expire":"有效期","status":"招募中/已锁定/已完成/已取消/争议中","ageReq":"年龄要求","bodyPref":"身材偏好","specialReq":"特殊要求","playTags":["Play标签"],"singleReward":"单人报酬","totalReward":"总报酬","serviceFee":"服务费","deposit":"押金状态","btnText":"按钮文字(报名应征/已报名/查看报名列表/无权限)","btnHint":"按钮说明","applicants":[{"code":"编号","age":0,"body":"身材","rating":"评分","orders":"完成单","note":"应征说明","ops":"操作(私信/确认/拒绝)"}],"views":0}}\n\n'
                        + '规则: recruitType从分类选(单人约会/多人聚会/角色扮演等)。body覆盖年龄体型时间地点频率要求。applicants.status:待审核/已确认/未选中/已取消。',

                    recruit_post: '请生成 M-life 黑金之选发布招募的表单数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"recruit_post","data":{"form":{"titleHint":"标题占位如寻找周末约会女伴","recruitType":"招募类型(单人约会/多人聚会/角色扮演/道具play/露出任务/调教/摄影/特殊类型)","budgetHint":"预算占位如8000M币/次","tagsHint":"标签占位逗号分隔","bodyHint":"详细要求占位(包括对年龄/体型/性格/经验/时间/地点/频率的要求)","balance":"当前M币余额"}}}\n\n'
                        + '规则: 占位文字要具体吸引人，符合黑金之选高端定位。招募类型从预设分类选。',

                    recruit_manage: '请生成 M-life 黑金之选我的管理页面数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"recruit_manage","data":{"tab":"我发布的/我报名的","filter":"全部/招募中/已锁定/已完成/已取消","myRecruits":[{"hidden":"真实进展（不显示）","id":"订单编号","typeIcon":"类型图标","title":"标题","recruitType":"招募类型","status":"招募中/已锁定/已完成/已取消/争议中","time":"时间","reward":"报酬","progress":"进展描述","ops":"操作(查看报名/确认人选/取消招募/联系对方)"}],"myApplications":[{"hidden":"应征动机（不显示）","id":"订单编号","typeIcon":"类型图标","title":"标题","poster":"发布人","recruitType":"招募类型","status":"已报名/已确认/已选中/未选中/已完成/已取消","time":"时间","reward":"报酬","progress":"进展描述","ops":"操作(查看详情/联系发布者/确认接单/取消报名)"}]}}\n\n'
                        + '规则: myRecruits 和 myApplications 根据 tab 填充。每个订单status和ops要对应。progress写状态补充说明。',

                    unbox: '请生成 M-life 开盒系统的角色详细数据。\n\n'
                        + 'JSON 结构:\n'
                        + '{"page":"unbox","data":{"contact":"联系人","avatar":"emoji","level":"LvX","vip":"无/白银/黄金/黑金","hasCharacter":true,"isUnboxed":true,"balance":"M币余额","character":{"id":"char_xxx","nick":"昵称","age":0,"job":"职业","level":"LvX","vip":"无/白银/黄金/黑金","purpose":"目的","registered":"新人/老用户/中间用户","bodyType":"体型","height":"身高","faceStyle":"面容","features":"特征","dailyStyle":"日常穿着","dateStyle":"约会穿着","lingerie":"内衣风格","homeStyle":"居家穿着","personality_drive":"性格驱动","personality_main":["性格标签"],"personality_contrast":"反差面","chat_style":"聊天风格","chat_pace":"节奏","chat_initiative":"主动性","chat_drive":"聊天驱动","meet_first":"初次印象","meet_real":"真实状态","meet_pace":"见面节奏","bust":"胸围","waist":"腰围","hip":"臀围","pubic":"耻骨","inner":"私处","sensitive":["敏感点"],"nsfw_drive":"性驱动","nsfw_style":"风格","nsfw_voice":"声音","nsfw_dirty_talk":"做爱话语","nsfw_likes":["喜好"],"nsfw_limits":["底线"],"nsfw_orgasm":"高潮","created_at":"创建时间"}}}\n\n'
                        + '规则: 所有 50+ 字段需填充完整，角色设定要独特。',
                };

                var prompt = prompts[pageName] || '请生成 M-life 的' + pageName + '页面数据。JSON 结构需包含 page 和 data 字段。\n\n';

                return '你是一个模拟社交软件 M-life 的内容生成器。请生成' + pageName + '页面数据。\n\n'
                    + '上下文:\n' + ctx + '\n\n'
                    + '请输出 JSON 格式，用 <mlife_app> 标签包裹。\n\n'
                    + prompt
                    + '\n规则:\n'
                    + '- 只输出 <mlife_app> 包裹的 JSON，不要多余文字\n'
                    + '- 禁止输出 <thinking> <content> 等标签\n'
                    + '- 数据要口语化、真实可信';
            }

            /**
             * 页面生成器配置
             */
            app.__pageGenerators = {
                home: { skeleton: skeletonHome, buildPrompt: buildPromptHome },
                match: { skeleton: skeletonMatch, buildPrompt: buildPromptMatch },
                detail: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                live_list: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                live: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                goddess: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                resource: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                selfie: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                chat: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                // profile: 从 MVU 变量读取，不 AI 生成
                recruit_list: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                recruit_detail: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                recruit_post: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                recruit_manage: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
                unbox: { skeleton: skeletonGeneric, buildPrompt: buildPromptGeneric },
            };

            /**
             * 生成锁，防止并发
             */
            app.__isGenerating = {};

            /**
             * 重试入口（供错误页面按钮调用）
             */
            app.__retryGenerate = function(pageName) {
                app.__isGenerating[pageName] = false;
                app.__generatePageContent(pageName);
            };

            /**
             * 主生成流程：骨架屏 → 调 API → 解析 → render → 缓存 → 显示
             */
            app.__generatePageContent = async function(pageName) {
                var gen = app.__pageGenerators[pageName];
                if (!gen) return false;
                if (app.__isGenerating[pageName]) return false;
                app.__isGenerating[pageName] = true;

                var contentEl = document.getElementById('mlife-content');
                if (!contentEl) { app.__isGenerating[pageName] = false; return false; }

                try {
                    // 1. 显示骨架屏
                    contentEl.innerHTML = gen.skeleton();

                    // 2. 构建提示词并调 API
                    var prompt = gen.buildPrompt(pageName);
                    var reply = await app.__callApi(prompt);
                    if (!reply) throw new Error('API 返回为空');

                    // 3. 提取 JSON
                    var json = app.__extractMlifeJson(reply);
                    if (!json || !json.data) throw new Error('JSON 解析失败');

                    // 4. 渲染 (使用 app 上的引用，避免闭包作用域问题)
                    var html = app.__renderPageByName(pageName, json.data);
                    if (!html) throw new Error('渲染失败');

                    // 5. 检查是否已导航离开
                    if (app.currentPage !== pageName) { app.__isGenerating[pageName] = false; return false; }

                    // 6. 缓存并显示
                    app.updateCache(pageName, html);
                    contentEl.innerHTML = html;
                    app.__isGenerating[pageName] = false;
                    return true;
                } catch (err) {
                    console.warn('[MlifeApp] 生成失败', pageName, err);
                    if (app.currentPage === pageName && contentEl) {
                        contentEl.innerHTML = skeletonError(pageName, err.message);
                    }
                    app.__isGenerating[pageName] = false;
                    return false;
                }
            };

            /**
             * renderDMList — 渲染私信联系人列表





































            app.navigate = function(page, data) {
                app.renderPage({ page: page, data: data || null });
                // 更新导航高亮
                updateNavActive(page);
            };

            app.switchTab = function(tab) {
                var cached = app.getCached(tab);
                if (cached) {
                    var contentEl = document.getElementById('mlife-content');
                    if (contentEl) contentEl.innerHTML = cached;
                    updateNavActive(tab);
                    app.currentPage = tab;
                    return;
                }
                // 如果该页支持 AI 生成，走生成流程
                if (app.__pageGenerators[tab]) {
                    app.currentPage = tab;
                    updateNavActive(tab);
                    // 优先显示骨架屏（即发即弃旧页面内容）
                    var gen = app.__pageGenerators[tab];
                    if (gen && gen.skeleton) {
                        var contentEl = document.getElementById('mlife-content');
                        if (contentEl) contentEl.innerHTML = gen.skeleton();
                    }
                    app.__generatePageContent(tab);
                    return;
                }
                // 回退：原有 navigate 逻辑
                app.navigate(tab);
            };

            /**
             * renderSettings — 设置页（无需 AI 生成，从变量直接渲染）



            // ---- 底部导航高亮 ----
            function updateNavActive(page) {
                // 黑金模式使用独立导航高亮
                if (app.__heiJinMode) {
                    updateHeiJinNav(page);
                    return;
                }
                var items = document.querySelectorAll('.nav-item');
                var pageMap = {
                    'home': 'nav-home',
                    'index': 'nav-home',
                    'match': 'nav-match',
                    'live_list': 'nav-live',
                    'livelist': 'nav-live',
                    'live': 'nav-live',
                    'dm': 'nav-dm',
                    'DM': 'nav-dm',
                    'dm_list': 'nav-dm',
                    'dmList': 'nav-dm',
                    'selfie': 'nav-me',
                    'goddess': 'nav-me',
                    'resource': 'nav-me',
                    'profile': 'nav-me',
                    'chat': 'nav-home',
                    'detail': 'nav-match',
                    'recruit_list': 'nav-me',
                    'recruitlist': 'nav-me',
                    'recruit_detail': 'nav-me',
                    'recruitdetail': 'nav-me',
                    'recruit_post': 'nav-me',
                    'recruitpost': 'nav-me',
                    'recruit_manage': 'nav-me',
                    'recruitmanage': 'nav-me',
                    'unbox': 'nav-dm',
                    'settings': 'nav-me'
                };
                var activeId = pageMap[page] || 'nav-home';
                items.forEach(function(item) {
                    if (item.id === activeId) {
                        item.classList.add('active');
                    } else {
                        item.classList.remove('active');
                    }
                });
            }

            /**
             * 黑金模式底部导航高亮
             */
            function updateHeiJinNav(page) {
                var items = document.querySelectorAll('.nav-item');
                var heiJinMap = {
                    'recruit_list': 'nav-heijin-square',
                    'recruitlist': 'nav-heijin-square',
                    'recruit_post': 'nav-heijin-post',
                    'recruitpost': 'nav-heijin-post',
                    'recruit_manage': 'nav-heijin-manage',
                    'recruitmanage': 'nav-heijin-manage',
                };
                // 退出（回到主应用）由 __exitHeiJinMode 处理，不在这里高亮
                // 未知页面全部视为"广场"高亮
                var activeId = heiJinMap[page] || 'nav-heijin-square';
                items.forEach(function(item) {
                    if (item.id === activeId) {
                        item.classList.add('active');
                    } else {
                        item.classList.remove('active');
                    }
                });
            }

            /**
             * 进入黑金之选独立模式
             * 替换底部导航栏为黑金之选专属 Tab
             */
            app.__enterHeiJinMode = function() {
                if (app.__heiJinMode) return;
                app.__heiJinMode = true;
                var appEl = document.getElementById('mlife-app');
                if (!appEl) return;
                var nav = appEl.querySelector('.nav-bar');
                if (!nav) return;
                // 保存进入前的页面和导航内容，用于退出后恢复
                app.__heiJinPrevPage = app.currentPage || 'home';
                app.__heiJinPrevNavHTML = nav.innerHTML;
                nav.innerHTML = ''
                    + '<button class="nav-item active" id="nav-heijin-square" style="color:#c9a96e!important;">'
                        + '<span class="nav-icon">💎</span>'
                        + '<span class="nav-label">广场</span>'
                    + '</button>'
                    + '<button class="nav-item" id="nav-heijin-post">'
                        + '<span class="nav-icon">✏️</span>'
                        + '<span class="nav-label">发布</span>'
                    + '</button>'
                    + '<button class="nav-item" id="nav-heijin-manage">'
                        + '<span class="nav-icon">📋</span>'
                        + '<span class="nav-label">管理</span>'
                    + '</button>'
                    + '<button class="nav-item" id="nav-heijin-exit">'
                        + '<span class="nav-icon">🔙</span>'
                        + '<span class="nav-label">返回</span>'
                    + '</button>';
                // 绑定黑金模式导航点击
                bindHeiJinNav();
                // 注入黑金模式专属样式
                injectHeiJinStyle();
            };

            /**
             * 退出黑金之选独立模式
             * 恢复原底部导航栏
             */
            app.__exitHeiJinMode = function() {
                if (!app.__heiJinMode) return;
                app.__heiJinMode = false;
                var appEl = document.getElementById('mlife-app');
                if (!appEl) return;
                var nav = appEl.querySelector('.nav-bar');
                if (!nav) return;
                // 恢复原导航
                if (app.__heiJinPrevNavHTML) {
                    nav.innerHTML = app.__heiJinPrevNavHTML;
                }
                // 重新绑定原导航点击
                bindNav();
                // 移除黑金模式样式
                removeHeiJinStyle();
                // 导航到进入前的页面
                var prevPage = app.__heiJinPrevPage || 'home';
                app.__heiJinPrevPage = null;
                try {
                    app.switchTab(prevPage);
                } catch(e) {
                    app.navigate(prevPage);
                }
            };

            /**
             * 黑金模式导航点击绑定
             */
            function bindHeiJinNav() {
                var navMap = {
                    'nav-heijin-square': 'recruit_list',
                    'nav-heijin-post': 'recruit_post',
                    'nav-heijin-manage': 'recruit_manage',
                };
                // 返回按钮特殊处理
                var exitEl = document.getElementById('nav-heijin-exit');
                if (exitEl) {
                    exitEl.addEventListener('click', function() {
                        app.__exitHeiJinMode();
                    });
                }
                // 其他三个 Tab
                Object.keys(navMap).forEach(function(id) {
                    var el = document.getElementById(id);
                    if (!el) return;
                    el.addEventListener('click', function() {
                        var page = navMap[id];
                        app.navigate(page);
                    });
                });
            }

            /**
             * 注入黑金模式样式（覆盖默认主题为暗黑金配色）
             */
            var __heiJinStyleId = 'mlife-heijin-style';
            function injectHeiJinStyle() {
                if (document.getElementById(__heiJinStyleId)) return;
                var style = document.createElement('style');
                style.id = __heiJinStyleId;
                style.textContent = ''
                    + '#mlife-app.mlife-heijin-mode .nav-bar{'
                    + 'background:linear-gradient(135deg,#0a0a0f,#1a1a1f)!important;'
                    + 'border-top:1px solid rgba(201,169,110,0.15)!important;'
                    + '}'
                    + '#mlife-app.mlife-heijin-mode .nav-item{'
                    + 'color:rgba(255,255,255,0.4)!important;'
                    + '}'
                    + '#mlife-app.mlife-heijin-mode .nav-item.active{'
                    + 'color:#c9a96e!important;'
                    + 'text-shadow:0 0 8px rgba(201,169,110,0.3)!important;'
                    + '}'
                    + '#mlife-app.mlife-heijin-mode .nav-item:hover{'
                    + 'color:rgba(201,169,110,0.7)!important;'
                    + 'background:rgba(201,169,110,0.06)!important;'
                    + '}';
                document.head.appendChild(style);
                // 添加黑金模式 class
                var appEl = document.getElementById('mlife-app');
                if (appEl) appEl.classList.add('mlife-heijin-mode');
            }

            function removeHeiJinStyle() {
                var style = document.getElementById(__heiJinStyleId);
                if (style) style.remove();
                var appEl = document.getElementById('mlife-app');
                if (appEl) appEl.classList.remove('mlife-heijin-mode');
            }

            /**
             * 判断当前用户是否为黑金 VIP
             */
            app.__isHeiJinVip = function() {
                try {
                    var vars = app.getMergedVars().stat_data || {};
                    var mu = vars['M-life_用户'] || {};
                    return mu.VIP类型 === '黑金';
                } catch(e) {}
                return false;
            };

            /**
             * 显示黑金 VIP 提示（暴露到全局，供 inline onclick 调用）
             */
            window.showHeiJinDenied = function() {
                var toast = document.createElement('div');
                toast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:999999;background:var(--ml-bg-section);border:1px solid #ff6b9d;border-radius:12px;padding:20px 28px;text-align:center;max-width:280px;box-shadow:0 8px 40px rgba(0,0,0,0.6);';
                toast.innerHTML = '<div style="font-size:32px;margin-bottom:10px;">🔒</div>'
                    + '<div style="font-size:16px;color:var(--ml-text);font-weight:bold;margin-bottom:6px;">黑金VIP 专属</div>'
                    + '<div style="font-size:13px;color:var(--ml-text-dim);line-height:1.5;">开通黑金VIP后<br>即可访问黑金之选</div>'
                    + '<button style="margin-top:16px;padding:8px 24px;border:none;border-radius:8px;background:var(--ml-gold);color:#1a1a1a;font-size:14px;font-weight:bold;cursor:pointer;font-family:inherit;">知道了</button>';
                document.body.appendChild(toast);
                toast.querySelector('button').addEventListener('click', function() { toast.remove(); });
                setTimeout(function() { if (toast.parentNode) toast.remove(); }, 4000);
            };

            // 修改 navigate 以支持黑金模式入口
            // 保存原始 navigate 引用
            var __origNavigate = app.navigate;
            app.navigate = function(page, data) {
                // 黑金页面：检查 VIP
                if (page === 'recruit_list' || page === 'recruitlist' || page === 'recruit_post' || page === 'recruitpost' || page === 'recruit_manage' || page === 'recruitmanage') {
                    if (!app.__heiJinMode && !app.__isHeiJinVip()) {
                        showHeiJinDenied();
                        return;
                    }
                    if (!app.__heiJinMode) {
                        app.__enterHeiJinMode();
                    }
                }
                // 调用原 navigate
                __origNavigate(page, data);
            };

            // 修改 switchTab 以支持黑金模式
            var __origSwitchTab = app.switchTab;
            app.switchTab = function(tab) {
                // 黑金页面：检查 VIP
                if (tab === 'recruit_list' || tab === 'recruitlist' || tab === 'recruit_post' || tab === 'recruitpost' || tab === 'recruit_manage' || tab === 'recruitmanage') {
                    if (!app.__heiJinMode && !app.__isHeiJinVip()) {
                        showHeiJinDenied();
                        return;
                    }
                    if (!app.__heiJinMode) {
                        app.__enterHeiJinMode();
                    }
                }
                __origSwitchTab(tab);
            };

            // ---- 底部导航点击绑定 ----
            function bindNav() {
                var navMap = {
                    'nav-home': 'home',
                    'nav-match': 'match',
                    'nav-live': 'live_list',
                    'nav-dm': 'dm',
                    'nav-me': 'profile'
                };
                Object.keys(navMap).forEach(function(id) {
                    var el = document.getElementById(id);
                    if (!el) return;
                    el.addEventListener('click', function() {
                        var page = navMap[id];
                        // 检查缓存
                        var cached = app.getCached(page);
                        if (cached) {
                            document.getElementById('mlife-content').innerHTML = cached;
                            updateNavActive(page);
                            app.currentPage = page;
                        } else if (app.__pageGenerators[page]) {
                            // 支持 AI 生成的页面走生成流程
                            app.currentPage = page;
                            updateNavActive(page);
                            app.__generatePageContent(page);
                        } else {
                            app.navigate(page);
                        }
                    });
                });
            }

            // ---- 启动 ----
            app.init = function(rawData) {
                if (rawData) {
                    if (typeof rawData === 'string') {
                        try { app.config = JSON.parse(rawData); }
                        catch (e) { app.config = rawData; }
                    } else {
                        app.config = rawData;
                    }
                } else {
                    app.config = parseJsonData();
                }

                // 确保 mlife-content 容器存在（浮层由外层自动创建）
                if (!document.getElementById('mlife-content') && document.getElementById('mlife-app')) {
                    var contentDiv = document.createElement('div');
                    contentDiv.id = 'mlife-content';
                    contentDiv.style.cssText = 'max-width:500px;margin:0 auto;padding:0 10px 70px;box-sizing:border-box;flex:1;min-height:0;height:100%;';
                    document.getElementById('mlife-app').appendChild(contentDiv);
                }

                // 刷新状态栏
                try { populateStatusBar(); } catch(e) { console.warn('[MlifeApp] populateStatusBar error:', e); }

                // 绑定导航
                try { bindNav(); } catch(e) { console.warn('[MlifeApp] bindNav error:', e); }

                // 注入 shimmer 动画样式
                try { injectShimmerStyle(); } catch(e) {}

                // 清除 AI 可生成页面的空状态缓存
                Object.keys(app.__pageGenerators).forEach(function(page) {
                    var cached = app.getCached(page);
                    if (cached && app.__isPageEmpty(page, cached)) {
                        app.tabCache[page] = null;
                    }
                });

                // 更新 DM Tab 未读标记
                try { app.updateDmTabBadge(); } catch(e) {}

                // 全局事件委托：点击 [data-person] 弹出用户菜单
                var mlifeContent = document.getElementById('mlife-content');
                if (mlifeContent) {
                    mlifeContent.addEventListener('click', function(e) {
                        var target = e.target.closest('[data-person]');
                        if (target) {
                            try {
                                var raw = target.getAttribute('data-person');
                                if (raw && raw.indexOf('%') !== -1) {
                                    raw = decodeURIComponent(raw);
                                }
                                var personData = JSON.parse(raw);
                                if (personData && personData.contact) {
                                    e.stopPropagation();
                                    app.showPersonMenu(personData);
                                }
                            } catch(_) {}
                        }
                    });
                }

                // 渲染首屏（独立模式由boot处理，避免二次渲染）
                // 只处理config.page存在的情况（酒馆模式）
                if (app.config && app.config.page) {
                    app.renderPage(app.config);
                }

                // 监听 MVU 变量更新
                if (typeof eventOn === 'function' && typeof Mvu !== 'undefined') {
                    eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, function() {
                        try { populateStatusBar(); } catch(e) {}
                    });
                }
            };

            return app;
        })();

        // ---- 酒馆模式：自动创建可拖动的悬浮窗 ----
        (function() {
            if (document.getElementById('mlife-app')) return;

            // 初始位置（屏幕右侧，离 💎 近一点）
            var winW = Math.min(380, window.innerWidth - 20);
            var startX = Math.max(10, window.innerWidth - winW - 70);
            var startY = 80;

            var ov = document.createElement('div');
            ov.id = 'mlife-app';
            ov.style.cssText = 'position:fixed;left:' + startX + 'px;top:' + startY + 'px;width:' + winW + 'px;height:calc(100vh - 100px);max-height:700px;z-index:99999;display:none;border-radius:16px;border:1px solid rgba(255,107,157,0.25);overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,0.6);';

            // 标题栏（可拖动）
            ov.innerHTML = '<div id="mlife-app-header" style="background:var(--ml-bg-section);padding:8px 12px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #2a2a3e;cursor:grab;user-select:none;">'
                + '<span style="color:var(--ml-accent-light);font-size:14px;font-weight:bold;">💎 魅途</span>'
                + '<button id="mlife-app-close" style="background:none;border:none;color:var(--ml-text-dim);font-size:18px;cursor:pointer;padding:2px 6px;font-family:inherit;line-height:1;">✕</button>'
                + '</div>'
                + '<div id="mlife-app-body" style="background:rgba(5,10,14,0.97);flex:1;min-height:0;overflow-y:auto;">'
                + '<div id="mlife-content" style="padding:8px 10px 20px;box-sizing:border-box;"></div>'
                + '</div>';

            document.body.appendChild(ov);

            // 关闭按钮
            document.getElementById('mlife-app-close').addEventListener('click', function() {
                ov.style.display = 'none';
            });

            // 拖拽逻辑
            (function() {
                var header = document.getElementById('mlife-app-header');
                var drag = false, sx, sy, ox, oy;

                header.addEventListener('mousedown', function(e) {
                    if (e.button !== 0) return;
                    drag = true;
                    var rect = ov.getBoundingClientRect();
                    ox = e.clientX - rect.left;
                    oy = e.clientY - rect.top;
                    header.style.cursor = 'grabbing';
                    e.preventDefault();
                });

                document.addEventListener('mousemove', function(e) {
                    if (!drag) return;
                    ov.style.left = Math.max(0, e.clientX - ox) + 'px';
                    ov.style.top = Math.max(0, e.clientY - oy) + 'px';
                });

                document.addEventListener('mouseup', function() {
                    if (drag) {
                        drag = false;
                        header.style.cursor = 'grab';
                    }
                });
            })();
        })();

        // ============================================================
        // 启动入口
        // ============================================================
        (function boot() {
            var isStandalone = (
                typeof window.$ !== 'function' &&
                typeof window.waitGlobalInitialized !== 'function'
            );

            if (isStandalone) {
                window.__isStandalone = true;
                // 独立模式：DOM 就绪后直接启动
                console.log('[MlifeApp] 独立模式启动');
                function start() {
                    console.log('[MlifeApp] start() invoked');
                    // 先调用 init（初始化内部状态、绑定导航等）
                    window.MlifeApp.init();

                    // 再填充演示数据覆盖首页
                    var demoData = {
                            "page": "home",
                            "posts": [
                                {
                                    "avatar": "\u{1F338}", "nick": "夜蝶", "level": "Lv8", "vip": "黄金",
                                    "time": "2分钟前", "section": "同城",
                                    "body": "今晚好无聊，有人来陪陪我吗？刚洗完澡，浑身软软的\u{1F60F}",
                                    "images": [{"desc": "浴室自拍，雾气朦胧，隐约可见锁骨和湿漉漉的长发"}],
                                    "paywall": "无", "likes": 42, "comments": 12, "shares": 3,
                                    "hotComments": [
                                        {"name": "暗夜骑士", "text": "我在！私信你了小姐姐"},
                                        {"name": "清风", "text": "坐标哪里？马上到"}
                                    ]
                                },
                                {
                                    "avatar": "\u{1F339}", "nick": "绯色梦境", "level": "Lv12", "vip": "黑金",
                                    "time": "15分钟前", "section": "推荐",
                                    "body": "周末有空，约了个小哥哥出来玩～猜猜我们去哪了？\u{1F609}\n附一张今天的穿搭，喜欢吗？",
                                    "images": [
                                        {"desc": "全身镜前自拍，黑色蕾丝短裙配红底高跟鞋"},
                                        {"desc": "咖啡馆角落，手里拿着拿铁，侧脸微笑"}
                                    ],
                                    "paywall": "完整版需关注", "likes": 128, "comments": 34, "shares": 17,
                                    "hotComments": [
                                        {"name": "绅士", "text": "这腿绝了\u{1F60D}"},
                                        {"name": "路人甲", "text": "求同款链接！"}
                                    ]
                                }
                            ]
                        };
                        var contentEl = document.getElementById('mlife-content');
                        if (contentEl) {
                            contentEl.innerHTML = window.MlifeApp.renderHome(demoData);
                        }

                        // 在首页渲染完成后调用 init（不覆盖首页内容）
                        window.MlifeApp.init();

                        // 私信 + 开盒演示数据：3秒后自动演示
                        // 以便用户先看首页内容，不被自动跳转干扰
                        setTimeout(function() {
                            // 渲染私信页面带开盒按钮
                            window.MlifeApp.navigate('dm', {
                                "contact": "蜜桃气泡水",
                                "avatar": "🍑",
                                "level": "Lv3",
                                "vip": "黄金",
                                "age": 24,
                                "hasCharacter": true,
                                "messages": [
                                    {"type": "incoming", "text": "你好呀~", "time": "10分钟前"},
                                    {"type": "outgoing", "text": "嗨，看了你的资料挺感兴趣的", "status": "已读", "time": "8分钟前"},
                                    {"type": "incoming", "text": "嘻嘻，谢谢~ 我也觉得你不错😊", "time": "5分钟前"}
                                ]
                            });
                        }, 300);

                        // 开盒页面演示（已开盒状态）：3秒后展示
                        setTimeout(function() {
                            window.MlifeApp.navigate('unbox', {
                                "contact": "蜜桃气泡水",
                                "avatar": "🍑",
                                "level": "Lv3",
                                "vip": "黄金",
                                "isUnboxed": true,
                                "balance": "400",
                                "character": {
                                    "id": "char_001",
                                    "nick": "蜜桃气泡水",
                                    "age": 24,
                                    "job": "舞蹈老师",
                                    "level": "Lv3",
                                    "vip": "黄金",
                                    "purpose": "找长期关系",
                                    "registered": "老用户（三个月以上）",
                                    "bodyType": "匀称型",
                                    "height": "165cm",
                                    "faceStyle": "甜美型",
                                    "features": "黑长直，皮肤白嫩，锁骨明显",
                                    "dailyStyle": "韩系风：针织开衫、百褶裙",
                                    "dateStyle": "性感型：低领、短裙",
                                    "lingerie": "性感型：蕾丝成套",
                                    "homeStyle": "睡衣党",
                                    "personality_drive": "害怕孤独",
                                    "personality_main": ["温柔体贴", "开朗健谈"],
                                    "personality_contrast": "外热内冷",
                                    "chat_style": "句尾加波浪线~，口语化",
                                    "chat_pace": "看心情型",
                                    "chat_initiative": "试探型",
                                    "chat_drive": "闷骚型慢热",
                                    "meet_first": "自然型",
                                    "meet_real": "一致型",
                                    "meet_pace": "看感觉型",
                                    "bust": "C杯",
                                    "waist": "盈盈一握",
                                    "hip": "蜜桃臀",
                                    "pubic": "粉嫩，阴毛修剪过",
                                    "inner": "紧致，深处敏感",
                                    "sensitive": ["脖颈", "乳头"],
                                    "nsfw_drive": "情感需求",
                                    "nsfw_style": "羞涩但投入型",
                                    "nsfw_voice": "自然型",
                                    "nsfw_dirty_talk": "不说型",
                                    "nsfw_likes": ["后入", "接吻"],
                                    "nsfw_limits": ["肛交"],
                                    "nsfw_orgasm": "痉挛型",
                                    "created_at": "2025年9月15日"
                                }
                            });
                        }, 3500);

                        // 4秒后展示"我的"页面（黑金VIP + 招募帖内容）
                        setTimeout(function() {
                            window.MlifeApp.navigate('profile', {
                                "nick": "孤独的风",
                                "level": "Lv16",
                                "vip": "黑金",
                                "avatar": "🦅",
                                "bio": "黑金VIP | 诚征长期关系，不诚勿扰",
                                "stats": {"following": 238, "followers": 1842, "likes": 9527, "posts": 68},
                                "sections": [
                                    {id:'selfie', name:'日常自拍', icon:'📸', locked:false},
                                    {id:'chat', name:'闲聊灌水', icon:'💬', locked:false},
                                    {id:'resource', name:'资源分享', icon:'📦', locked:false},
                                    {id:'goddess', name:'女神夜话', icon:'👑', locked:false},
                                    {id:'recruit_list', name:'黑金之选', icon:'💎', locked:false}
                                ]
                            });
                            // 预填充黑金之选招募帖数据
                            window.MlifeApp.navigate('recruit_list', {
                                "recruits": [
                                    {
                                        "code": "R001",
                                        "avatar": "💃",
                                        "title": "周末高端宴会女伴",
                                        "poster": "寂寞绅士",
                                        "status": "招募中",
                                        "budget": "💰 3000 M币",
                                        "applicants": 5,
                                        "tags": ["宴会", "高端", "周末"],
                                        "time": "2小时前发布"
                                    },
                                    {
                                        "code": "R002",
                                        "avatar": "🌙",
                                        "title": "深夜私聊·长期陪伴",
                                        "poster": "夜行者",
                                        "status": "招募中",
                                        "budget": "💰 1500 M币/周",
                                        "applicants": 12,
                                        "tags": ["陪伴", "深夜", "长期"],
                                        "time": "5小时前发布"
                                    },
                                    {
                                        "code": "R003",
                                        "avatar": "🏖️",
                                        "title": "三亚旅行伴侣 3天2夜",
                                        "poster": "阳光男",
                                        "status": "已锁定",
                                        "budget": "💰 8000 M币",
                                        "applicants": 3,
                                        "tags": ["旅行", "三亚", "短期"],
                                        "time": "1天前发布"
                                    }
                                ]
                            });
                        }, 4500);

                        // 6秒后演示"发布招募"页面
                        setTimeout(function() {
                            window.MlifeApp.navigate('recruit_post', {
                                "form": {
                                    "titleHint": "例：寻找长期固定伴侣",
                                    "budgetHint": "例：5000M币/次",
                                    "tagsHint": "例：长期,固定,互惠",
                                    "bodyHint": "描述你的要求..."
                                }
                            });
                        }, 6500);

                        // 7.5秒后演示"我的管理"页面
                        setTimeout(function() {
                            window.MlifeApp.navigate('recruit_manage', {
                                "tab": "我发布的",
                                "myRecruits": [
                                    {"title": "周末高端宴会女伴", "applicants": 5, "status": "招募中"},
                                    {"title": "一对一摄影创作", "applicants": 3, "status": "已确认"},
                                    {"title": "深夜陪聊·长期", "applicants": 8, "status": "已完成"}
                                ],
                                "myApplications": [
                                    {"title": "三亚旅行伴侣 3天2夜", "status": "已报名"},
                                    {"title": "商务晚宴女伴", "status": "未选中"}
                                ]
                            });
                        }, 8500);
                }
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', start);
                } else {
                    start();
                }
            }
        })();

// [2] DM Manager
/**
 * M-life DM 管理器 v1
 *
 * 独立 API 模式的私信系统，不走 tavern 主线楼层。
 *
 * 核心功能:
 *   1. dmGenerate() — 调 tavern 内部 API 获取 AI 回复
 *   2. 会话管理 — 多联系人独立上下文，localStorage 持久化
 *   3. 联系人索引 — 未读标记、时间排序、最近消息
 *   4. 三层堆积控制 — 本地存储 retention / API 滑动窗口 / 主线桥接限频
 *   5. Persona 管理 — 从开盒/匹配数据生成角色设定
 *
 * 集成:
 *   注册到 index.yaml 脚本库，类型"脚本"，在 MlifeApp 之后加载。
 *   暴露 window.DM_Manager，MlifeApp 通过 DM_Manager.xxx 调用。
 */

(function () {
    'use strict';

    // ===================================================================
    // 常量
    // ===================================================================

    var STORAGE_INDEX = 'mlife_dm_index_v1';       // 联系人索引
    var STORAGE_SESS_PREFIX = 'mlife_dm_sess_v1_';  // 会话数据
    var STORAGE_UNREAD = 'mlife_dm_unread_v1';      // 未读计数
    var STORAGE_PERSONA_PREFIX = 'mlife_dm_persona_v1_'; // persona 缓存

    var MAX_SESSION_MSGS = 50;     // 一个会话保留消息上限
    var API_WINDOW = 10;           // 每次发给 API 的最近轮数
    var BRIDGE_COOLDOWN_MS = 5 * 60 * 1000; // 同一联系人桥接冷却 5 分钟
    var MAX_BRIDGE_GLOBAL = 3;     // 全局每 8 轮主线最多注入 3 条
    var MAX_TOKEN = 600;           // API max_tokens
    var TEMPERATURE = 0.85;

    // ===================================================================
    // 内部状态
    // ===================================================================

    var dm = {};
    var _bridgeTimestamps = {};    // map[contact] → last bridge time
    var _currentContact = null;    // 当前打开的会话联系人
    var _sending = false;          // 发送中防重

    // ===================================================================
    // 工具函数
    // ===================================================================

    function now() { return new Date().toISOString(); }

    /* esc 已移至 src/escape.js（外层闭包，目前无调用点，待后续与 escapeHtml 统一） */

    function getContactKey(contact) {
        return (contact || '').trim();
    }

    // ===================================================================
    // 联系人索引导出 / 持久化
    // ===================================================================

    /** 读取联系人索引 */
    function loadIndex() {
        try {
            var raw = localStorage.getItem(STORAGE_INDEX);
            return raw ? JSON.parse(raw) : [];
        } catch (_) { return []; }
    }

    /** 保存联系人索引 */
    function saveIndex(list) {
        try { localStorage.setItem(STORAGE_INDEX, JSON.stringify(list)); } catch (_) {}
    }

    /** 读取未读计数 */
    function loadUnread() {
        try {
            var raw = localStorage.getItem(STORAGE_UNREAD);
            return raw ? JSON.parse(raw) : {};
        } catch (_) { return {}; }
    }

    /** 保存未读计数 */
    function saveUnread(map) {
        try { localStorage.setItem(STORAGE_UNREAD, JSON.stringify(map)); } catch (_) {}
    }

    /** 读取会话 */
    function loadSession(contact) {
        var key = getContactKey(contact);
        if (!key) return null;
        try {
            var raw = localStorage.getItem(STORAGE_SESS_PREFIX + key);
            return raw ? JSON.parse(raw) : null;
        } catch (_) { return null; }
    }

    /** 保存会话 */
    function saveSession(contact, data) {
        var key = getContactKey(contact);
        if (!key) return;
        try { localStorage.setItem(STORAGE_SESS_PREFIX + key, JSON.stringify(data)); } catch (_) {}
    }

    /** 读取缓存 persona */
    function loadPersona(contact) {
        try {
            var raw = localStorage.getItem(STORAGE_PERSONA_PREFIX + getContactKey(contact));
            return raw ? JSON.parse(raw) : null;
        } catch (_) { return null; }
    }

    /** 保存缓存 persona */
    function savePersona(contact, data) {
        try { localStorage.setItem(STORAGE_PERSONA_PREFIX + getContactKey(contact), JSON.stringify(data)); } catch (_) {}
    }

    // ===================================================================
    // API 调用 — 调 tavern 内部 chat-completions
    // ===================================================================

    /* extractReply 已移至 src/parse.js（外层闭包） */

    /**
     * 发送 chat completion 请求到 tavern 后端
     *
     * @param {Array} messages - [{role, content}, ...]
     * @param {string} systemPrompt - DM 角色 system prompt
     * @returns {Promise<string>} AI 回复
     */
    async function dmGenerate(messages, systemPrompt) {
        var chatCompletionSource = window.main_api || 'openai';
        var model = undefined;

        // 获取当前模型
        try {
            if (window.oai_settings && window.oai_settings.model) {
                model = window.oai_settings.model;
            }
        } catch (_) {}

        var payload = {
            messages: [
                { role: 'system', content: systemPrompt },
            ],
            chat_completion_source: chatCompletionSource,
            max_tokens: MAX_TOKEN,
            temperature: TEMPERATURE,
            stream: false,
            use_sysprompt: false,
        };

        // 追加滑动窗口消息 (最近 API_WINDOW 轮)
        var recent = messages.slice(-(API_WINDOW * 2)); // ×2 因为每轮 user+assistant
        for (var i = 0; i < recent.length; i++) {
            payload.messages.push(recent[i]);
        }

        // 加入模型
        if (model) payload.model = model;

        // 获取 CSRF token
        var csrfToken = '';
        try { csrfToken = window.token || ''; } catch (_) {}

        var response;
        try {
            response = await fetch('/api/backends/chat-completions/generate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                },
                cache: 'no-cache',
                body: JSON.stringify(payload),
            });
        } catch (err) {
            // fetch 失败 → 回退到 generateQuietPrompt
            return await fallbackGenerate(messages, systemPrompt);
        }

        if (!response.ok) {
            // API 返回错误 → 回退
            return await fallbackGenerate(messages, systemPrompt);
        }

        var json;
        try { json = await response.json(); } catch (_) {
            return await fallbackGenerate(messages, systemPrompt);
        }

        if (json.error) {
            return await fallbackGenerate(messages, systemPrompt);
        }

        var reply = extractReply(json);
        if (!reply) {
            return await fallbackGenerate(messages, systemPrompt);
        }

        return reply;
    }

    /**
     * 回退方案：使用 generateQuietPrompt
     * 当 fetch API 不可用时调用
     */
    async function fallbackGenerate(messages, systemPrompt) {
        try {
            if (typeof generateQuietPrompt !== 'function') {
                return '[DM 服务暂不可用]';
            }

            // 组装 prompt
            var prompt = systemPrompt + '\n\n';
            var recent = messages.slice(-(API_WINDOW * 2));
            for (var i = 0; i < recent.length; i++) {
                var m = recent[i];
                if (m.role === 'user') prompt += '{{user}}: ' + m.content + '\n';
                else if (m.role === 'assistant') prompt += '你: ' + m.content + '\n';
            }
            prompt += '{{user}}: \n';  // 触发回复

            var result = await generateQuietPrompt({
                quietPrompt: prompt,
                responseLength: MAX_TOKEN,
            });

            return result || '[无回复]';
        } catch (_) {
            return '[消息发送失败]';
        }
    }

    // ===================================================================
    // Persona 管理
    // ===================================================================

    /**
     * 获取联系人的 persona prompt
     * 层级: 缓存 → 开盒数据 → 匹配/详情数据 → 世界书 → AI 生成
     */
    async function getOrCreatePersona(contact, avatar, extra) {
        // 1. 检查缓存
        var cached = loadPersona(contact);
        if (cached && cached.prompt) return cached.prompt;

        // 2. 尝试 AI 生成完整人格
        var personaData = extra || {};
        var prompt = await buildPersonaPrompt(contact, avatar, personaData);

        // 3. 缓存
        savePersona(contact, { prompt: prompt, created: now() });
        return prompt;
    }

    /**
     * AI 生成完整人格底座（使用角色生成模板全维度）
     * 返回 system prompt 文本
     */
    async function buildPersonaPrompt(contact, avatar, data) {
        var name = contact || '对方';
        var age = data.age || '26';
        var job = data.job || '';
        var city = data.city || '';
        var tags = (data.tags || []).join('、');
        var note = data.note || '';
        var selfIntro = data.selfIntro || '';
        var recruitTitle = (data.relationship || '').indexOf('招募') >= 0 ? data.relationship : ('招募「' + (window.top && window.top.MlifeApp ? window.top.MlifeApp.currentPage : '') + '」')
        var rating = data.rating || '4.5';

        // 尝试 AI 生成（走 tavern API）
        try {
            if (typeof dmGenerate === 'function') {
                var genMessages = [
                    { role: 'system', content: '你是一个 M-life 社交软件的角色生成器。根据用户提供的信息，生成一个完整的女性角色设定。输出格式为纯文本角色描述，不要 JSON，不要 markdown。' },
                    { role: 'user', content: '为以下 M-life 用户生成完整的角色设定。\n\n基本信息：\n昵称: ' + name + '\n年龄: ' + age + (job ? '\n职业: ' + job : '') + (city ? '\n城市: ' + city : '') + '\n评分: ' + rating + (tags ? '\n标签: ' + tags : '') + (selfIntro ? '\n自我介绍: ' + selfIntro : '') + '\n\n请按以下维度生成，每个维度 1-3 句话：\n1. 基本信息（年龄/职业/等级/VIP/使用目的）\n2. 外表（身材/面容/特征/穿衣风格）\n3. 性格调色盘（核心驱动/主性格/反差面）\n4. 聊天风格（打字习惯/回复节奏/主动程度/表情使用）\n5. 见面倾向（初次表现/约会习惯/进展节奏）\n6. 对 {{user}} 的态度（初始好感/关系定位）\n\n要求：角色立体有辨识度，避免万能模板，性格和背景要匹配。' }
                ];
                var result = await dmGenerate(genMessages, '');
                if (result && result.length > 50) {
                    var fullPrompt = '你现在是一个叫"' + name + '"的 M-life 社交软件女性用户。\n\n' + result
                        + '\n\n=== 对 {{user}} 的态度 ===\n当前关系: 刚认识' + (recruitTitle ? '（通过' + recruitTitle + '接触）' : '')
                        + '\n好感度: 初始 60/100'
                        + '\n\n=== 规则 ==='
                        + '\n1. 回复像真实人类聊天，1-3 句话，自然口语化，带表情符号'
                        + '\n2. 循序渐渐，不要主动聊色'
                        + '\n3. 语气贴合性格设定'
                        + '\n4. 首次聊天主动做自我介绍'
                        + '\n5. 不要透露自己是 AI';
                    return fullPrompt;
                }
            }
        } catch(_) {}

        // 回退：基础静态 prompt
        return '你现在是一个叫"' + name + '"的 M-life 社交软件女性用户。'
            + '\n年龄: ' + age + (job ? '\n职业: ' + job : '') + (city ? '\n城市: ' + city : '')
            + '\n\n=== 性格 ===\n温柔体贴，开朗健谈'
            + '\n\n=== 聊天习惯 ===\n自然口语化，偶尔用表情'
            + '\n\n=== 对 {{user}} 的态度 ===\n刚认识，友好'
            + '\n\n=== 规则 ===\n1. 回复像真实聊天，1-3句话\n2. 不要主动聊色\n3. 不要透露是AI';
    }

    // ===================================================================
    // 会话管理
    // ===================================================================

    /**
     * 获取/创建会话
     */
    function getOrCreateSession(contact, avatar) {
        var key = getContactKey(contact);
        if (!key) return null;

        var sess = loadSession(key);
        if (sess) return sess;

        // 新建会话
        sess = {
            contact: key,
            avatar: avatar || '👤',
            messages: [],
            created: now(),
            updated: now(),
            version: 1,
        };
        saveSession(key, sess);
        return sess;
    }

    /**
     * 更新联系人索引
     */
    function updateIndex(contact, lastMessage) {
        var list = loadIndex();
        var key = getContactKey(contact);
        var found = false;

        for (var i = 0; i < list.length; i++) {
            if (list[i].contact === key) {
                list[i].lastTime = now();
                if (lastMessage) list[i].lastMessage = lastMessage.slice(0, 60);
                found = true;
                break;
            }
        }

        if (!found) {
            list.push({
                contact: key,
                lastTime: now(),
                lastMessage: lastMessage ? lastMessage.slice(0, 60) : '',
            });
        }

        // 按 lastTime 降序
        list.sort(function (a, b) { return a.lastTime < b.lastTime ? 1 : -1; });
        saveIndex(list);
        return list;
    }

    /**
     * 保留 retention: 超过 MAX_SESSION_MSGS 条 → 压缩为摘要
     * 将最早的一半消息压缩成一条 system 摘要
     */
    function retainSession(contact) {
        var sess = loadSession(getContactKey(contact));
        if (!sess || !sess.messages) return;

        if (sess.messages.length <= MAX_SESSION_MSGS) return;

        // 取前半部分用于压缩
        var half = Math.floor(sess.messages.length / 2);
        var oldPart = sess.messages.splice(0, half);

        // 尝试生成摘要 (只从 oldPart 提取关键内容)
        var summaryLines = [];
        var userTopics = [];
        var aiTopics = [];
        for (var i = 0; i < oldPart.length; i++) {
            var m = oldPart[i];
            var text = (m.content || '').trim();
            if (!text) continue;
            // 只取每轮的第一句作为线索
            var firstSentence = text.split(/[。！？\n]/)[0].slice(0, 30);
            if (m.role === 'user') {
                userTopics.push(firstSentence);
            } else {
                aiTopics.push(firstSentence);
            }
        }

        // 汇总成一条摘要
        var summary = '[历史 ' + oldPart.length + ' 条消息] ';
        if (userTopics.length > 0) {
            summary += '{{user}}聊了: ' + userTopics.slice(0, 3).join('; ');
        }
        if (aiTopics.length > 0) {
            summary += ' | 对方回应: ' + aiTopics.slice(0, 3).join('; ');
        }

        // 插入摘要作为 system 消息
        if (summary.length > 10) {
            sess.messages.unshift({
                role: 'system',
                content: summary.slice(0, 300),
                time: oldPart[0]?.time || '',
                summarized: true,
            });
        }

        sess.updated = now();
        saveSession(getContactKey(contact), sess);
    }

    // ===================================================================
    // 未读管理
    // ===================================================================

    function getUnread(contact) {
        var map = loadUnread();
        return map[getContactKey(contact)] || 0;
    }

    function setUnread(contact, count) {
        var map = loadUnread();
        map[getContactKey(contact)] = count;
        saveUnread(map);
    }

    function incrementUnread(contact) {
        var key = getContactKey(contact);
        var map = loadUnread();
        map[key] = (map[key] || 0) + 1;
        saveUnread(map);
        return map[key];
    }

    function clearUnread(contact) {
        setUnread(contact, 0);
    }

    function getTotalUnread() {
        var map = loadUnread();
        var total = 0;
        for (var k in map) {
            if (map.hasOwnProperty(k)) total += map[k];
        }
        return total;
    }

    // ===================================================================
    // 主线桥接 — MVP 版
    // ===================================================================

    /**
     * 判断是否需要桥接到主线
     * 冷却期内不重复桥接
     */
    function shouldBridge(contact) {
        var key = getContactKey(contact);
        var last = _bridgeTimestamps[key] || 0;
        var elapsed = Date.now() - last;
        return elapsed >= BRIDGE_COOLDOWN_MS;
    }

    /**
     * 执行主线桥接：更新 MVU 变量 + system message
     */
    function bridgeToMain(contact, summary) {
        if (!summary) return;
        var key = getContactKey(contact);
        if (!shouldBridge(key)) return;

        _bridgeTimestamps[key] = Date.now();

        // 1. 更新 MVU 变量 (持久记忆)
        try {
            if (typeof updateVariable === 'function') {
                updateVariable('M-life_私信.最近对话', summary.slice(0, 150));
                updateVariable('M-life_私信.最近联系人', key);
            }
        } catch (_) {}

        // 2. 注入主线 system message
        try {
            if (typeof triggerSlash === 'function') {
                var msg = '[M-life私信] ' + key + ': ' + summary.slice(0, 100);
                triggerSlash('/system ' + msg);
            }
        } catch (_) {}
    }

    // ===================================================================
    // 核心发送逻辑
    // ===================================================================

    /**
     * 发送 DM 消息
     *
     * @param {string} contact - 联系人
     * @param {string} text - 消息内容
     * @param {Object} options - { avatar, personaExtra }
     * @returns {Promise<{ok:boolean, reply?:string, error?:string}>}
     */
    dm.send = async function (contact, text, options) {
        if (!contact || !text) return { ok: false, error: '参数不足' };
        if (_sending) return { ok: false, error: '发送中' };
        _sending = true;

        options = options || {};
        var key = getContactKey(contact);

        try {
            // 1. 获取/创建会话
            var sess = getOrCreateSession(key, options.avatar);
            if (!sess) return { ok: false, error: '会话创建失败' };

            // 2. 确认 persona
            if (!sess.personaPrompt) {
                sess.personaPrompt = await getOrCreatePersona(key, options.avatar, options.personaExtra || {});
            }

            // 3. 添加用户消息
            var userMsg = { role: 'user', content: text, time: now() };
            sess.messages.push(userMsg);
            sess.updated = now();
            saveSession(key, sess);

            // 4. 更新索引 + 清除未读 (发送方清除自己的未读)
            updateIndex(key, text);
            clearUnread(key);

            // 5. 调 API
            var reply = await dmGenerate(sess.messages, sess.personaPrompt);

            if (!reply || reply === '[无回复]' || reply === '[DM 服务暂不可用]' || reply === '[消息发送失败]') {
                // 失败：移除用户消息
                sess.messages.pop();
                saveSession(key, sess);
                return { ok: false, error: reply || '回复为空' };
            }

            // 6. 添加 AI 回复
            var aiMsg = { role: 'assistant', content: reply, time: now() };
            sess.messages.push(aiMsg);
            sess.updated = now();
            saveSession(key, sess);

            // 7. 更新索引
            updateIndex(key, reply);

            // 8. retention 检查
            retainSession(key);

            // 9. 主线桥接 (冷却控制)
            var summary = key + ': ' + text.slice(0, 20) + ' → ' + reply.slice(0, 40);
            bridgeToMain(key, summary);

            return { ok: true, reply: reply };

        } catch (err) {
            return { ok: false, error: err.message || '未知错误' };
        } finally {
            _sending = false;
        }
    };

    // ===================================================================
    // 接收消息 (从主线 AI 的 <mlife_app> 数据)
    // ===================================================================

    /**
     * 接收外部消息 (来自主线的 DM 数据)
     */
    dm.receive = function (data) {
        if (!data || !data.contact) return;

        var key = getContactKey(data.contact);
        var sess = getOrCreateSession(key, data.avatar);
        if (!sess) return;

        // 追加传入消息
        var msgs = data.messages || [];
        var lastMsg = '';
        for (var i = 0; i < msgs.length; i++) {
            var m = msgs[i];
            var role = m.type === 'outgoing' ? 'user' : 'assistant';
            var content = m.text || m.transcript || '';
            if (!content) continue;
            sess.messages.push({ role: role, content: content, time: m.time || now() });
            lastMsg = content;
        }

        sess.updated = now();
        saveSession(key, sess);

        // 更新索引
        updateIndex(key, lastMsg);

        // 增加未读 (如果当前不是这个会话)
        if (_currentContact !== key) {
            incrementUnread(key);
        }

        // 返回是否有新消息
        return msgs.length > 0;
    };

    // ===================================================================
    // 获取数据 (供 UI 渲染使用)
    // ===================================================================

    /** 获取联系人列表 (排序后的) */
    dm.getContactList = function () {
        return loadIndex();
    };

    /** 获取会话消息 */
    dm.getMessages = function (contact) {
        var sess = loadSession(getContactKey(contact));
        return sess ? (sess.messages || []) : [];
    };

    /** 获取会话元数据 */
    dm.getSessionMeta = function (contact) {
        var sess = loadSession(getContactKey(contact));
        if (!sess) return null;
        return {
            contact: sess.contact,
            avatar: sess.avatar,
            created: sess.created,
            updated: sess.updated,
            msgCount: (sess.messages || []).length,
            hasPersona: !!sess.personaPrompt,
        };
    };

    /** 获取联系人的未读数 */
    dm.getUnread = function (contact) {
        return getUnread(contact);
    };

    /** 获取总未读数 */
    dm.getTotalUnread = function () {
        return getTotalUnread();
    };

    /** 设当前打开的联系人 (未读清零用) */
    dm.setCurrentContact = function (contact) {
        _currentContact = getContactKey(contact);
        if (_currentContact) {
            clearUnread(_currentContact);
        }
    };

    /** 清空某联系人所有数据 */
    dm.deleteContact = function (contact) {
        var key = getContactKey(contact);
        try { localStorage.removeItem(STORAGE_SESS_PREFIX + key); } catch (_) {}
        try { localStorage.removeItem(STORAGE_PERSONA_PREFIX + key); } catch (_) {}

        var map = loadUnread();
        delete map[key];
        saveUnread(map);

        var list = loadIndex();
        for (var i = list.length - 1; i >= 0; i--) {
            if (list[i].contact === key) list.splice(i, 1);
        }
        saveIndex(list);

        if (_currentContact === key) _currentContact = null;
    };

    /** 发送中状态 */
    dm.isSending = function () { return _sending; };

    /** AI 生成人格底座 */
    dm.getOrCreatePersona = getOrCreatePersona;
    dm.dmGenerate = function(msg, sys) { return dmGenerate(msg, sys); };
    dm.getOrCreateSession = getOrCreateSession;

    // ===================================================================
    // 对外暴露
    // ===================================================================

    window.DM_Manager = dm;

    // 尝试挂载到 MlifeApp
    try {
        if (window.MlifeApp) {
            window.MlifeApp.dm = dm;
        }
    } catch (_) {}

})();


// [3] Floating Ball + Auto-boot
/**
 * M-life 悬浮控制球
 *
 * 功能:
 *   - 固定在屏幕边缘的悬浮球，可拖动（手机/PC）
 *   - 点击💎直接打开/关闭 MlifeApp 完整浮层（带底部导航栏）
 *   - 自动注入底部导航栏（CDP 模式/角色卡模板缺失时）
 *   - 白天/黑夜主题切换，持久化偏好
 *   - 位置持久化（localStorage）
 *
 * 集成:
 *   注册到 index.yaml 脚本库，类型为"脚本"，导出时携带按钮。
 *   按钮调用 toggle() 可手动展开/收起浮层。
 */

(function () {
  'use strict';

  // ========== 常量 ==========
  var ID = 'mlife-float-ball';
  var STYLE_ID = ID + '-style';
  var STORAGE_KEY = 'mlifeFloatBallPos';
  var THEME_KEY = 'mlifeTheme';
  var Z_BASE = 2147483646;

  // ========== DOM 引用 ==========
  var pdoc, pwin;

  try {
    pdoc = (parent && parent.document) ? parent.document : document;
    pwin = (parent && parent.window) ? parent.window : window;
  } catch (e) {
    pdoc = document;
    pwin = window;
  }

  // ========== 状态 ==========
  var isOpen = false;
  var drag = false;
  var moved = false;
  var ox = 0;
  var oy = 0;
  var sx = 0;
  var sy = 0;
  var DRAG_THRESHOLD = 6;
  var ball, dragMask;
  var _navInjected = false;
  var _themeInjected = false;
  var _navWrapped = false;

  // 导航历史栈
  var _pageHistory = ['home'];
  // 主 tab 列表（底部导航栏页面），切 tab 时重置历史
  var _tabPages = ['home', 'match', 'live_list', 'dm', 'profile'];

  // ========== 位置 ==========
  var pos = {
    x: pwin.innerWidth - 80,
    y: Math.round(pwin.innerHeight * 0.4),
  };

  try {
    var saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      var p = JSON.parse(saved);
      pos.x = clamp(Number(p.x) || pos.x, 0, pwin.innerWidth - 60);
      pos.y = clamp(Number(p.y) || pos.y, 0, pwin.innerHeight - 60);
    }
  } catch (_) {}

  function clamp(v, min, max) {
    return Math.max(min, Math.min(v, max));
  }

  // ========== 读取主题偏好 ==========
  function getSavedTheme() {
    try {
      return localStorage.getItem(THEME_KEY) || 'dark';
    } catch (_) { return 'dark'; }
  }

  function saveTheme(t) {
    try { localStorage.setItem(THEME_KEY, t); } catch (_) {}
  }

  // ========== 样式注入（含主题） ==========
  function injectStyles() {
    if (pdoc.getElementById(STYLE_ID)) return;

    var css = pdoc.createElement('style');
    css.id = STYLE_ID;
    css.textContent = [
      // ==========================================
      // 悬浮球
      // ==========================================
      '#' + ID + '{',
      'position:fixed!important;',
      'z-index:' + Z_BASE + '!important;',
      'width:52px;height:52px;',
      'border-radius:50%;',
      'background:linear-gradient(135deg,#ff6b9d 0%,#ff8fb4 100%);',
      'box-shadow:0 4px 16px rgba(255,107,157,0.4),0 2px 4px rgba(0,0,0,0.2);',
      'display:flex;align-items:center;justify-content:center;',
      'cursor:grab;',
      'user-select:none;-webkit-user-select:none;',
      'touch-action:none;',
      'transition:box-shadow 0.2s,transform 0.15s;',
      'font-size:22px;line-height:1;',
      'color:#fff;',
      'pointer-events:auto;',
      '}',
      '#' + ID + ':active{cursor:grabbing;}',
      '#' + ID + ':hover{box-shadow:0 6px 24px rgba(255,107,157,0.55);transform:scale(1.05);}',

      // ==========================================
      // 主题 CSS 变量
      // ==========================================
      '#mlife-app{',
      '--ml-bg:rgba(5,10,14,0.97);',
      '--ml-bg-card:#12121a;',
      '--ml-bg-section:#1a1a2e;',
      '--ml-bg-hover:#2a2a3e;',
      '--ml-bg-info:#0d0d18;',
      '--ml-text:#eee;',
      '--ml-text-main:#ddd;',
      '--ml-text-dim:#8a8a9a;',
      '--ml-text-dimmer:#666;',
      '--ml-border:#1e1e2e;',
      '--ml-border-light:#2a2a3e;',
      '--ml-accent:#ff6b9d;',
      '--ml-accent-light:#ff8fb4;',
      '--ml-accent-glow:rgba(255,107,157,0.15);',
      '--ml-border-1a:#1a1a2e;',
      '--ml-text-ccc:#ccc;',
      '--ml-text-bbb:#bbb;',
      '--ml-text-aaa:#aaa;',
      '--ml-cyan:#00e5ff;',
      '--ml-glow-10:rgba(255,107,157,0.1);',
      '--ml-gold:linear-gradient(135deg,#f6d365,#fda085);',

      '--ml-nav-bg:#14141e;',
      '--ml-nav-hover:rgba(255,255,255,0.06);',
      '--ml-nav-active-bg:rgba(255,107,157,0.08);',
      '}',
      '#mlife-app.mlife-theme-light{',
      '--ml-bg:#f5f0eb;',
      '--ml-bg-card:#ffffff;',
      '--ml-bg-section:#f0ece6;',
      '--ml-bg-hover:#e8e4de;',
      '--ml-bg-info:#faf8f5;',
      '--ml-text:#222;',
      '--ml-text-main:#444;',
      '--ml-text-dim:#888;',
      '--ml-text-dimmer:#aaa;',
      '--ml-border:#e0ddd8;',
      '--ml-border-light:#d0ccc8;',
      '--ml-accent:#e05570;',
      '--ml-accent-light:#f07890;',
      '--ml-accent-glow:rgba(224,85,112,0.12);',
      '--ml-border-1a:#e0ddd8;',
      '--ml-text-ccc:#444;',
      '--ml-text-bbb:#444;',
      '--ml-text-aaa:#888;',
      '--ml-cyan:#0891b2;',
      '--ml-glow-10:rgba(224,85,112,0.12);',
      '--ml-gold:#f07890;',

      '}',

      // ==========================================
      // 浮层 chrome（header / body / nav）
      // ==========================================
      '#mlife-app-header{',
      'background:var(--ml-bg-section)!important;',
      'border-bottom-color:var(--ml-border)!important;',
      '}',
      '#mlife-app-header span{color:var(--ml-accent-light)!important;}',
      '#mlife-app-header button{color:var(--ml-text-dim)!important;}',
      '#mlife-app-body{background:var(--ml-bg)!important;min-height:0;}',
      '#mlife-app{color:var(--ml-text-main);}',

      // 底部导航
      '#mlife-app .nav-bar{',
      'display:flex;flex-shrink:0;',
      'background:var(--ml-bg-section)!important;',
      'border-top:1px solid var(--ml-border)!important;',
      'padding:4px 2px;',
      'box-shadow:0 -1px 8px rgba(0,0,0,0.04);',
      '}',
      '#mlife-app .nav-item{',
      'flex:1;display:flex;flex-direction:column;',
      'align-items:center;justify-content:center;',
      'gap:3px;padding:6px 4px;margin:0 4px;',
      'cursor:pointer;border:none;background:transparent;',
      'color:var(--ml-text-dim)!important;font-family:inherit;',
      'font-size:10px;letter-spacing:0.06em;line-height:1;',
      'border-radius:8px;',
      'transition:all 0.2s;user-select:none;',
      '}',
      '#mlife-app .nav-item:hover{',
      'color:var(--ml-text-main)!important;',
      'background:var(--ml-nav-hover)!important;',
      '}',
      '#mlife-app .nav-item.active{',
      'color:var(--ml-accent)!important;',
      'background:var(--ml-nav-active-bg)!important;',
      'text-shadow:0 0 6px var(--ml-accent-glow)!important;',
      '}',
      '#mlife-app .nav-icon{font-size:18px;line-height:1;pointer-events:none;}',
      '#mlife-app .nav-label{line-height:1;pointer-events:none;}',

      // 主题切换按钮
      '#mlife-theme-btn{',
      'background:none;border:none;',
      'cursor:pointer;padding:2px 4px;line-height:1;',
      'font-family:inherit;font-size:15px;',
      'transition:transform 0.2s;',
      '}',
      '#mlife-theme-btn:hover{transform:scale(1.15);}',

      // 返回按钮
      '#mlife-back-btn{',
      'background:none;border:none;',
      'cursor:pointer;padding:2px 4px;line-height:1;',
      'font-family:inherit;font-size:16px;',
      'color:var(--ml-text-dim)!important;',
      'transition:transform 0.2s,color 0.2s;',
      'display:none;margin-right:2px;',
      '}',
      '#mlife-back-btn:hover{transform:scale(1.15);color:var(--ml-accent)!important;}',
      '#mlife-back-btn.visible{display:inline-block;}',

      // ==========================================
      // 内容区 — inline 样式已改用 var(--ml-*)，主题色由下方 #mlife-app 变量统一定义
      // ==========================================

      // Toast
      '.mlf-toast{',
      'position:fixed;top:20px;left:50%;transform:translateX(-50%);',
      'z-index:' + (Z_BASE + 10) + ';',
      'background:var(--ml-bg-card);border:1px solid var(--ml-accent-glow);',
      'border-radius:20px;padding:8px 18px;',
      'color:var(--ml-accent-light);font-size:13px;',
      'box-shadow:0 4px 16px rgba(0,0,0,0.4);',
      'pointer-events:none;',
      'animation:mlfFadeInOut 1.8s ease forwards;',
      '}',
      '@keyframes mlfFadeInOut{',
      '0%{opacity:0;transform:translateX(-50%) translateY(-8px);}',
      '15%{opacity:1;transform:translateX(-50%) translateY(0);}',
      '80%{opacity:1;}',
      '100%{opacity:0;transform:translateX(-50%) translateY(-4px);}',
      '}',
    ].join('\n');
    pdoc.head.appendChild(css);
  }

  // ========== Toast 提示 ==========
  function toast(msg) {
    var el = pdoc.createElement('div');
    el.className = 'mlf-toast';
    el.textContent = msg;
    pdoc.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 2000);
  }

  // ========== 主题切换 ==========
  var currentTheme = getSavedTheme();

  function applyTheme(theme) {
    var appEl = pdoc.getElementById('mlife-app');
    if (!appEl) return;
    appEl.classList.remove('mlife-theme-dark', 'mlife-theme-light');
    appEl.classList.add('mlife-theme-' + theme);
    currentTheme = theme;
    saveTheme(theme);

    // 更新按钮图标
    var btn = pdoc.getElementById('mlife-theme-btn');
    if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
  }

  function toggleTheme() {
    var next = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    toast(next === 'light' ? '☀️ 白天模式' : '🌙 黑夜模式');
  }

  function ensureThemeBtn() {
    if (_themeInjected) return;
    var header = pdoc.getElementById('mlife-app-header');
    if (!header) return;

    // 如果已有按钮则跳过
    if (pdoc.getElementById('mlife-theme-btn')) { _themeInjected = true; return; }

    var btn = pdoc.createElement('button');
    btn.id = 'mlife-theme-btn';
    btn.title = '切换主题';
    btn.textContent = currentTheme === 'dark' ? '☀️' : '🌙';
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      toggleTheme();
    });

    // 插入到关闭按钮前面
    var closeBtn = pdoc.getElementById('mlife-app-close');
    if (closeBtn) {
      header.insertBefore(btn, closeBtn);
    } else {
      header.appendChild(btn);
    }

    _themeInjected = true;
  }

  // ========== 返回按钮 ==========
  function ensureBackBtn() {
    var header = pdoc.getElementById('mlife-app-header');
    if (!header) return;
    if (pdoc.getElementById('mlife-back-btn')) return;

    var backBtn = pdoc.createElement('button');
    backBtn.id = 'mlife-back-btn';
    backBtn.title = '返回';
    backBtn.textContent = '←';
    backBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      goBack();
    });

    // 插入到标题前面
    var title = header.querySelector('span');
    if (title) {
      header.insertBefore(backBtn, title);
    } else {
      header.insertBefore(backBtn, header.firstChild);
    }
  }

  function updateBackBtn() {
    var btn = pdoc.getElementById('mlife-back-btn');
    if (!btn) return;
    // 历史栈只有当前页（或空）时隐藏返回按钮
    var show = _pageHistory.length > 1;
    if (show) { btn.classList.add('visible'); }
    else { btn.classList.remove('visible'); }
  }

  function goBack() {
    if (_pageHistory.length <= 1) return;
    _pageHistory.pop(); // 当前页
    var target = _pageHistory.pop(); // 上一页
    if (!target) { _pageHistory = ['home']; target = 'home'; }
    _pageHistory.push(target);
    try {
      if (pwin.MlifeApp && typeof pwin.MlifeApp.switchTab === 'function') {
        pwin.MlifeApp.switchTab(target);
      }
    } catch (e) {
      console.warn('[悬浮球] 返回失败:', e);
      _pageHistory = ['home'];
    }
    updateBackBtn();
  }

  // ========== 包装导航函数以跟踪历史 ==========
  function wrapNavigation() {
    if (_navWrapped || !pwin.MlifeApp) return;

    // 包装 navigate（子页面导航用）
    if (typeof pwin.MlifeApp.navigate === 'function') {
      var origNavigate = pwin.MlifeApp.navigate;
      pwin.MlifeApp.navigate = function (page, data) {
        if (_tabPages.indexOf(page) !== -1) {
          _pageHistory = [page];
        } else {
          if (_pageHistory.length === 0 || _pageHistory[_pageHistory.length - 1] !== page) {
            _pageHistory.push(page);
          }
        }
        updateBackBtn();
        return origNavigate.call(pwin.MlifeApp, page, data);
      };
    }

    // 包装 switchTab（主 tab + 部分子页面混合用，如 profile section 导航）
    if (typeof pwin.MlifeApp.switchTab === 'function') {
      var origSwitchTab = pwin.MlifeApp.switchTab;
      pwin.MlifeApp.switchTab = function (tab) {
        if (_tabPages.indexOf(tab) !== -1) {
          _pageHistory = [tab];
        } else {
          if (_pageHistory.length === 0 || _pageHistory[_pageHistory.length - 1] !== tab) {
            _pageHistory.push(tab);
          }
        }
        updateBackBtn();
        return origSwitchTab.call(pwin.MlifeApp, tab);
      };
    }

    _navWrapped = true;
  }

  // ========== 重置导航历史（切 tab 时调用） ==========
  function resetHistory(tab) {
    _pageHistory = [tab || 'home'];
    updateBackBtn();
  }

  // ========== 确保底部导航存在 ==========
  function ensureBottomNav() {
    if (_navInjected) return true;
    var appEl = pdoc.getElementById('mlife-app');
    if (!appEl) return false;

    // 已有导航栏（角色卡模板自带）
    if (appEl.querySelector('.nav-bar')) {
      _navInjected = true;
      bindNavClicks();
      return true;
    }

    // 将浮层改为 flex 布局，以便底部导航固定在底部
    appEl.style.display = 'none';
    appEl.style.flexDirection = 'column';
    appEl.style.overflow = 'hidden';

    var body = pdoc.getElementById('mlife-app-body');
    if (body) {
      body.style.flex = '1';
      body.style.minHeight = '0';
      body.style.overflowY = 'auto';
    }

    // 创建底部导航栏
    var nav = pdoc.createElement('div');
    nav.className = 'nav-bar';
    nav.innerHTML = ''
      + '<button class="nav-item active" id="nav-home">'
        + '<span class="nav-icon">&#x2302;</span>'
        + '<span class="nav-label">首页</span>'
      + '</button>'
      + '<button class="nav-item" id="nav-match">'
        + '<span class="nav-icon">&#x2661;</span>'
        + '<span class="nav-label">匹配</span>'
      + '</button>'
      + '<button class="nav-item" id="nav-live">'
        + '<span class="nav-icon">&#x25B6;</span>'
        + '<span class="nav-label">直播</span>'
      + '</button>'
      + '<button class="nav-item" id="nav-dm">'
        + '<span class="nav-icon">&#x2709;</span>'
        + '<span class="nav-label">私信</span>'
      + '</button>'
      + '<button class="nav-item" id="nav-me">'
        + '<span class="nav-icon">&#x263A;</span>'
        + '<span class="nav-label">我的</span>'
      + '</button>';
    appEl.appendChild(nav);

    // 绑定导航点击
    bindNavClicks();

    _navInjected = true;
    console.log('[悬浮球] 底部导航已注入');
    return true;
  }

  // ========== 导航点击绑定 ==========
  function bindNavClicks() {
    var navMap = {
      'nav-home': 'home',
      'nav-match': 'match',
      'nav-live': 'live_list',
      'nav-dm': 'dm',
      'nav-me': 'profile'
    };

    Object.keys(navMap).forEach(function (id) {
      var el = pdoc.getElementById(id);
      if (!el) return;
      el.addEventListener('click', function () {
        var page = navMap[id];
        // 主 tab 点击时重置导航历史
        resetHistory(page);
        try {
          if (pwin.MlifeApp && typeof pwin.MlifeApp.switchTab === 'function') {
            pwin.MlifeApp.switchTab(page);
          } else if (pwin.MlifeApp && typeof pwin.MlifeApp.navigate === 'function') {
            pwin.MlifeApp.navigate(page);
          }
        } catch (e) {
          console.warn('[悬浮球] 导航失败:', e);
        }
      });
    });
  }

  // ========== 拖拽逻辑 ==========
  function createMask() {
    removeMask();
    dragMask = pdoc.createElement('div');
    dragMask.style.cssText = 'position:fixed;inset:0;z-index:' + (Z_BASE + 2) + ';cursor:grabbing;background:transparent;touch-action:none;pointer-events:none;';
    pdoc.body.appendChild(dragMask);
  }

  function removeMask() {
    if (dragMask) { dragMask.remove(); dragMask = null; }
  }

  function savePos() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ x: parseInt(ball.style.left), y: parseInt(ball.style.top) }));
    } catch (_) {}
  }

  function startDrag(cx, cy) {
    drag = true;
    moved = false;
    sx = cx; sy = cy;
    var rect = ball.getBoundingClientRect();
    ox = cx - rect.left;
    oy = cy - rect.top;
    ball.style.transition = 'none';
    createMask();
  }

  function moveDrag(cx, cy) {
    if (!drag) return;
    if (!moved && Math.abs(cx - sx) < DRAG_THRESHOLD && Math.abs(cy - sy) < DRAG_THRESHOLD) return;
    moved = true;
    ball.style.left = clamp(cx - ox, 0, pwin.innerWidth - 52) + 'px';
    ball.style.top = clamp(cy - oy, 0, pwin.innerHeight - 52) + 'px';
  }

  function endDrag() {
    if (!drag) return;
    drag = false;
    ball.style.transition = '';
    removeMask();
    if (moved) savePos();
  }

  // ========== 确保浮层为 flex 布局 ==========
  function ensureFlexLayout(appEl) {
    if (_navInjected && appEl) {
      appEl.style.display = 'flex';
      appEl.style.flexDirection = 'column';
    }
  }

  // ========== 切换 MlifeApp 浮层 ==========
  function toggleApp() {
    var appEl = pdoc.getElementById('mlife-app');
    if (!appEl) {
      toast('MlifeApp 未加载');
      return;
    }

    isOpen = !isOpen;

    if (isOpen) {
      // 1. 确保底部导航存在
      ensureBottomNav();

      // 2. 应用保存的主题
      applyTheme(currentTheme);

      // 3. 确保主题按钮和返回按钮存在
      ensureThemeBtn();
      ensureBackBtn();

      // 4. 包装导航函数跟踪历史
      wrapNavigation();
      updateBackBtn();

      // 5. 打开浮层
      appEl.style.display = 'flex';
      appEl.style.flexDirection = 'column';

      // 6. 用 switchTab 恢复页面（走缓存）
      try {
        if (pwin.MlifeApp) {
          var current = pwin.MlifeApp.currentPage;
          pwin.MlifeApp.switchTab(current || 'home');
        }
      } catch (e) {
        console.warn('[悬浮球] 导航失败:', e);
      }

      // 7. 确保 flex 布局
      ensureFlexLayout(appEl);

      // 8. 球状态
      ball.style.transform = 'scale(1.1)';
      ball.style.boxShadow = '0 6px 24px rgba(255,107,157,0.55)';
    } else {
      appEl.style.display = 'none';
      ball.style.transform = '';
      ball.style.boxShadow = '';
    }
  }

  // ========== 构建 DOM ==========
  function buildUI() {
    // 悬浮球
    ball = pdoc.createElement('div');
    ball.id = ID;
    ball.textContent = '💎';
    ball.style.left = pos.x + 'px';
    ball.style.top = pos.y + 'px';
    ball.title = '打开/关闭 M-life';
    pdoc.body.appendChild(ball);

    // 同步浮层关闭按钮状态
    function watchCloseBtn() {
      var closeBtn = pdoc.getElementById('mlife-app-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', function () {
          isOpen = false;
          if (ball) {
            ball.style.transform = '';
            ball.style.boxShadow = '';
          }
        });
      }
    }

    // ---- 点击：切换浮层 ----
    ball.addEventListener('click', function (e) {
      if (moved) {
        moved = false;
        return;
      }
      e.stopPropagation();
      watchCloseBtn();
      toggleApp();
    });

    // ---- 鼠标拖拽 ----
    ball.addEventListener('mousedown', function (e) {
      if (e.button !== 0) return;
      startDrag(e.clientX, e.clientY);
    });
    pdoc.addEventListener('mousemove', function (e) { moveDrag(e.clientX, e.clientY); });
    pdoc.addEventListener('mouseup', function () { if (drag) endDrag(); });

    // ---- 触摸拖拽 ----
    ball.addEventListener('touchstart', function (e) {
      var t = e.touches[0];
      startDrag(t.clientX, t.clientY);
    }, { passive: true });
    pdoc.addEventListener('touchmove', function (e) {
      if (!drag) return;
      var t = e.touches[0];
      moveDrag(t.clientX, t.clientY);
      e.preventDefault();
    }, { passive: false });
    pdoc.addEventListener('touchend', function () { if (drag) endDrag(); });
    pdoc.addEventListener('touchcancel', function () { if (drag) endDrag(); });
  }

  // ========== 初始化 ==========
  function init() {
    if (pdoc.getElementById(ID)) return;

    injectStyles();
    buildUI();

    // 窗口缩放时保持球在视口内
    pwin.addEventListener('resize', function () {
      if (!ball) return;
      var maxX = pwin.innerWidth - 60;
      var maxY = pwin.innerHeight - 60;
      ball.style.left = Math.min(parseInt(ball.style.left) || 0, maxX) + 'px';
      ball.style.top = Math.min(parseInt(ball.style.top) || 0, maxY) + 'px';
    });
  }

  // ---------- 自动启动 ----------
  function autoBoot() {
    if (pdoc.getElementById(ID)) return;
    init();
  }

  if (pdoc.readyState === 'loading') {
    pdoc.addEventListener('DOMContentLoaded', autoBoot);
  } else {
    autoBoot();
  }

  // 暴露给外部
  pwin.MlifeFloatBall = {
    toggle: toggleApp,
    close: function () { if (isOpen) toggleApp(); },
    open: function () { if (!isOpen) toggleApp(); },
    refresh: function () { toast('状态已刷新'); },
    setTheme: function (t) { if (t === 'light' || t === 'dark') { currentTheme = t; saveTheme(t); applyTheme(t); } },
  };

})();



// [4] Auto-init MlifeApp
setTimeout(function() {
  try {
    if (typeof MlifeApp !== "undefined" && typeof MlifeApp.init === "function") {
      MlifeApp.init();
      console.log("[Mlife] Auto-init complete");
    }
  } catch(e) {
    console.warn("[Mlife] Auto-init error:", e);
  }
}, 800);

// [4] Auto-init
setTimeout(function() {
  try {
    if (typeof MlifeApp !== "undefined" && typeof MlifeApp.init === "function") {
      if (typeof waitGlobalInitialized === "function") {
        waitGlobalInitialized("Mvu").then(function() { MlifeApp.init(); });
      } else {
        MlifeApp.init();
      }
      console.log("[Mlife] All-in-One boot complete");
    }
  } catch(e) {
    console.warn("[Mlife] boot error:", e);
  }
}, 800);

})();