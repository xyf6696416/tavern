# -*- coding: utf-8 -*-
# phase3_relocate.py
# 将 20 个 app.render* / renderPage 函数从 src/main.js 逐字搬迁到 src/views/render<Name>.js
# 搬迁为纯机械（字节一致），保证零行为变更；后续由 build.js 注入到内层 IIFE。
import io, os, re

SRC = r"X:/tavern_sync_project/角色卡修改用/魅途/脚本/src"
main_path = os.path.join(SRC, "main.js")
text = io.open(main_path, encoding="utf-8").read()

NAMES = [
    "renderRecruitDetailLocal", "renderRecruitManage", "renderHome", "renderDMList",
    "renderMatch", "renderDetail", "renderLiveList", "renderLive", "renderGoddess",
    "renderResource", "renderProfile", "renderSelfie", "renderChat", "renderDM",
    "renderRecruitList", "renderRecruitDetail", "renderRecruitPost", "renderUnbox",
    "renderPage", "renderSettings",
]

def extract(name):
    pat = re.compile(r'\n[ \t]*app\.' + re.escape(name) + r'\s*=\s*function')
    m = pat.search(text)
    if not m:
        raise SystemExit("NOT FOUND: " + name)
    # 找到 function 后的首个 {
    ob = text.index('{', m.end() - 1)
    depth = 0
    i = ob
    n = len(text)
    instr = None
    while i < n:
        c = text[i]
        if instr is not None:
            if c == '\\':
                i += 2
                continue
            if c == instr:
                instr = None
            i += 1
            continue
        if c == "'" or c == '"' or c == '`':
            instr = c
            i += 1
            continue
        if c == '{':
            depth += 1
            i += 1
            continue
        if c == '}':
            depth -= 1
            if depth == 0:
                break
            i += 1
            continue
        i += 1
    end = i  # 闭合 } 的位置
    line_start = text.rfind('\n', 0, m.start()) + 1
    after = end + 1
    while after < n and text[after] in ' \t':
        after += 1
    if after < n and text[after] == ';':
        after += 1
    snippet = text[line_start:after]
    return line_start, after, snippet

removed_spans = []
views_dir = os.path.join(SRC, "views")
os.makedirs(views_dir, exist_ok=True)
report = []
for name in NAMES:
    ls, ae, snip = extract(name)
    removed_spans.append((ls, ae))
    fpath = os.path.join(views_dir, "render" + name[0].upper() + name[1:] + ".js")
    io.open(fpath, "w", encoding="utf-8").write(snip + "\n")
    report.append((name, len(snip), snip[:38].replace("\n", " "), snip[-12:].replace("\n", " ")))

# 从后往前删除，避免偏移
new = text
for ls, ae in sorted(removed_spans, reverse=True):
    new = new[:ls] + "\n" + new[ae:]

# 插入视图注入标记（紧接 var app = {}; 之后）
marker = "            var app = {};\n"
mid = new.index(marker) + len(marker)
new = new[:mid] + "            /*__MLIFE_VIEWS__*/\n" + new[mid:]

io.open(main_path, "w", encoding="utf-8").write(new)

print("relocated %d functions -> %s" % (len(NAMES), views_dir))
for name, ln, head, tail in report:
    print("  %-26s len=%-5d  head=%-36s  tail=%s" % (name, ln, head, tail))
