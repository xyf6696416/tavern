# -*- coding: utf-8 -*-
# Phase 2 迁移：将内容区内联字面量改为 var(--ml-*)，删除脆弱的 [style*=""] 属性覆盖，
# 注入专属主题变量（dark=原值 / light=旧覆盖目标），并把两处 statusColorMap 合并为 STATUS_COLORS。
import re, io

PATH = r"X:/tavern_sync_project/角色卡修改用/魅途/脚本/src/main.js"
with io.open(PATH, 'r', encoding='utf-8') as f:
    t = f.read()

# 22 条：被旧 [style*=""] 覆盖规则命中的内联字面量 -> var()
# 注意：dark 模式下旧覆盖规则不生效，故专属变量的 dark 值必须等于原字面量，才能逐字节保住 dark 渲染。
REPL = [
    ("background:#12121a", "background:var(--ml-bg-card)"),
    ("background:#1a1a2e", "background:var(--ml-bg-section)"),
    ("background:#0d0d18", "background:var(--ml-bg-info)"),
    ("background:#0a1017", "background:var(--ml-bg-0a1017)"),
    ("background:#2a2a3e", "background:var(--ml-bg-hover)"),
    ("border-color:#ff6b9d", "border-color:var(--ml-accent)"),
    ("border:1px solid #1e1e2e", "border:1px solid var(--ml-border)"),
    ("border-bottom:1px solid #1e1e2e", "border-bottom:1px solid var(--ml-border)"),
    ("border-bottom:1px solid #1a1a2e", "border-bottom:1px solid var(--ml-border-1a)"),
    ("color:#eee", "color:var(--ml-text)"),
    ("color:#ddd", "color:var(--ml-text-main)"),
    ("color:#ccc", "color:var(--ml-text-ccc)"),
    ("color:#bbb", "color:var(--ml-text-bbb)"),
    ("color:#8a8a9a", "color:var(--ml-text-dim)"),
    ("color:#aaa", "color:var(--ml-text-aaa)"),
    ("color:#666", "color:var(--ml-text-dimmer)"),
    ("color:#ff6b9d", "color:var(--ml-accent)"),
    ("color:#ff8fb4", "color:var(--ml-accent-light)"),
    ("color:#00e5ff", "color:var(--ml-cyan)"),
    ("background:rgba(255,107,157,0.1)", "background:var(--ml-glow-10)"),
    ("background:rgba(255,107,157,0.05)", "background:var(--ml-glow-05)"),
    ("background:linear-gradient(135deg,#f6d365,#fda085)", "background:var(--ml-gold)"),
]

print("=== 字面量 -> var() 替换计数 ===")
for old, new in REPL:
    n = t.count(old)
    if n:
        t = t.replace(old, new)
    print("%3d  %s" % (n, old))

# 删除脆弱的 [style*="..."] 属性覆盖规则（仅存在于 .mlife-theme-light 作用域内）
before = t.count("[style*=")
t = re.sub(r"^\s*'#mlife-app\.mlife-theme-light \[style\*=[^\n]*',\n", "", t, flags=re.MULTILINE)
after = t.count("[style*=")
print("\n=== [style*=''] 规则: 删除前 %d -> 删除后 %d ===" % (before, after))

# 更新内容区注释
t = t.replace(
    "      // 内容区 — 用 CSS 变量覆盖 inline 样式",
    "      // 内容区 — inline 样式已改用 var(--ml-*)，主题色由下方 #mlife-app 变量统一定义"
)

# 注入专属变量（dark = 原字面量；light = 旧覆盖目标）
dark_anchor = "      '--ml-accent-glow:rgba(255,107,157,0.15);',"
light_anchor = "      '--ml-accent-glow:rgba(224,85,112,0.12);',"

dark_vars = dark_anchor + "\n" + (
    "      '--ml-bg-0a1017:#0a1017;',\n"
    "      '--ml-border-1a:#1a1a2e;',\n"
    "      '--ml-text-ccc:#ccc;',\n"
    "      '--ml-text-bbb:#bbb;',\n"
    "      '--ml-text-aaa:#aaa;',\n"
    "      '--ml-cyan:#00e5ff;',\n"
    "      '--ml-glow-10:rgba(255,107,157,0.1);',\n"
    "      '--ml-glow-05:rgba(255,107,157,0.05);',\n"
    "      '--ml-gold:linear-gradient(135deg,#f6d365,#fda085);',\n"
)
light_vars = light_anchor + "\n" + (
    "      '--ml-bg-0a1017:#f0ece6;',\n"
    "      '--ml-border-1a:#e0ddd8;',\n"
    "      '--ml-text-ccc:#444;',\n"
    "      '--ml-text-bbb:#444;',\n"
    "      '--ml-text-aaa:#888;',\n"
    "      '--ml-cyan:#0891b2;',\n"
    "      '--ml-glow-10:rgba(224,85,112,0.12);',\n"
    "      '--ml-glow-05:rgba(224,85,112,0.12);',\n"
    "      '--ml-gold:#f07890;',\n"
)
if dark_anchor in t:
    t = t.replace(dark_anchor, dark_vars, 1)
    print("已注入 dark 专属变量")
else:
    print("!! 未找到 dark anchor")

if light_anchor in t:
    t = t.replace(light_anchor, light_vars, 1)
    print("已注入 light 专属变量")
else:
    print("!! 未找到 light anchor")

# statusColorMap 两处取并集 -> 共用 STATUS_COLORS（零行为变更）
n_sm = len(re.findall(r"var statusColorMap = \{", t))
t = re.sub(r"var statusColorMap = \{[\s\S]*?\};", "var statusColorMap = STATUS_COLORS;", t)
n_sm2 = len(re.findall(r"var statusColorMap = STATUS_COLORS;", t))
print("\n=== statusColorMap: %d 处局部定义 -> %d 处共用 STATUS_COLORS ===" % (n_sm, n_sm2))

with io.open(PATH, 'w', encoding='utf-8') as f:
    f.write(t)
print("\n已写回 src/main.js")
