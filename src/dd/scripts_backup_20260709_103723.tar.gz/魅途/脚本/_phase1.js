// Phase 1: 管理页闭环 批量修改
const fs = require('fs');
let code = fs.readFileSync('E:/tavern_sync_project/角色卡修改用/魅途/脚本/Mlife_TH.js', 'utf8');

// === Edit 1: 路由注册（第 822-823 行）===
code = code.replace(
  "case 'recruit_detail': case 'recruitdetail': return app.renderRecruitDetail(data);\n                    case 'recruit_post': case 'recruitpost': return app.renderRecruitPost(data);",
  "case 'recruit_detail': case 'recruitdetail': return app.renderRecruitDetail(data);\n                    case 'recruit_detail_local': return app.renderRecruitDetailLocal(data.postId);\n                    case 'recruit_post': case 'recruitpost': return app.renderRecruitPost(data);"
);

// === Edit 2: 在 getRecruitPosts 后添加 helper 函数 ===
const helperInsert = `            app.getRecruitPostById = function(id) {
                var posts = app.getRecruitPosts();
                for (var i = 0; i < posts.length; i++) {
                    if (posts[i].id === id) return posts[i];
                }
                return null;
            };

            app.cancelRecruitPost = function(id) {
                try {
                    var posts = app.getRecruitPosts();
                    for (var i = 0; i < posts.length; i++) {
                        if (posts[i].id === id) {
                            posts[i].status = '已取消';
                            posts[i].progress = '已主动取消';
                            localStorage.setItem('mlife_recruit_posts', JSON.stringify(posts));
                            return true;
                        }
                    }
                } catch(e) { console.warn('[MlifeApp] cancelRecruitPost error:', e); }
                return false;
            };

            app.reactivateRecruitPost = function(id) {
                try {
                    var posts = app.getRecruitPosts();
                    for (var i = 0; i < posts.length; i++) {
                        if (posts[i].id === id) {
                            posts[i].status = '招募中';
                            posts[i].progress = '已重新发布';
                            localStorage.setItem('mlife_recruit_posts', JSON.stringify(posts));
                            return true;
                        }
                    }
                } catch(e) { console.warn('[MlifeApp] reactivateRecruitPost error:', e); }
                return false;
            };

            app.renderRecruitDetailLocal = function(postId) {
                var post = app.getRecruitPostById(postId);
                if (!post) {
                    return '<div style="padding:30px;text-align:center;color:#8a8a9a;font-size:14px;">招募已不存在</div>';
                }

                var statusColorMap = {
                    '招募中': '#34d399','已报名': '#60a5fa','已确认': '#60a5fa','已选中': '#60a5fa',
                    '已完成': '#34d399','已取消': '#9ca3af','未选中': '#6a6a70','争议中': '#f87171','已锁定': '#60a5fa'
                };
                var sc = statusColorMap[post.status] || '#9ca3af';
                var sRgb = app.hexToRgb(sc);
                var statusTag = '<span style="font-size:12px;padding:2px 10px;border-radius:4px;background:rgba(' + sRgb + ',0.1);color:' + sc + ';border:1px solid rgba(' + sRgb + ',0.2);font-weight:500;">' + app.escapeHtml(post.status) + '</span>';

                // 应征者列表
                var applicantsHtml = '';
                var applicants = JSON.parse(localStorage.getItem('mlife_recruit_applicants_' + post.id) || '[]');
                if (applicants.length === 0) {
                    applicantsHtml = '<div style="padding:24px;text-align:center;"><div style="font-size:32px;margin-bottom:8px;opacity:0.5;">📭</div><div style="font-size:13px;color:#6a6a70;">还没有人应征</div><div style="font-size:11px;color:#6a6a70;margin-top:4px;">发布后等待平台推荐应征者</div></div>';
                } else {
                    applicantsHtml = '<div style="display:flex;flex-direction:column;gap:8px;">';
                    for (var ai = 0; ai < applicants.length; ai++) {
                        var a = applicants[ai];
                        var aSc = statusColorMap[a.status] || '#9ca3af';
                        var aRgb = app.hexToRgb(aSc);
                        var aStatusTag = '<span style="font-size:10px;padding:1px 6px;border-radius:3px;background:rgba(' + aRgb + ',0.1);color:' + aSc + ';border:1px solid rgba(' + aRgb + ',0.2);">' + app.escapeHtml(a.status) + '</span>';

                        var tagsHtml = '';
                        if (a.tags && a.tags.length) {
                            tagsHtml = '<div style="display:flex;gap:4px;flex-wrap:wrap;margin:4px 0;">';
                            for (var ti = 0; ti < a.tags.length; ti++) {
                                tagsHtml += '<span style="font-size:10px;padding:1px 6px;border-radius:3px;background:rgba(255,255,255,0.04);color:#9a9a9f;border:1px solid rgba(255,255,255,0.06);">' + app.escapeHtml(a.tags[ti]) + '</span>';
                            }
                            tagsHtml += '</div>';
                        }

                        // 状态为招募中才显示确认/拒绝按钮
                        var actionBtns = '';
                        if (post.status === '招募中') {
                            actionBtns = '<span onclick="if(confirm(\\'确认选择' + app.escapeHtml(a.name) + '？\\')){MlifeApp.cancelRecruitPost(\\'' + post.id + '\\');MlifeApp.navigate(\\'recruit_manage\\');}" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(52,211,153,0.15);color:#34d399;border:1px solid rgba(52,211,153,0.25);font-family:inherit;">✅ 确认</span>'
                                + '<span onclick="MlifeApp.action(\\'/send 私信 ' + app.escapeHtml(a.contactId || a.name) + '|/trigger\\')" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(96,165,250,0.1);color:#60a5fa;border:1px solid rgba(96,165,250,0.2);font-family:inherit;">💬 私信</span>'
                                + '<span onclick="MlifeApp.action(\\'/send 拒绝 ' + app.escapeHtml(a.name) + '|/trigger\\')" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(248,113,113,0.1);color:#f87171;border:1px solid rgba(248,113,113,0.2);font-family:inherit;">❌ 拒绝</span>';
                        } else {
                            actionBtns = '<span onclick="MlifeApp.navigate(\\'dm\\',{contact:\\'' + app.escapeHtml(a.contactId || a.name) + '\\'})" style="display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;cursor:pointer;background:rgba(96,165,250,0.1);color:#60a5fa;border:1px solid rgba(96,165,250,0.2);font-family:inherit;">💬 私信</span>';
                        }

                        applicantsHtml += '<div style="background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:10px;padding:12px 14px;">'
                            + '<div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:4px;">'
                            + '<div style="display:flex;align-items:center;gap:8px;">'
                            + '<span style="font-size:24px;">' + (a.avatar || '👤') + '</span>'
                            + '<div><div style="font-weight:600;font-size:14px;color:#e5e5e7;">' + app.escapeHtml(a.name) + '</div>'
                            + '<div style="font-size:11px;color:#9a9a9f;">' + (a.age || '--') + ' · ' + (a.city || '--') + ' ⭐' + (a.rating || '--') + '</div></div>'
                            + '</div>' + aStatusTag
                            + '</div>'
                            + (a.note ? '<div style="font-size:12px;color:#6a6a70;padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:6px;margin:4px 0;line-height:1.4;">📝 ' + app.escapeHtml(a.note) + '</div>' : '')
                            + tagsHtml
                            + (actionBtns ? '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;">' + actionBtns + '</div>' : '')
                            + '</div>';
                    }
                    applicantsHtml += '</div>';
                }

                // 底部操作按钮
                var bottomBtns = '';
                if (post.status === '招募中') {
                    bottomBtns = '<button onclick="if(confirm(\\'确定取消招募「' + app.escapeHtml(post.title) + '」？\\')){MlifeApp.cancelRecruitPost(\\'' + post.id + '\\');MlifeApp.navigate(\\'recruit_manage\\');}" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(248,113,113,0.3);background:rgba(248,113,113,0.1);color:#f87171;font-size:13px;cursor:pointer;font-family:inherit;">取消招募</button>';
                } else if (post.status === '已取消') {
                    bottomBtns = '<button onclick="MlifeApp.reactivateRecruitPost(\\'' + post.id + '\\');MlifeApp.navigate(\\'recruit_manage\\');" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(52,211,153,0.3);background:rgba(52,211,153,0.1);color:#34d399;font-size:13px;cursor:pointer;font-family:inherit;">重新发布</button>';
                }
                bottomBtns += '<button onclick="MlifeApp.navigate(\\'recruit_manage\\')" style="flex:1;padding:10px;border-radius:8px;border:1px solid rgba(201,169,110,0.2);background:transparent;color:#9a9a9f;font-size:13px;cursor:pointer;font-family:inherit;">返回</button>';

                // 组装
                var rewardDisplay = post.reward ? '<div style="display:flex;gap:10px;font-size:12px;color:#9a9a9f;"><span>💰 ' + app.escapeHtml(post.reward) + '</span></div>' : '';
                var progressHtml = post.progress ? '<div style="font-size:12px;color:#6a6a70;padding:6px 8px;background:rgba(255,255,255,0.02);border-radius:6px;line-height:1.4;">' + app.escapeHtml(post.progress) + '</div>' : '';

                return '<div style="padding:0;">'
                    + '<div style="background:linear-gradient(135deg,#1a1a1f,#222228);padding:12px 16px;border-bottom:1px solid rgba(201,169,110,0.12);display:flex;align-items:center;gap:10px;">'
                    + '<button onclick="MlifeApp.navigate(\\'recruit_manage\\')" style="background:none;border:none;color:#8a8a9a;font-size:16px;cursor:pointer;padding:0 2px;font-family:inherit;">←</button>'
                    + '<span style="font-size:18px;">' + (post.typeIcon || '📋') + '</span>'
                    + '<div><div style="font-weight:600;font-size:15px;color:#e5e5e7;">' + app.escapeHtml(post.title) + '</div>'
                    + '<div style="font-size:11px;color:#9a9a9f;">' + (post.recruitType || '') + '</div></div>'
                    + statusTag
                    + '</div>'
                    + '<div style="padding:14px 16px;">'
                    + '<div style="font-size:12px;color:#9a9a9f;margin-bottom:6px;">👤 ' + app.escapeHtml(post.poster || '用户') + ' · 🕐 ' + app.escapeHtml(post.time || '') + '</div>'
                    + rewardDisplay
                    + '<div style="background:#1a1a1f;border-radius:8px;padding:10px 12px;border:1px solid rgba(201,169,110,0.08);margin:8px 0;">'
                    + '<div style="font-size:11px;color:#9a9a9f;margin-bottom:6px;font-weight:600;">详细信息</div>'
                    + '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 12px;font-size:12px;color:#e5e5e7;">'
                    + (post.count ? '<div><span style="color:#6a6a70;">人数:</span> ' + app.escapeHtml(String(post.count)) + '</div>' : '')
                    + (post.date ? '<div><span style="color:#6a6a70;">日期:</span> ' + app.escapeHtml(post.date) + '</div>' : '')
                    + (post.city ? '<div><span style="color:#6a6a70;">地点:</span> ' + app.escapeHtml(post.city) + '</div>' : '')
                    + (post.duration ? '<div><span style="color:#6a6a70;">时长:</span> ' + app.escapeHtml(post.duration) + '</div>' : '')
                    + (post.ageRange ? '<div><span style="color:#6a6a70;">年龄:</span> ' + app.escapeHtml(post.ageRange) + '</div>' : '')
                    + (post.bodyPref ? '<div><span style="color:#6a6a70;">偏好:</span> ' + app.escapeHtml(post.bodyPref) + '</div>' : '')
                    + '</div>'
                    + (post.specialReq ? '<div style="font-size:12px;color:#e5e5e7;margin-top:6px;"><span style="color:#6a6a70;">特殊要求:</span> ' + app.escapeHtml(post.specialReq) + '</div>' : '')
                    + (post.playTags && post.playTags.length ? '<div style="font-size:12px;color:#c9a96e;margin-top:6px;">🏷 ' + post.playTags.map(function(t){return app.escapeHtml(t)}).join(' · ') + '</div>' : '')
                    + '</div>'
                    + progressHtml
                    + '</div>'
                    + '<div style="padding:8px 16px 4px;border-bottom:1px solid rgba(201,169,110,0.08);"><div style="font-size:13px;font-weight:600;color:#e5e5e7;">应征者 (' + applicants.length + '人)</div></div>'
                    + '<div style="padding:8px 16px;">' + applicantsHtml + '</div>'
                    + '<div style="padding:12px 16px;display:flex;gap:8px;">' + bottomBtns + '</div>'
                    + '</div>';
            };

`;

code = code.replace(
  "            app.getRecruitPosts = function()",
  helperInsert + "            app.getRecruitPosts = function()"
);

// === Edit 3: 修改管理页列表渲染，添加 click 事件 ===
// 在 makeItemList 中给每一条帖子添加 onclick
const oldCardPattern = "var listHtml = '';\n                    for (var i = 0; i < filtered.length; i++) {\n                        var item = filtered[i];\n                        var statusClass = getStatusClass(item.status);\n\n                        // 隐藏描述\n                        var hiddenHtml = item.hidden ? '<div style=\"font-size:11px;color:#6a6a70;font-style:italic;padding:0 0 8px;line-height:1.4;border-bottom:1px dashed rgba(255,255,255,0.04);margin-bottom:8px;\">' + app.escapeHtml(item.hidden) + '</div>' : '';\n\n                        // 操作按钮\n                        var opsHtml = '';\n                        if (item.ops) {\n                            var ops = item.ops.split('/').filter(function(o) { return o.trim(); });\n                            for (var oi = 0; oi < ops.length; oi++) {\n                                var op = ops[oi].trim();\n                                if (op === '无') continue;\n                                var opClass = 'background:rgba(255,255,255,0.06);color:#9a9a9f;border:1px solid rgba(255,255,255,0.1);';\n                                if (op.indexOf('确认') !== -1 || op.indexOf('选择') !== -1) opClass = 'background:rgba(52,211,153,0.15);color:#34d399;border:1px solid rgba(52,211,153,0.25);';\n                                else if (op.indexOf('取消') !== -1 || op.indexOf('拒绝') !== -1 || op.indexOf('撤回') !== -1) opClass = 'background:rgba(248,113,113,0.1);color:#f87171;border:1px solid rgba(248,113,113,0.2);';\n                                else if (op.indexOf('查看') !== -1 || op.indexOf('联系') !== -1 || op.indexOf('评价') !== -1 || op.indexOf('再次') !== -1) opClass = 'background:rgba(255,255,255,0.06);color:#9a9a9f;border:1px solid rgba(255,255,255,0.1);';\n                                else if (op.indexOf('提交') !== -1) opClass = 'background:rgba(201,169,110,0.15);color:#c9a96e;border:1px solid rgba(201,169,110,0.3);';\n                                opsHtml += '<span style=\"display:inline-block;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:500;cursor:pointer;' + opClass + 'font-family:inherit;transition:background 0.2s;\" onclick=\"MlifeApp.action(\\'/send ' + app.escapeHtml(op) + '|/trigger\\')\">' + app.escapeHtml(op) + '</span>';\n                            }\n                            if (opsHtml) opsHtml = '<div style=\"display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;\">' + opsHtml + '</div>';\n                        }\n\n                        var typeIcon = item.typeIcon || '📋';\n                        var posterHtml = item.poster ? '<div style=\"font-size:11px;color:#9a9a9f;margin-bottom:4px;\">' + app.escapeHtml(item.poster) + '</div>' : '';\n\n                        listHtml += '<div style=\"background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:10px;padding:12px 14px;margin-bottom:8px;\">'";

// Find the renderRecruitManage function and modify its makeItemList
// The simpler approach: just add onclick to the card div
code = code.replace(
  "listHtml += '<div style=\"background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:10px;padding:12px 14px;margin-bottom:8px;\">'",
  "listHtml += '<div onclick=\"MlifeApp.navigate(\\'recruit_detail_local\\',{postId:\\'' + item.id + '\\'})\" style=\"background:#222228;border:1px solid rgba(201,169,110,0.12);border-radius:10px;padding:12px 14px;margin-bottom:8px;cursor:pointer;\" onmouseover=\"this.style.borderColor=\\'rgba(201,169,110,0.3)\\';this.style.background=\\'#2a2a32\\'\" onmouseout=\"this.style.borderColor=\\'rgba(201,169,110,0.12)\\';this.style.background=\\'#222228\\'\">'"
);

// Verify syntax
try { new Function(code); console.log('语法: OK'); } catch(e) { console.log('语法错误:', e.message.slice(0,200)); process.exit(1); }

fs.writeFileSync('E:/tavern_sync_project/角色卡修改用/魅途/脚本/Mlife_TH.js', code, 'utf8');
console.log('写入完成, 大小:', (code.length/1024).toFixed(0), 'KB');
