import { registerMvuSchema } from
  'https://testingcf.jsdelivr.net/gh/StageDog/tavern_resource/dist/util/mvu_zod.js';

export const Schema = z.object({
  系统: z.object({
    日期: z.string().prefault(''),
    时间: z.string().prefault(''),
    位置: z.string().prefault(''),
  }).prefault({}),
  M-life_经济: z.object({
    M币余额: z.string().prefault('0'),
    累计充值: z.string().prefault('0'),
  }).prefault({}),
  M-life_用户: z.object({
    用户等级: z.string().prefault('Lv1'),
    经验值: z.string().prefault('0'),
    VIP类型: z.string().prefault('无'),
    VIP到期日: z.string().prefault(''),
    昵称: z.string().prefault(''),
    年龄: z.string().prefault(''),
  }).prefault({}),
  M-life_社交: z.object({
    获赞总数: z.string().prefault('0'),
    匹配成功数: z.string().prefault('0'),
    粉丝数: z.string().prefault('0'),
    关注数: z.string().prefault('0'),
    今日匹配次数: z.string().prefault('0'),
    今日发帖次数: z.string().prefault('0'),
    今日已签到: z.string().prefault('false'),
    连续签到天数: z.string().prefault('0'),
  }).prefault({}),
  M-life_私信: z.object({
    未读私信数: z.string().prefault('0'),
    最近联系人: z.string().prefault(''),
  }).prefault({}),
  M-life_黑金: z.object({
    进行中招募数: z.string().prefault('0'),
    已报名招募数: z.string().prefault('0'),
  }).prefault({}),
  M-life_角色库: z.object({
    角色列表: z.string().prefault('[]'),
  }).prefault({}),
  M-life_角色详情: z.object({
    已开盒角色: z.string().prefault('[]'),
    角色详情缓存: z.string().prefault('[]'),
  }).prefault({}),
});

$(() => {
  registerMvuSchema(Schema);
});