// MLIFE_MODULE_PERSONA
// M-life Persona — 私信人格底座生成系统
// 依赖: MlifeCore (window.MlifeApp, window.DM_Manager)
(function(){"use strict";
if(window.top&&window.top!==window.self){
  try{
    var _s=document.querySelectorAll("script[type=module]");
    for(var _i=0;_i<_s.length;_i++){
      var _t=_s[_i].textContent||"";
      if(_t.indexOf("MLIFE_MODULE_PERSONA")>=0){
        var _inj=window.top.document.createElement("script");
        _inj.textContent=_t;
        window.top.document.head.appendChild(_inj);break;
      }
    }
  }catch(_e){}
  return;
}

// 等待 MlifeApp 就绪
var _retry=0;
function _init(){
  var pwin=window.top||window;
  if(!pwin.MlifeApp||!pwin.DM_Manager){_retry++;if(_retry<50){setTimeout(_init,200);}return;}
  console.log('[Mlife] Persona module loaded');
}
_init();
})();
